import React from 'react';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import { MAP_DARK_STYLE } from '@/constants/config';

export { Marker, Polyline };

export function TariqMapView({ style, region, initialRegion, children, showsUserLocation }: any) {
  return (
    <MapView
      style={style}
      provider={PROVIDER_GOOGLE}
      customMapStyle={MAP_DARK_STYLE}
      region={region}
      initialRegion={initialRegion}
      showsUserLocation={showsUserLocation}
      showsMyLocationButton={false}
      showsCompass={false}
      showsTraffic={false}
    >
      {children}
    </MapView>
  );
}
