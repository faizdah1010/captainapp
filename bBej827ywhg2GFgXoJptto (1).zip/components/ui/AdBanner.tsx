import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, Pressable } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Typography, Spacing, Radius } from '@/constants/theme';
import { useLanguage } from '@/hooks/useLanguage';

const ADS_AR = [
  {
    id: '1',
    title: 'خصم 20% على أول رحلة VIP',
    subtitle: 'عرض حصري لمستخدمي طريقي الجدد',
    badge: 'عرض حصري',
    icon: 'local-offer' as const,
    gradient: ['#6B0010', '#CC1020'] as [string, string],
  },
  {
    id: '2',
    title: 'طريق نسائي — الآن في الأردن',
    subtitle: 'كابتن أنثى متخصصة لكل رحلة بأمان',
    badge: 'جديد',
    icon: 'face' as const,
    gradient: ['#6B0045', '#9B1A6A'] as [string, string],
  },
  {
    id: '3',
    title: 'إكسبرس — توصيل سريع للطرود',
    subtitle: 'نصل إليك في كافة محافظات المملكة',
    badge: 'أسرع',
    icon: 'local-shipping' as const,
    gradient: ['#0A2A5C', '#1A5C9B'] as [string, string],
  },
];

const ADS_EN = [
  {
    id: '1',
    title: '20% Off Your First VIP Ride',
    subtitle: 'Exclusive offer for new Tariq users',
    badge: 'Exclusive',
    icon: 'local-offer' as const,
    gradient: ['#6B0010', '#CC1020'] as [string, string],
  },
  {
    id: '2',
    title: 'Tariq Ladies — Now in Jordan',
    subtitle: 'Female captain only, safe & comfortable',
    badge: 'New',
    icon: 'face' as const,
    gradient: ['#6B0045', '#9B1A6A'] as [string, string],
  },
  {
    id: '3',
    title: 'Express — Fast Parcel Delivery',
    subtitle: 'We reach all governorates in Jordan',
    badge: 'Fastest',
    icon: 'local-shipping' as const,
    gradient: ['#0A2A5C', '#1A5C9B'] as [string, string],
  },
];

export function AdBanner() {
  const { language, isRTL } = useLanguage();
  const ads = language === 'ar' ? ADS_AR : ADS_EN;
  const [current, setCurrent] = useState(0);
  const fadeAnim = useRef(new Animated.Value(1)).current;
  const slideAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const interval = setInterval(() => {
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 0, duration: 250, useNativeDriver: true }),
        Animated.timing(slideAnim, { toValue: -12, duration: 250, useNativeDriver: true }),
      ]).start(() => {
        setCurrent((prev) => (prev + 1) % ads.length);
        slideAnim.setValue(12);
        Animated.parallel([
          Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
          Animated.spring(slideAnim, { toValue: 0, tension: 80, friction: 10, useNativeDriver: true }),
        ]).start();
      });
    }, 4500);
    return () => clearInterval(interval);
  }, [ads.length]);

  const ad = ads[current];

  return (
    <Pressable
      style={styles.wrapper}
      onPress={() => {}}
      style={({ pressed }) => [styles.wrapper, pressed && { opacity: 0.9, transform: [{ scale: 0.99 }] }]}
    >
      <LinearGradient
        colors={[...ad.gradient, '#0D0002']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.container}
      >
        <Animated.View
          style={[
            styles.inner,
            { opacity: fadeAnim, transform: [{ translateX: slideAnim }] },
            { flexDirection: isRTL ? 'row-reverse' : 'row' },
          ]}
        >
          {/* Text */}
          <View style={[styles.textCol, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{ad.badge}</Text>
            </View>
            <Text style={[styles.title, { textAlign: isRTL ? 'right' : 'left' }]}>{ad.title}</Text>
            <Text style={[styles.subtitle, { textAlign: isRTL ? 'right' : 'left' }]}>{ad.subtitle}</Text>
          </View>

          {/* Icon */}
          <View style={styles.iconBox}>
            <MaterialIcons name={ad.icon} size={30} color="rgba(255,255,255,0.9)" />
          </View>
        </Animated.View>

        {/* Dots */}
        <View style={styles.dots}>
          {ads.map((_, i) => (
            <View key={i} style={[styles.dot, i === current && styles.activeDot]} />
          ))}
        </View>

        {/* Decorative circle */}
        <View style={styles.decCircle} pointerEvents="none" />
      </LinearGradient>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    marginHorizontal: Spacing.base,
    marginVertical: Spacing.sm,
    borderRadius: Radius.lg,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 10,
    elevation: 6,
  },
  container: {
    borderRadius: Radius.lg,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  inner: {
    alignItems: 'center',
    padding: Spacing.base,
    paddingVertical: Spacing.md,
    gap: Spacing.md,
  },
  textCol: { flex: 1, gap: 5 },
  badge: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: Radius.full,
    marginBottom: 3,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.25)',
  },
  badgeText: { color: '#FFF', fontSize: Typography.sizes.xs, fontWeight: Typography.weights.bold },
  title: {
    color: '#FFFFFF',
    fontSize: Typography.sizes.md,
    fontWeight: Typography.weights.bold,
    lineHeight: 20,
  },
  subtitle: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: Typography.sizes.sm,
    lineHeight: 17,
  },
  iconBox: {
    width: 56, height: 56, borderRadius: 28,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)',
  },
  dots: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: Spacing.xs,
    paddingBottom: Spacing.sm,
  },
  dot: { width: 5, height: 5, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.3)' },
  activeDot: { backgroundColor: '#FFF', width: 18 },
  decCircle: {
    position: 'absolute', right: -30, top: -30,
    width: 120, height: 120, borderRadius: 60,
    backgroundColor: 'rgba(255,255,255,0.04)',
    pointerEvents: 'none',
  },
});
