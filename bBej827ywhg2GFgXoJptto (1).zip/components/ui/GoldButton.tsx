import React from 'react';
import { Pressable, Text, StyleSheet, ViewStyle, TextStyle, ActivityIndicator } from 'react-native';
import { Colors, Typography, Spacing, Radius, Shadows } from '@/constants/theme';

interface GoldButtonProps {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  disabled?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
}

export function GoldButton({
  label, onPress, variant = 'primary', size = 'md',
  loading = false, disabled = false, style, textStyle,
}: GoldButtonProps) {
  const isDisabled = disabled || loading;

  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      style={({ pressed }) => [
        styles.base,
        styles[variant],
        styles[`size_${size}`],
        pressed && styles.pressed,
        isDisabled && styles.disabled,
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={variant === 'primary' ? Colors.textOnGold : Colors.gold} size="small" />
      ) : (
        <Text style={[styles.text, styles[`text_${variant}`], styles[`textSize_${size}`], textStyle]}>
          {label}
        </Text>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: Radius.full,
  },
  primary: {
    backgroundColor: Colors.red,
    ...Shadows.red,
  },
  outline: {
    backgroundColor: 'transparent',
    borderWidth: 1.5,
    borderColor: Colors.gold,
  },
  ghost: {
    backgroundColor: Colors.redFaint,
  },
  size_sm: { paddingVertical: Spacing.sm, paddingHorizontal: Spacing.lg, minHeight: 40 },
  size_md: { paddingVertical: Spacing.md, paddingHorizontal: Spacing.xl, minHeight: 50 },
  size_lg: { paddingVertical: Spacing.base, paddingHorizontal: Spacing.xxl, minHeight: 58 },
  pressed: { opacity: 0.8, transform: [{ scale: 0.97 }] },
  disabled: { opacity: 0.4 },
  text: { fontWeight: Typography.weights.bold },
  text_primary: { color: '#FFFFFF' },
  text_outline: { color: Colors.gold },
  text_ghost: { color: Colors.gold },
  textSize_sm: { fontSize: Typography.sizes.sm },
  textSize_md: { fontSize: Typography.sizes.base },
  textSize_lg: { fontSize: Typography.sizes.lg },
});
