import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography } from '@/constants/theme';

// Web fallback — react-native-maps is mobile-only
export function TariqMapView({ style, children }: any) {
  return (
    <View style={[styles.container, style]}>
      <MaterialIcons name="map" size={48} color={Colors.gold} />
      <Text style={styles.text}>خريطة الأردن التفاعلية</Text>
      <Text style={styles.subtext}>متاحة على تطبيق الجوال</Text>
    </View>
  );
}

export function Marker({ children }: any) {
  return <>{children}</>;
}

export function Polyline() {
  return null;
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.surfaceCard,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  text: { color: Colors.textPrimary, fontSize: Typography.sizes.base, fontWeight: '600' },
  subtext: { color: Colors.textSecondary, fontSize: Typography.sizes.sm },
});
