import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, Radius, Shadows } from '@/constants/theme';
import { useLanguage } from '@/hooks/useLanguage';
import { CONFIG } from '@/constants/config';

interface CaptainCardProps {
  captain: typeof CONFIG.MOCK_CAPTAIN;
  eta?: number;
  onChat?: () => void;
  onCall?: () => void;
}

export function CaptainCard({ captain, eta = 4, onChat, onCall }: CaptainCardProps) {
  const { language, isRTL, t } = useLanguage();

  return (
    <View style={styles.container}>
      <View style={[styles.row, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
        <View style={styles.avatar}>
          <MaterialIcons name="person" size={32} color={Colors.gold} />
        </View>
        <View style={[styles.info, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
          <Text style={styles.name}>{language === 'ar' ? captain.name : captain.nameEn}</Text>
          <View style={[styles.ratingRow, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
            <MaterialIcons name="star" size={14} color={Colors.gold} />
            <Text style={styles.rating}>{captain.rating}</Text>
            <Text style={styles.trips}>• {captain.trips} {language === 'ar' ? 'رحلة' : 'trips'}</Text>
          </View>
          <Text style={styles.car}>{captain.car} • {captain.plate}</Text>
        </View>
        <View style={styles.etaBox}>
          <Text style={styles.etaNum}>{eta}</Text>
          <Text style={styles.etaLabel}>{t('minutes')}</Text>
        </View>
      </View>
      <View style={[styles.actions, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
        <Pressable style={styles.actionBtn} onPress={onChat}>
          <MaterialIcons name="chat" size={20} color={Colors.gold} />
          <Text style={styles.actionText}>{t('chatWithCaptain')}</Text>
        </Pressable>
        <View style={styles.divider} />
        <Pressable style={styles.actionBtn} onPress={onCall}>
          <MaterialIcons name="call" size={20} color={Colors.gold} />
          <Text style={styles.actionText}>{t('callCaptain')}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.surfaceCard,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.borderGold,
    overflow: 'hidden',
    ...Shadows.gold,
  },
  row: {
    padding: Spacing.base,
    gap: Spacing.md,
    alignItems: 'center',
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: Colors.goldFaint,
    borderWidth: 2,
    borderColor: Colors.gold,
    alignItems: 'center',
    justifyContent: 'center',
  },
  info: { flex: 1, gap: 4 },
  name: { color: Colors.textPrimary, fontSize: Typography.sizes.base, fontWeight: Typography.weights.bold },
  ratingRow: { gap: Spacing.xs, alignItems: 'center' },
  rating: { color: Colors.gold, fontSize: Typography.sizes.sm, fontWeight: Typography.weights.semiBold },
  trips: { color: Colors.textSecondary, fontSize: Typography.sizes.sm },
  car: { color: Colors.textSecondary, fontSize: Typography.sizes.sm },
  etaBox: {
    alignItems: 'center',
    backgroundColor: Colors.goldFaint,
    borderRadius: Radius.md,
    padding: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.borderGold,
    minWidth: 52,
  },
  etaNum: { color: Colors.gold, fontSize: Typography.sizes.xxl, fontWeight: Typography.weights.bold },
  etaLabel: { color: Colors.textSecondary, fontSize: Typography.sizes.xs },
  actions: {
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  actionBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.md,
    gap: Spacing.sm,
  },
  actionText: { color: Colors.gold, fontSize: Typography.sizes.sm, fontWeight: Typography.weights.semiBold },
  divider: { width: 1, backgroundColor: Colors.border, marginVertical: Spacing.sm },
});
