import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, Pressable, TextInput, Modal,
  Animated, Easing, KeyboardAvoidingView, Platform, ScrollView,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, Radius, Shadows } from '@/constants/theme';

interface RatingModalProps {
  visible: boolean;
  captainName: string;
  language: 'ar' | 'en';
  isRTL: boolean;
  onSubmit: (rating: number, review: string) => void;
  onSkip: () => void;
}

const QUICK_REVIEWS_AR = [
  'كابتن محترف', 'سيارة نظيفة', 'وصل في الوقت', 'قيادة آمنة', 'خدمة ممتازة',
];
const QUICK_REVIEWS_EN = [
  'Professional captain', 'Clean car', 'On time', 'Safe driving', 'Excellent service',
];

export function RatingModal({ visible, captainName, language, isRTL, onSubmit, onSkip }: RatingModalProps) {
  const [selectedRating, setSelectedRating] = useState(0);
  const [hoveredStar, setHoveredStar] = useState(0);
  const [review, setReview] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);

  // Animations
  const backdropOpacity = useRef(new Animated.Value(0)).current;
  const sheetTranslate = useRef(new Animated.Value(400)).current;
  const starScales = useRef([1, 2, 3, 4, 5].map(() => new Animated.Value(1))).current;
  const successScale = useRef(new Animated.Value(0)).current;
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    if (visible) {
      setSelectedRating(0);
      setHoveredStar(0);
      setReview('');
      setSelectedTags([]);
      setShowSuccess(false);
      successScale.setValue(0);

      Animated.parallel([
        Animated.timing(backdropOpacity, { toValue: 1, duration: 280, useNativeDriver: true }),
        Animated.spring(sheetTranslate, { toValue: 0, tension: 60, friction: 10, useNativeDriver: true }),
      ]).start();
    } else {
      backdropOpacity.setValue(0);
      sheetTranslate.setValue(400);
    }
  }, [visible]);

  const animateStar = (index: number) => {
    Animated.sequence([
      Animated.timing(starScales[index], { toValue: 1.5, duration: 120, useNativeDriver: true, easing: Easing.out(Easing.back(3)) }),
      Animated.spring(starScales[index], { toValue: 1, tension: 200, friction: 6, useNativeDriver: true }),
    ]).start();
    // Cascade smaller bounce on adjacent stars
    if (index > 0) {
      Animated.sequence([
        Animated.timing(starScales[index - 1], { toValue: 1.2, duration: 80, useNativeDriver: true }),
        Animated.spring(starScales[index - 1], { toValue: 1, tension: 300, friction: 8, useNativeDriver: true }),
      ]).start();
    }
  };

  const handleStarPress = (star: number) => {
    setSelectedRating(star);
    animateStar(star - 1);
  };

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = async () => {
    if (selectedRating === 0) return;
    setSubmitting(true);

    const fullReview = [
      ...selectedTags,
      review.trim(),
    ].filter(Boolean).join(' · ');

    // Show success animation first
    setShowSuccess(true);
    Animated.spring(successScale, { toValue: 1, tension: 80, friction: 6, useNativeDriver: true }).start();

    setTimeout(() => {
      onSubmit(selectedRating, fullReview);
    }, 1000);
  };

  const ratingLabels = {
    ar: ['', 'سيء', 'مقبول', 'جيد', 'جيد جداً', 'ممتاز!'],
    en: ['', 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent!'],
  };
  const quickReviews = language === 'ar' ? QUICK_REVIEWS_AR : QUICK_REVIEWS_EN;

  const ratingColor =
    selectedRating <= 2 ? Colors.error :
    selectedRating === 3 ? Colors.warning :
    Colors.gold;

  if (!visible) return null;

  return (
    <Modal transparent visible={visible} animationType="none" statusBarTranslucent>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        {/* Backdrop */}
        <Animated.View style={[styles.backdrop, { opacity: backdropOpacity }]}>
          <Pressable style={styles.flex} onPress={onSkip} />
        </Animated.View>

        {/* Sheet */}
        <Animated.View style={[styles.sheet, { transform: [{ translateY: sheetTranslate }] }]}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={styles.scrollContent}
          >
            {showSuccess ? (
              /* ── Success state ── */
              <Animated.View style={[styles.successContainer, { transform: [{ scale: successScale }] }]}>
                <View style={styles.successIcon}>
                  <MaterialIcons name="check-circle" size={56} color={Colors.success} />
                </View>
                <Text style={styles.successTitle}>
                  {language === 'ar' ? 'شكراً على تقييمك!' : 'Thank you for your rating!'}
                </Text>
                <Text style={styles.successSubtitle}>
                  {language === 'ar'
                    ? 'تقييمك يساعدنا على تحسين الخدمة'
                    : 'Your feedback helps us improve our service'}
                </Text>
              </Animated.View>
            ) : (
              <>
                {/* Handle bar */}
                <View style={styles.handleBar} />

                {/* Header */}
                <Text style={styles.title}>
                  {language === 'ar' ? 'كيف كانت رحلتك؟' : 'How was your ride?'}
                </Text>
                <Text style={styles.captainNameText}>
                  {language === 'ar' ? 'مع' : 'with'}{' '}
                  <Text style={styles.captainHighlight}>{captainName}</Text>
                </Text>

                {/* Star row */}
                <View style={styles.starsRow}>
                  {[1, 2, 3, 4, 5].map((star) => {
                    const filled = star <= (hoveredStar || selectedRating);
                    return (
                      <Pressable
                        key={star}
                        onPress={() => handleStarPress(star)}
                        hitSlop={8}
                        style={styles.starBtn}
                      >
                        <Animated.View style={{ transform: [{ scale: starScales[star - 1] }] }}>
                          <MaterialIcons
                            name={filled ? 'star' : 'star-border'}
                            size={44}
                            color={filled ? ratingColor : Colors.border}
                          />
                        </Animated.View>
                      </Pressable>
                    );
                  })}
                </View>

                {/* Rating label */}
                {selectedRating > 0 ? (
                  <Animated.Text style={[styles.ratingLabel, { color: ratingColor }]}>
                    {ratingLabels[language][selectedRating]}
                  </Animated.Text>
                ) : (
                  <Text style={styles.ratingPlaceholder}>
                    {language === 'ar' ? 'اضغط لتقييم الرحلة' : 'Tap to rate your ride'}
                  </Text>
                )}

                {/* Quick tags */}
                {selectedRating >= 4 ? (
                  <View style={styles.tagsSection}>
                    <Text style={[styles.tagsLabel, { textAlign: isRTL ? 'right' : 'left' }]}>
                      {language === 'ar' ? 'ما الذي أعجبك؟' : 'What did you like?'}
                    </Text>
                    <View style={[styles.tagsWrap, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
                      {quickReviews.map((tag) => {
                        const active = selectedTags.includes(tag);
                        return (
                          <Pressable
                            key={tag}
                            style={({ pressed }) => [
                              styles.tag,
                              active && styles.tagActive,
                              pressed && { opacity: 0.7 },
                            ]}
                            onPress={() => toggleTag(tag)}
                          >
                            {active ? (
                              <MaterialIcons name="check" size={12} color={Colors.textOnGold} style={{ marginEnd: 4 }} />
                            ) : null}
                            <Text style={[styles.tagText, active && styles.tagTextActive]}>{tag}</Text>
                          </Pressable>
                        );
                      })}
                    </View>
                  </View>
                ) : null}

                {/* Text review */}
                <View style={styles.reviewBox}>
                  <TextInput
                    value={review}
                    onChangeText={setReview}
                    placeholder={
                      language === 'ar'
                        ? 'اكتب تعليقاً (اختياري)...'
                        : 'Write a comment (optional)...'
                    }
                    placeholderTextColor={Colors.textMuted}
                    style={[styles.reviewInput, { textAlign: isRTL ? 'right' : 'left' }]}
                    multiline
                    maxLength={300}
                  />
                  <Text style={styles.charCount}>{review.length}/300</Text>
                </View>

                {/* Submit */}
                <Pressable
                  style={({ pressed }) => [
                    styles.submitBtn,
                    selectedRating === 0 && styles.submitDisabled,
                    pressed && selectedRating > 0 && { opacity: 0.88 },
                  ]}
                  onPress={handleSubmit}
                  disabled={selectedRating === 0 || submitting}
                >
                  <MaterialIcons name="star" size={20} color={Colors.textOnGold} />
                  <Text style={styles.submitText}>
                    {language === 'ar' ? 'إرسال التقييم' : 'Submit Rating'}
                  </Text>
                </Pressable>

                {/* Skip */}
                <Pressable style={styles.skipBtn} onPress={onSkip}>
                  <Text style={styles.skipText}>
                    {language === 'ar' ? 'تخطي' : 'Skip'}
                  </Text>
                </Pressable>
              </>
            )}
          </ScrollView>
        </Animated.View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.72)',
  },
  sheet: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: Colors.surface,
    borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl,
    borderTopWidth: 1, borderTopColor: Colors.borderGold,
    maxHeight: '88%',
    ...Shadows.deep,
  },
  scrollContent: {
    padding: Spacing.xl, paddingBottom: Spacing.xxl, alignItems: 'center',
  },

  handleBar: {
    width: 40, height: 4, borderRadius: 2,
    backgroundColor: Colors.border, marginBottom: Spacing.base,
  },

  title: {
    color: Colors.textPrimary, fontSize: Typography.sizes.xl,
    fontWeight: Typography.weights.bold, textAlign: 'center', marginBottom: Spacing.xs,
  },
  captainNameText: {
    color: Colors.textSecondary, fontSize: Typography.sizes.base, textAlign: 'center',
    marginBottom: Spacing.xl,
  },
  captainHighlight: {
    color: Colors.gold, fontWeight: Typography.weights.semiBold,
  },

  starsRow: {
    flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing.base,
  },
  starBtn: {
    padding: Spacing.xs, alignItems: 'center', justifyContent: 'center',
  },

  ratingLabel: {
    fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold,
    textAlign: 'center', marginBottom: Spacing.base,
    minHeight: 28,
  },
  ratingPlaceholder: {
    color: Colors.textMuted, fontSize: Typography.sizes.sm,
    textAlign: 'center', marginBottom: Spacing.base, minHeight: 28,
  },

  tagsSection: { width: '100%', marginBottom: Spacing.base },
  tagsLabel: {
    color: Colors.textSecondary, fontSize: Typography.sizes.sm,
    marginBottom: Spacing.sm, fontWeight: Typography.weights.medium,
  },
  tagsWrap: {
    flexWrap: 'wrap', gap: Spacing.sm,
  },
  tag: {
    flexDirection: 'row', alignItems: 'center',
    paddingVertical: Spacing.sm, paddingHorizontal: Spacing.md,
    borderRadius: Radius.full, borderWidth: 1.5,
    borderColor: Colors.border, backgroundColor: Colors.surfaceCard,
  },
  tagActive: {
    borderColor: Colors.gold, backgroundColor: Colors.goldFaint,
  },
  tagText: {
    color: Colors.textSecondary, fontSize: Typography.sizes.sm, fontWeight: Typography.weights.medium,
  },
  tagTextActive: { color: Colors.gold },

  reviewBox: {
    width: '100%', marginBottom: Spacing.base,
    backgroundColor: Colors.surfaceCard, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, padding: Spacing.base,
  },
  reviewInput: {
    color: Colors.textPrimary, fontSize: Typography.sizes.base,
    minHeight: 72, maxHeight: 120, lineHeight: 24,
  },
  charCount: {
    color: Colors.textMuted, fontSize: Typography.sizes.xs,
    textAlign: 'right', marginTop: Spacing.xs,
  },

  submitBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: Spacing.sm, backgroundColor: Colors.gold,
    borderRadius: Radius.full, paddingVertical: Spacing.md,
    width: '100%', minHeight: 52, marginBottom: Spacing.md,
    ...Shadows.gold,
  },
  submitDisabled: { opacity: 0.45 },
  submitText: {
    color: Colors.textOnGold, fontSize: Typography.sizes.base, fontWeight: Typography.weights.bold,
  },

  skipBtn: { paddingVertical: Spacing.sm, minHeight: 44, alignItems: 'center', justifyContent: 'center' },
  skipText: { color: Colors.textMuted, fontSize: Typography.sizes.sm },

  // Success
  successContainer: { alignItems: 'center', paddingVertical: Spacing.xxxl, gap: Spacing.base },
  successIcon: {
    width: 96, height: 96, borderRadius: 48,
    backgroundColor: Colors.success + '20', alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: Colors.success + '40',
  },
  successTitle: {
    color: Colors.textPrimary, fontSize: Typography.sizes.xl,
    fontWeight: Typography.weights.bold, textAlign: 'center',
  },
  successSubtitle: {
    color: Colors.textSecondary, fontSize: Typography.sizes.base, textAlign: 'center',
  },
});
