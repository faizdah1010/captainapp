import React, { useRef, useEffect } from 'react';
import { Pressable, View, Text, StyleSheet, Animated } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, Radius, Shadows } from '@/constants/theme';
import { ServiceType } from '@/contexts/RideContext';

interface ServiceCardProps {
  type: ServiceType;
  title: string;
  description: string;
  icon: keyof typeof MaterialIcons.glyphMap;
  isSelected: boolean;
  onPress: () => void;
  isRTL?: boolean;
}

const SERVICE_COLORS: Record<ServiceType, string> = {
  regular: Colors.red,
  ladies: '#9B1A6A',
  express: '#1A5C9B',
};

export function ServiceCard({ type, title, description, icon, isSelected, onPress, isRTL }: ServiceCardProps) {
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const borderAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.spring(scaleAnim, {
        toValue: isSelected ? 1.04 : 1,
        tension: 80, friction: 8, useNativeDriver: true,
      }),
      Animated.timing(borderAnim, {
        toValue: isSelected ? 1 : 0,
        duration: 200, useNativeDriver: false,
      }),
    ]).start();
  }, [isSelected]);

  const accentColor = SERVICE_COLORS[type] ?? Colors.red;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [pressed && { opacity: 0.85 }]}
    >
      <Animated.View
        style={[
          styles.container,
          isSelected && { borderColor: accentColor, borderWidth: 2 },
          { transform: [{ scale: scaleAnim }] },
        ]}
      >
        {/* Glow background when selected */}
        {isSelected ? (
          <View style={[styles.selectedBg, { backgroundColor: `${accentColor}18` }]} />
        ) : null}

        {/* Icon */}
        <View style={[styles.iconWrap, isSelected && { backgroundColor: accentColor, borderColor: accentColor }]}>
          <MaterialIcons
            name={icon}
            size={26}
            color={isSelected ? '#FFF' : Colors.textMuted}
          />
        </View>

        {/* Labels */}
        <Text style={[styles.title, isSelected && { color: Colors.textPrimary }]}>{title}</Text>
        <Text style={styles.desc}>{description}</Text>

        {/* Selected badge */}
        {isSelected ? (
          <View style={[styles.badge, { backgroundColor: accentColor }]}>
            <MaterialIcons name="check" size={10} color="#FFF" />
          </View>
        ) : null}
      </Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    width: 104,
    backgroundColor: Colors.surfaceCard,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    alignItems: 'center',
    gap: Spacing.sm,
    borderWidth: 1.5,
    borderColor: 'rgba(204,16,32,0.18)',
    minHeight: 124,
    position: 'relative',
    overflow: 'hidden',
    ...Shadows.card,
  },
  selectedBg: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    borderRadius: Radius.lg,
  },
  iconWrap: {
    width: 50, height: 50, borderRadius: Radius.md,
    backgroundColor: Colors.surfaceElevated,
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: 'rgba(204,16,32,0.2)',
  },
  title: {
    color: Colors.textSecondary,
    fontSize: Typography.sizes.sm,
    fontWeight: Typography.weights.bold,
    textAlign: 'center',
  },
  desc: {
    color: Colors.textMuted,
    fontSize: Typography.sizes.xs,
    lineHeight: 15,
    textAlign: 'center',
  },
  badge: {
    position: 'absolute', top: 8, right: 8,
    width: 18, height: 18, borderRadius: 9,
    alignItems: 'center', justifyContent: 'center',
  },
});
