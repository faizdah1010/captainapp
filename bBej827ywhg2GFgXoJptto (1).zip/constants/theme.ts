// Tariq - Royal Red & Gold Theme
export const Colors = {
  // Base — deep crimson dark
  background: '#0D0002',
  surface: '#160004',
  surfaceElevated: '#200008',
  surfaceCard: '#1A0005',
  border: '#3A0010',
  borderGold: '#C9A84C44',

  // Red Palette (brand primary)
  primary: '#CC1020',
  primaryLight: '#E8182A',
  red: '#CC1020',
  redLight: '#E8182A',
  redDim: '#8B0010',
  redFaint: '#CC102018',
  redMedium: '#CC102035',
  redGradientTop: '#6B0010',
  redGradientCenter: '#AA0A18',
  redGradientBottom: '#0D0002',

  // Gold Palette (accent secondary)
  gold: '#C9A84C',
  goldLight: '#E8C96A',
  goldDim: '#A08030',
  goldFaint: '#C9A84C18',
  goldMedium: '#C9A84C40',

  // Text
  textPrimary: '#F5F0E8',
  textSecondary: '#C4A8B0',
  textMuted: '#7A5060',
  textOnRed: '#FFFFFF',
  textOnGold: '#1A0005',

  // Semantic
  success: '#4CAF87',
  error: '#FF4444',
  warning: '#E8A030',
  info: '#4A90C9',

  // Overlay
  overlay: 'rgba(10,0,2,0.75)',
  overlayLight: 'rgba(10,0,2,0.45)',
};

export const Typography = {
  sizes: {
    xs: 11,
    sm: 13,
    md: 15,
    base: 16,
    lg: 18,
    xl: 20,
    xxl: 24,
    xxxl: 30,
    hero: 38,
  },
  weights: {
    regular: '400' as const,
    medium: '500' as const,
    semiBold: '600' as const,
    bold: '700' as const,
    extraBold: '800' as const,
  },
  lineHeights: {
    tight: 1.2,
    normal: 1.5,
    relaxed: 1.7,
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
  xxxl: 48,
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 28,
  full: 999,
};

export const Shadows = {
  gold: {
    shadowColor: '#C9A84C',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  red: {
    shadowColor: '#CC1020',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 10,
  },
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 8,
    elevation: 5,
  },
  deep: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.7,
    shadowRadius: 20,
    elevation: 12,
  },
};
