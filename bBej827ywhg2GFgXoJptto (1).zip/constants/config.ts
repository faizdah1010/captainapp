export const CONFIG = {
  APP_NAME: 'طريق',
  APP_NAME_EN: 'Tariq',
  VERSION: '1.0.0',
  CURRENCY: 'JOD',
  CURRENCY_AR: 'د.أ',

  // Jordan center coordinates
  MAP_CENTER: {
    latitude: 31.9539,
    longitude: 35.9106,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  },

  // Jordan governorates
  GOVERNORATES: [
    { id: 'amman', nameAr: 'عمّان', nameEn: 'Amman', lat: 31.9539, lng: 35.9106 },
    { id: 'zarqa', nameAr: 'الزرقاء', nameEn: 'Zarqa', lat: 32.0728, lng: 36.0878 },
    { id: 'irbid', nameAr: 'إربد', nameEn: 'Irbid', lat: 32.5556, lng: 35.8500 },
    { id: 'aqaba', nameAr: 'العقبة', nameEn: 'Aqaba', lat: 29.5321, lng: 35.0063 },
    { id: 'petra', nameAr: 'البتراء', nameEn: 'Petra', lat: 30.3285, lng: 35.4444 },
    { id: 'madaba', nameAr: 'مادبا', nameEn: 'Madaba', lat: 31.7158, lng: 35.7939 },
    { id: 'jerash', nameAr: 'جرش', nameEn: 'Jerash', lat: 32.2751, lng: 35.8997 },
    { id: 'salt', nameAr: 'السلط', nameEn: 'As-Salt', lat: 32.0392, lng: 35.7275 },
    { id: 'mafraq', nameAr: 'المفرق', nameEn: 'Mafraq', lat: 32.3428, lng: 36.2058 },
    { id: 'karak', nameAr: 'الكرك', nameEn: 'Karak', lat: 31.1833, lng: 35.7042 },
  ],

  // Mock captain
  MOCK_CAPTAIN: {
    name: 'أحمد الخالدي',
    nameEn: 'Ahmad Al-Khalidi',
    rating: 4.9,
    trips: 1240,
    plate: 'أ ب ج 1234',
    car: 'Toyota Camry 2023',
    carColor: 'Silver',
    avatar: null,
    lat: 31.9620,
    lng: 35.9200,
  },

  MOCK_CAPTAIN_LADIES: {
    name: 'سارة العمر',
    nameEn: 'Sarah Al-Omar',
    rating: 5.0,
    trips: 890,
    plate: 'س م ل 5678',
    car: 'Hyundai Tucson 2024',
    carColor: 'White',
    avatar: null,
    lat: 31.9480,
    lng: 35.9050,
  },

  // Pricing per service (JOD base rates)
  PRICING: {
    regular: { base: 1.5, perKm: 0.35 },
    ladies: { base: 2.0, perKm: 0.40 },
    express: { base: 2.5, perKm: 0.30 },
  },

  DISCOUNT_CODES: [
    { code: 'TARIQ10', discount: 10 },
    { code: 'WELCOME', discount: 15 },
    { code: 'VIP20', discount: 20 },
    { code: 'JORDAN', discount: 5 },
  ],
};

export const MAP_DARK_STYLE = [
  { elementType: 'geometry', stylers: [{ color: '#0A0A0A' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#0A0A0A' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#A09880' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#1C1C1C' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#2A2A2A' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#2A2218' }] },
  { featureType: 'road.highway', elementType: 'geometry.stroke', stylers: [{ color: '#C9A84C40' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#0D1520' }] },
  { featureType: 'poi', elementType: 'geometry', stylers: [{ color: '#141414' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#0F1F0F' }] },
  { featureType: 'transit', elementType: 'geometry', stylers: [{ color: '#1A1A1A' }] },
  { featureType: 'administrative', elementType: 'geometry', stylers: [{ color: '#2A2A2A' }] },
  { featureType: 'administrative.country', elementType: 'labels.text.fill', stylers: [{ color: '#C9A84C' }] },
];
