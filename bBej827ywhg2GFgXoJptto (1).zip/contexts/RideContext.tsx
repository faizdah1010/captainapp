import React, { createContext, useState, useCallback, useContext, ReactNode, useRef, useEffect } from 'react';
import { getSupabaseClient } from '@/template';
import { CONFIG } from '@/constants/config';
import { sendRideNotification } from '@/services/notificationService';
import { AuthContext } from '@/contexts/AuthContext';

export type ServiceType = 'regular' | 'ladies' | 'express';
export type RideStatus = 'idle' | 'searching' | 'found' | 'arriving' | 'inProgress' | 'completed' | 'cancelled';

export interface Location {
  name: string;
  nameEn: string;
  lat: number;
  lng: number;
}

export interface RideRecord {
  id: string;
  date: string;
  from: Location;
  to: Location;
  service: ServiceType;
  price: number;
  status: 'completed' | 'cancelled';
  captainName: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  isMe: boolean;
  timestamp: Date;
}

export interface CaptainInfo {
  id: string;
  name: string;
  nameEn: string;
  phone: string | null;
  car: string;
  plate: string;
  rating: number;
  trips: number;
  lat: number;
  lng: number;
}

interface RideContextType {
  selectedService: ServiceType;
  setSelectedService: (s: ServiceType) => void;
  pickup: Location | null;
  setPickup: (l: Location | null) => void;
  dropoff: Location | null;
  setDropoff: (l: Location | null) => void;
  estimatedPrice: number;
  discountCode: string;
  setDiscountCode: (c: string) => void;
  discountPercent: number;
  applyDiscount: (code: string) => boolean;
  finalPrice: number;
  rideStatus: RideStatus;
  setRideStatus: (s: RideStatus) => void;
  captain: CaptainInfo | null;
  rideHistory: RideRecord[];
  isLoadingHistory: boolean;
  chatMessages: ChatMessage[];
  sendMessage: (text: string) => void;
  startRide: (language?: 'ar' | 'en') => void;
  cancelRide: () => void;
  completeRide: (language?: 'ar' | 'en') => void;
  resetRide: () => void;
  fetchRideHistory: () => Promise<void>;
  saveRating: (rideId: string, rating: number, review: string) => Promise<void>;
  lastCompletedRideId: string | null;
  activeRequestId: string | null;
}

export const RideContext = createContext<RideContextType | undefined>(undefined);

export function RideProvider({ children }: { children: ReactNode }) {
  const auth = useContext(AuthContext);
  const supabase = getSupabaseClient();

  const [selectedService, setSelectedService] = useState<ServiceType>('regular');
  const [pickup, setPickup] = useState<Location | null>(null);
  const [dropoff, setDropoff] = useState<Location | null>(null);
  const [discountCode, setDiscountCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [rideStatus, setRideStatus] = useState<RideStatus>('idle');
  const [captain, setCaptain] = useState<CaptainInfo | null>(null);
  const [rideHistory, setRideHistory] = useState<RideRecord[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [lastCompletedRideId, setLastCompletedRideId] = useState<string | null>(null);
  const [activeRequestId, setActiveRequestId] = useState<string | null>(null);

  // Polling refs
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const chatPollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastMsgCountRef = useRef(0);

  const getDistance = () => {
    if (!pickup || !dropoff) return 5;
    const R = 6371;
    const dLat = ((dropoff.lat - pickup.lat) * Math.PI) / 180;
    const dLon = ((dropoff.lng - pickup.lng) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((pickup.lat * Math.PI) / 180) *
        Math.cos((dropoff.lat * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    return Math.max(1, 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
  };

  const pricing = CONFIG.PRICING[selectedService];
  const distance = getDistance();
  const estimatedPrice = Math.round((pricing.base + distance * pricing.perKm) * 100) / 100;
  const finalPrice = Math.round(estimatedPrice * (1 - discountPercent / 100) * 100) / 100;

  const applyDiscount = (code: string): boolean => {
    const found = CONFIG.DISCOUNT_CODES.find((d) => d.code.toUpperCase() === code.toUpperCase());
    if (found) { setDiscountPercent(found.discount); return true; }
    setDiscountPercent(0);
    return false;
  };

  // ── Fetch ride history from Supabase ──────────────────────────────────────
  const fetchRideHistory = useCallback(async () => {
    if (!auth?.session?.user) return;
    setIsLoadingHistory(true);
    try {
      const { data, error } = await supabase
        .from('ride_history')
        .select('*')
        .eq('user_id', auth.session.user.id)
        .order('created_at', { ascending: false })
        .limit(30);

      if (error) { console.error('fetchRideHistory:', error.message); return; }

      if (data) {
        setRideHistory(
          data.map((r: any) => ({
            id: r.id,
            date: new Date(r.created_at).toISOString().split('T')[0],
            from: { name: r.from_name ?? '', nameEn: r.from_name_en ?? '', lat: Number(r.from_lat ?? 0), lng: Number(r.from_lng ?? 0) },
            to: { name: r.to_name ?? '', nameEn: r.to_name_en ?? '', lat: Number(r.to_lat ?? 0), lng: Number(r.to_lng ?? 0) },
            service: r.service as ServiceType,
            price: Number(r.price_jod ?? 0),
            status: r.status as 'completed' | 'cancelled',
            captainName: r.captain_name ?? '',
          }))
        );
      }
    } finally {
      setIsLoadingHistory(false);
    }
  }, [auth?.session?.user?.id]);

  // ── Save rating for a completed ride ──────────────────────────────────────
  const saveRating = useCallback(async (rideId: string, rating: number, review: string) => {
    if (!auth?.session?.user) return;
    const userId = auth.session.user.id;
    await supabase
      .from('ride_history')
      .update({ rating, review: review || null })
      .eq('id', rideId)
      .eq('user_id', userId);
    await supabase.rpc('update_passenger_rating', { p_user_id: userId }).catch(() => {});
  }, [auth?.session?.user?.id]);

  // ── Poll ride_request for captain acceptance + location ───────────────────
  const pollRideRequest = useCallback(async (requestId: string, language: 'ar' | 'en') => {
    const { data: req } = await supabase
      .from('ride_requests')
      .select('*, captain_id')
      .eq('id', requestId)
      .single();

    if (!req) return;

    // Captain accepted the ride
    if (req.status === 'accepted' && req.captain_id && rideStatus === 'searching') {
      // Fetch captain profile
      const { data: cap } = await supabase
        .from('captain_profiles')
        .select('*')
        .eq('id', req.captain_id)
        .single();

      if (cap) {
        const captainInfo: CaptainInfo = {
          id: cap.id,
          name: cap.name_ar,
          nameEn: cap.name_en,
          phone: null,
          car: [cap.vehicle_model, cap.vehicle_color].filter(Boolean).join(' ') || 'سيارة',
          plate: cap.plate_number || '',
          rating: Number(cap.rating) || 5.0,
          trips: cap.total_trips || 0,
          lat: Number(cap.current_lat) || CONFIG.MOCK_CAPTAIN.lat,
          lng: Number(cap.current_lng) || CONFIG.MOCK_CAPTAIN.lng,
        };
        setCaptain(captainInfo);
        setRideStatus('found');

        // Immediate local notification for passenger
        sendRideNotification('booking_accepted', language);

        setTimeout(() => {
          setRideStatus('arriving');
          sendRideNotification('captain_arriving', language);
        }, 2000);
      }
    }

    // Captain is in progress
    if (req.status === 'inProgress' && (rideStatus === 'found' || rideStatus === 'arriving')) {
      setRideStatus('inProgress');
    }

    // Captain completed the ride
    if (req.status === 'completed' && rideStatus === 'inProgress') {
      completeRideInternal(language);
    }

    // Update captain location in real-time
    if (req.captain_id && (rideStatus === 'found' || rideStatus === 'arriving' || rideStatus === 'inProgress')) {
      const { data: cap } = await supabase
        .from('captain_profiles')
        .select('current_lat, current_lng')
        .eq('id', req.captain_id)
        .single();

      if (cap?.current_lat && cap?.current_lng) {
        setCaptain((prev) => prev ? { ...prev, lat: Number(cap.current_lat), lng: Number(cap.current_lng) } : prev);
      }
    }
  }, [rideStatus]);

  // ── Poll chat messages from ride_messages ─────────────────────────────────
  const pollChatMessages = useCallback(async (requestId: string) => {
    if (!auth?.session?.user) return;
    const userId = auth.session.user.id;

    const { data } = await supabase
      .from('ride_messages')
      .select('*')
      .eq('ride_id', requestId)
      .order('created_at', { ascending: true });

    if (data && data.length !== lastMsgCountRef.current) {
      lastMsgCountRef.current = data.length;
      setChatMessages(
        data.map((m: any) => ({
          id: m.id,
          text: m.message,
          isMe: m.sender_id === userId,
          timestamp: new Date(m.created_at),
        }))
      );
    }
  }, [auth?.session?.user?.id]);

  // Start/stop polling when activeRequestId changes
  useEffect(() => {
    if (!activeRequestId || rideStatus === 'idle' || rideStatus === 'cancelled') {
      if (pollRef.current) clearInterval(pollRef.current);
      if (chatPollRef.current) clearInterval(chatPollRef.current);
      return;
    }

    const reqId = activeRequestId;
    const lang = 'ar'; // default; startRide passes the real language

    chatPollRef.current = setInterval(() => pollChatMessages(reqId), 3000);

    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
      if (chatPollRef.current) clearInterval(chatPollRef.current);
    };
  }, [activeRequestId, rideStatus]);

  // ── Create ride_request in Supabase ──────────────────────────────────────
  const createRideRequest = async (): Promise<string | null> => {
    if (!auth?.session?.user || !pickup || !dropoff) return null;
    const userId = auth.session.user.id;

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('username, phone, rating')
      .eq('id', userId)
      .single();

    const { data, error } = await supabase
      .from('ride_requests')
      .insert({
        passenger_id: userId,
        service: selectedService,
        from_name: pickup.name,
        from_name_en: pickup.nameEn || pickup.name,
        from_lat: pickup.lat,
        from_lng: pickup.lng,
        to_name: dropoff.name,
        to_name_en: dropoff.nameEn || dropoff.name,
        to_lat: dropoff.lat,
        to_lng: dropoff.lng,
        price_jod: finalPrice,
        discount_code: discountCode || null,
        discount_pct: discountPercent,
        passenger_name: profile?.username || 'راكب',
        passenger_phone: profile?.phone || null,
        passenger_rating: profile?.rating || null,
        status: 'pending',
      })
      .select('id')
      .single();

    if (error) {
      console.error('createRideRequest:', error.message);
      return null;
    }
    return data?.id ?? null;
  };

  const cancelRideRequest = async (requestId: string) => {
    await supabase
      .from('ride_requests')
      .update({ status: 'cancelled' })
      .eq('id', requestId)
      .eq('status', 'pending');
  };

  const saveRideToDB = async (record: RideRecord) => {
    if (!auth?.session?.user) return;
    const userId = auth.session.user.id;
    const { data: insertData } = await supabase.from('ride_history').insert({
      user_id: userId,
      service: record.service,
      from_name: record.from.name,
      from_name_en: record.from.nameEn,
      from_lat: record.from.lat,
      from_lng: record.from.lng,
      to_name: record.to.name,
      to_name_en: record.to.nameEn,
      to_lat: record.to.lat,
      to_lng: record.to.lng,
      price_jod: record.price,
      status: record.status,
      captain_name: record.captainName,
      discount_code: discountCode || null,
      discount_pct: discountPercent,
    }).select('id').single();

    if (insertData?.id && record.status === 'completed') {
      setLastCompletedRideId(insertData.id);
    }

    await supabase.rpc('increment_total_rides', { user_id_param: userId }).catch(() => {
      supabase
        .from('user_profiles')
        .update({ total_rides: (auth.user?.total_rides ?? 0) + 1 })
        .eq('id', userId);
    });
  };

  // Internal complete (used by both passenger & polling)
  const completeRideInternal = (language: 'ar' | 'en' = 'ar') => {
    if (pickup && dropoff) {
      const record: RideRecord = {
        id: `r${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        from: pickup,
        to: dropoff,
        service: selectedService,
        price: finalPrice,
        status: 'completed',
        captainName: captain?.name || '',
      };
      setRideHistory((prev) => [record, ...prev]);
      saveRideToDB(record);

      if (activeRequestId) {
        supabase
          .from('ride_requests')
          .update({ status: 'completed', completed_at: new Date().toISOString() })
          .eq('id', activeRequestId)
          .then(() => {});
      }
    }
    setRideStatus('completed');
    sendRideNotification('ride_completed', language);
    if (pollRef.current) clearInterval(pollRef.current);
    if (chatPollRef.current) clearInterval(chatPollRef.current);
  };

  // ── startRide: create request + poll for captain ──────────────────────────
  const startRide = async (language: 'ar' | 'en' = 'ar') => {
    setRideStatus('searching');
    setChatMessages([]);
    lastMsgCountRef.current = 0;

    const requestId = await createRideRequest();
    if (requestId) {
      setActiveRequestId(requestId);

      // Start polling for captain acceptance every 4 seconds
      if (pollRef.current) clearInterval(pollRef.current);
      pollRef.current = setInterval(() => pollRideRequest(requestId, language), 4000);

      // Start chat polling
      if (chatPollRef.current) clearInterval(chatPollRef.current);
      chatPollRef.current = setInterval(() => pollChatMessages(requestId), 3000);
    }
  };

  const cancelRide = () => {
    if (pollRef.current) clearInterval(pollRef.current);
    if (chatPollRef.current) clearInterval(chatPollRef.current);

    if (activeRequestId) {
      cancelRideRequest(activeRequestId);
      setActiveRequestId(null);
    }

    if (pickup && dropoff) {
      const record: RideRecord = {
        id: `r${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        from: pickup,
        to: dropoff,
        service: selectedService,
        price: 0,
        status: 'cancelled',
        captainName: '',
      };
      setRideHistory((prev) => [record, ...prev]);
      saveRideToDB(record);
    }
    setRideStatus('cancelled');
    setTimeout(() => resetRide(), 2000);
  };

  const completeRide = (language: 'ar' | 'en' = 'ar') => {
    completeRideInternal(language);
  };

  const resetRide = () => {
    if (pollRef.current) clearInterval(pollRef.current);
    if (chatPollRef.current) clearInterval(chatPollRef.current);
    setRideStatus('idle');
    setCaptain(null);
    setPickup(null);
    setDropoff(null);
    setDiscountCode('');
    setDiscountPercent(0);
    setChatMessages([]);
    setLastCompletedRideId(null);
    setActiveRequestId(null);
    lastMsgCountRef.current = 0;
  };

  // ── Send message to ride_messages ─────────────────────────────────────────
  const sendMessage = async (text: string) => {
    if (!activeRequestId || !auth?.session?.user) return;
    const userId = auth.session.user.id;

    // Optimistic update
    const tempMsg: ChatMessage = {
      id: `temp_${Date.now()}`,
      text,
      isMe: true,
      timestamp: new Date(),
    };
    setChatMessages((prev) => [...prev, tempMsg]);

    await supabase.from('ride_messages').insert({
      ride_id: activeRequestId,
      sender_id: userId,
      sender_role: 'passenger',
      message: text,
    });
  };

  return (
    <RideContext.Provider value={{
      selectedService, setSelectedService,
      pickup, setPickup, dropoff, setDropoff,
      estimatedPrice, discountCode, setDiscountCode,
      discountPercent, applyDiscount, finalPrice,
      rideStatus, setRideStatus, captain,
      rideHistory, isLoadingHistory, chatMessages,
      sendMessage, startRide, cancelRide, completeRide, resetRide,
      fetchRideHistory: fetchRideHistory, saveRating, lastCompletedRideId, activeRequestId,
    }}>
      {children}
    </RideContext.Provider>
  );
}
