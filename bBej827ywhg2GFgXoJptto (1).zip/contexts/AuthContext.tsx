import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { getSupabaseClient } from '@/template';
import type { Session } from '@supabase/supabase-js';
import {
  saveSessionToSecureStore,
  getSessionFromSecureStore,
  clearSessionFromSecureStore,
  setBiometricEnabled,
  isBiometricEnabled,
  isBiometricHardwareAvailable,
  saveLastPhone,
} from '@/services/biometricService';

interface UserProfile {
  id: string;
  phone: string | null;
  email: string;
  username: string | null;
  avatar_url: string | null;
  rating: number;
  total_rides: number;
  referral_code: string | null;
}

interface AuthContextType {
  user: UserProfile | null;
  session: Session | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  biometricAvailable: boolean;
  biometricEnabled: boolean;
  logout: () => Promise<void>;
  setSessionFromOTP: (session: Session, phone?: string) => Promise<void>;
  enableBiometric: () => Promise<void>;
  disableBiometric: () => Promise<void>;
  restoreSessionFromBiometric: () => Promise<boolean>;
  refreshProfile: () => Promise<void>;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [biometricAvailable, setBiometricAvailable] = useState(false);
  const [biometricEnabled, setBiometricEnabledState] = useState(false);

  const supabase = getSupabaseClient();

  const fetchProfile = async (userId: string): Promise<UserProfile | null> => {
    const { data, error } = await supabase
      .from('user_profiles')
      .select('id, phone, email, username, avatar_url, rating, total_rides, referral_code')
      .eq('id', userId)
      .single();
    if (error) { console.error('fetchProfile:', error.message); return null; }
    return data as UserProfile;
  };

  useEffect(() => {
    const init = async () => {
      // Check biometric hardware
      const hw = await isBiometricHardwareAvailable();
      setBiometricAvailable(hw);

      // Check if user enabled biometric
      if (hw) {
        const enabled = await isBiometricEnabled();
        setBiometricEnabledState(enabled);
      }

      // Try to restore existing Supabase session
      const { data: { session: s } } = await supabase.auth.getSession();
      if (s?.user) {
        setSession(s);
        const profile = await fetchProfile(s.user.id);
        setUser(profile);
      }
      setIsLoading(false);
    };

    init();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, s) => {
      setSession(s);
      if (s?.user) {
        const profile = await fetchProfile(s.user.id);
        setUser(profile);
      } else {
        setUser(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  // ── Called right after successful OTP verification ───────────────────────
  const setSessionFromOTP = async (newSession: Session, phone?: string) => {
    // Set session in Supabase client
    await supabase.auth.setSession({
      access_token: newSession.access_token,
      refresh_token: newSession.refresh_token,
    });

    // Always persist session in SecureStore for biometric restoration
    await saveSessionToSecureStore({
      access_token: newSession.access_token,
      refresh_token: newSession.refresh_token,
    });

    if (phone) {
      await saveLastPhone(phone);
    }

    const profile = await fetchProfile(newSession.user.id);
    setUser(profile);
    setSession(newSession);
  };

  // ── Biometric: restore session from SecureStore after biometric success ──
  const restoreSessionFromBiometric = async (): Promise<boolean> => {
    const stored = await getSessionFromSecureStore();
    if (!stored) return false;

    try {
      const { data, error } = await supabase.auth.setSession({
        access_token: stored.access_token,
        refresh_token: stored.refresh_token,
      });

      if (error || !data.session) {
        // Token expired — clear and force re-login
        await clearSessionFromSecureStore();
        return false;
      }

      const profile = await fetchProfile(data.session.user.id);
      setUser(profile);
      setSession(data.session);

      // Persist refreshed tokens
      await saveSessionToSecureStore({
        access_token: data.session.access_token,
        refresh_token: data.session.refresh_token,
      });

      return true;
    } catch {
      await clearSessionFromSecureStore();
      return false;
    }
  };

  const enableBiometric = async () => {
    await setBiometricEnabled(true);
    setBiometricEnabledState(true);
  };

  const disableBiometric = async () => {
    await setBiometricEnabled(false);
    setBiometricEnabledState(false);
  };

  const refreshProfile = async () => {
    if (session?.user) {
      const profile = await fetchProfile(session.user.id);
      setUser(profile);
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    await clearSessionFromSecureStore();
    // Keep biometric preference but clear session
    setUser(null);
    setSession(null);
  };

  return (
    <AuthContext.Provider value={{
      user,
      session,
      isAuthenticated: !!session,
      isLoading,
      biometricAvailable,
      biometricEnabled,
      logout,
      setSessionFromOTP,
      enableBiometric,
      disableBiometric,
      restoreSessionFromBiometric,
      refreshProfile,
    }}>
      {children}
    </AuthContext.Provider>
  );
}
