import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { I18nManager } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Language, translations, TranslationKey } from '@/constants/i18n';

interface LanguageContextType {
  language: Language;
  isRTL: boolean;
  t: (key: TranslationKey) => string;
  toggleLanguage: () => void;
  setLanguage: (lang: Language) => void;
}

export const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLangState] = useState<Language>('ar');

  useEffect(() => {
    AsyncStorage.getItem('tariq_language').then((saved) => {
      if (saved === 'ar' || saved === 'en') {
        setLangState(saved);
        I18nManager.forceRTL(saved === 'ar');
      } else {
        setLangState('ar');
        I18nManager.forceRTL(true);
      }
    });
  }, []);

  const setLanguage = async (lang: Language) => {
    await AsyncStorage.setItem('tariq_language', lang);
    I18nManager.forceRTL(lang === 'ar');
    setLangState(lang);
  };

  const toggleLanguage = () => {
    setLanguage(language === 'ar' ? 'en' : 'ar');
  };

  const t = (key: TranslationKey): string => {
    return translations[language][key] || translations['ar'][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, isRTL: language === 'ar', t, toggleLanguage, setLanguage }}>
      {children}
    </LanguageContext.Provider>
  );
}
