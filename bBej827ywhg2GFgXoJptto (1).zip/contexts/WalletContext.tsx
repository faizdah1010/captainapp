import React, { createContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { getSupabaseClient } from '@/template';
import { useContext } from 'react';
import { AuthContext } from '@/contexts/AuthContext';

export type TransactionType = 'credit' | 'debit' | 'refund' | 'topup';

export interface Transaction {
  id: string;
  type: TransactionType;
  amountJOD: number;
  titleAr: string;
  titleEn: string;
  descAr: string;
  descEn: string;
  date: string;
  icon: string;
}

interface WalletContextType {
  balanceJOD: number;
  referralCode: string;
  transactions: Transaction[];
  isLoading: boolean;
  addBalance: (amount: number) => Promise<void>;
  deductBalance: (amount: number, titleAr: string, titleEn: string, descAr?: string, descEn?: string) => Promise<boolean>;
  refreshWallet: () => Promise<void>;
}

export const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: ReactNode }) {
  const auth = useContext(AuthContext);
  const [balanceJOD, setBalanceJOD] = useState(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const supabase = getSupabaseClient();

  const referralCode = auth?.user?.referral_code ?? '';

  const fetchWallet = useCallback(async () => {
    if (!auth?.session?.user) return;
    setIsLoading(true);
    try {
      const userId = auth.session.user.id;

      // Fetch balance
      const { data: balData } = await supabase
        .from('wallet_balances')
        .select('balance_jod')
        .eq('user_id', userId)
        .single();

      if (balData) setBalanceJOD(Number(balData.balance_jod));

      // Fetch transactions
      const { data: txData } = await supabase
        .from('wallet_transactions')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(50);

      if (txData) {
        setTransactions(
          txData.map((tx: any) => ({
            id: tx.id,
            type: tx.type as TransactionType,
            amountJOD: Number(tx.amount_jod),
            titleAr: tx.title_ar,
            titleEn: tx.title_en,
            descAr: tx.desc_ar ?? '',
            descEn: tx.desc_en ?? '',
            date: new Date(tx.created_at).toLocaleDateString('ar-JO', {
              day: 'numeric', month: 'long', year: 'numeric',
            }),
            icon: tx.icon ?? 'account-balance-wallet',
          }))
        );
      }
    } catch (e) {
      console.error('fetchWallet error:', e);
    } finally {
      setIsLoading(false);
    }
  }, [auth?.session?.user?.id]);

  useEffect(() => {
    if (auth?.session?.user) {
      fetchWallet();
    } else {
      setBalanceJOD(0);
      setTransactions([]);
    }
  }, [auth?.session?.user?.id]);

  const addBalance = async (amount: number) => {
    if (!auth?.session?.user) return;
    const userId = auth.session.user.id;

    // Insert transaction
    await supabase.from('wallet_transactions').insert({
      user_id: userId,
      type: 'topup',
      amount_jod: amount,
      title_ar: 'شحن المحفظة',
      title_en: 'Wallet Top-up',
      desc_ar: `تعبئة رصيد ${amount.toFixed(2)} د.أ`,
      desc_en: `Top-up of ${amount.toFixed(2)} JOD`,
      icon: 'add-circle',
    });

    // Update balance
    await supabase
      .from('wallet_balances')
      .update({
        balance_jod: balanceJOD + amount,
        updated_at: new Date().toISOString(),
      })
      .eq('user_id', userId);

    await fetchWallet();
  };

  const deductBalance = async (
    amount: number,
    titleAr: string,
    titleEn: string,
    descAr?: string,
    descEn?: string
  ): Promise<boolean> => {
    if (!auth?.session?.user) return false;
    if (balanceJOD < amount) return false;
    const userId = auth.session.user.id;

    await supabase.from('wallet_transactions').insert({
      user_id: userId,
      type: 'debit',
      amount_jod: amount,
      title_ar: titleAr,
      title_en: titleEn,
      desc_ar: descAr ?? '',
      desc_en: descEn ?? '',
      icon: 'directions-car',
    });

    await supabase
      .from('wallet_balances')
      .update({
        balance_jod: balanceJOD - amount,
        updated_at: new Date().toISOString(),
      })
      .eq('user_id', userId);

    await fetchWallet();
    return true;
  };

  return (
    <WalletContext.Provider value={{
      balanceJOD,
      referralCode,
      transactions,
      isLoading,
      addBalance,
      deductBalance,
      refreshWallet: fetchWallet,
    }}>
      {children}
    </WalletContext.Provider>
  );
}
