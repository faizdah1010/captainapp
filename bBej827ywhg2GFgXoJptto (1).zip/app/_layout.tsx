import { AlertProvider } from '@/template';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { LanguageProvider } from '@/contexts/LanguageContext';
import { AuthProvider } from '@/contexts/AuthContext';
import { RideProvider } from '@/contexts/RideContext';
import { WalletProvider } from '@/contexts/WalletContext';
import { useNotifications } from '@/hooks/useNotifications';
import { useEffect, useContext } from 'react';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { AuthContext } from '@/contexts/AuthContext';
import { getSupabaseClient } from '@/template';

// ── Register Expo Push Token and save to user_profiles ──────────────────────
function PushTokenRegistrar() {
  const auth = useContext(AuthContext);
  useEffect(() => {
    if (!auth?.session?.user?.id) return;
    const register = async () => {
      if (!Device.isDevice) return;
      const { status } = await Notifications.getPermissionsAsync();
      if (status !== 'granted') return;
      try {
        const tokenData = await Notifications.getExpoPushTokenAsync();
        const token = tokenData.data;
        const supabase = getSupabaseClient();
        await supabase
          .from('user_profiles')
          .update({ push_token: token })
          .eq('id', auth.session.user.id);
        console.log('[PushToken] Saved for passenger:', auth.session.user.id);
      } catch (e) {
        console.warn('[PushToken] Failed:', e);
      }
    };
    register();
  }, [auth?.session?.user?.id]);
  return null;
}

function AppWithNotifications({ children }: { children: React.ReactNode }) {
  useNotifications();
  return <>{children}</>;
}

export default function RootLayout() {
  return (
    <AlertProvider>
      <SafeAreaProvider>
        <LanguageProvider>
          <AuthProvider>
            <RideProvider>
              <WalletProvider>
                <AppWithNotifications>
                  <PushTokenRegistrar />
                  <StatusBar style="light" backgroundColor="#0D0002" />
                  <Stack
                    screenOptions={{
                      headerShown: false,
                      contentStyle: { backgroundColor: '#0D0002' },
                      animation: 'fade_from_bottom',
                      animationDuration: 280,
                    }}
                  >
                    <Stack.Screen name="splash" options={{ animation: 'fade' }} />
                    <Stack.Screen name="index" options={{ animation: 'fade' }} />
                    <Stack.Screen name="login" options={{ animation: 'slide_from_right' }} />
                    <Stack.Screen name="(tabs)" options={{ animation: 'fade' }} />
                    <Stack.Screen name="booking" options={{ presentation: 'modal', animation: 'slide_from_bottom' }} />
                    <Stack.Screen name="tracking" options={{ animation: 'slide_from_right' }} />
                    <Stack.Screen name="wallet" options={{ animation: 'slide_from_right' }} />
                    <Stack.Screen name="admin" options={{ animation: 'slide_from_right' }} />
                  </Stack>
                </AppWithNotifications>
              </WalletProvider>
            </RideProvider>
          </AuthProvider>
        </LanguageProvider>
      </SafeAreaProvider>
    </AlertProvider>
  );
}
