import * as LocalAuthentication from 'expo-local-authentication';
import * as SecureStore from 'expo-secure-store';

const KEYS = {
  SESSION: 'tariq_session',
  BIOMETRIC_ENABLED: 'tariq_biometric_enabled',
  PHONE: 'tariq_last_phone',
};

// ── Device capability checks ─────────────────────────────────────────────────

export const isBiometricHardwareAvailable = async (): Promise<boolean> => {
  const compatible = await LocalAuthentication.hasHardwareAsync();
  const enrolled = await LocalAuthentication.isEnrolledAsync();
  return compatible && enrolled;
};

export type BiometricType = 'fingerprint' | 'face' | 'iris' | 'none';

export const getBiometricType = async (): Promise<BiometricType> => {
  const types = await LocalAuthentication.supportedAuthenticationTypesAsync();
  if (types.includes(LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION)) return 'face';
  if (types.includes(LocalAuthentication.AuthenticationType.FINGERPRINT)) return 'fingerprint';
  if (types.includes(LocalAuthentication.AuthenticationType.IRIS)) return 'iris';
  return 'none';
};

// ── Biometric authentication ─────────────────────────────────────────────────

export interface BiometricResult {
  success: boolean;
  error?: string;
}

export const authenticateWithBiometric = async (
  promptMessageAr = 'تحقق من هويتك للدخول',
  promptMessageEn = 'Authenticate to sign in'
): Promise<BiometricResult> => {
  try {
    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: promptMessageAr,
      fallbackLabel: 'استخدم رمز الجهاز',
      cancelLabel: 'إلغاء',
      disableDeviceFallback: false,
    });

    if (result.success) return { success: true };

    const errMap: Record<string, string> = {
      UserCancel: 'تم الإلغاء',
      UserFallback: 'تم الإلغاء',
      SystemCancel: 'تم الإلغاء من النظام',
      PasscodeNotSet: 'لم يتم تعيين رمز مرور',
      BiometryNotAvailable: 'البصمة غير متاحة',
      BiometryNotEnrolled: 'لم يتم تسجيل البصمة',
      BiometryLockout: 'البصمة مقفلة مؤقتاً',
    };

    return {
      success: false,
      error: errMap[result.error as string] ?? 'فشل التحقق',
    };
  } catch {
    return { success: false, error: 'خطأ في نظام البصمة' };
  }
};

// ── SecureStore helpers ───────────────────────────────────────────────────────

export const saveSessionToSecureStore = async (session: {
  access_token: string;
  refresh_token: string;
}): Promise<void> => {
  await SecureStore.setItemAsync(KEYS.SESSION, JSON.stringify(session));
};

export const getSessionFromSecureStore = async (): Promise<{
  access_token: string;
  refresh_token: string;
} | null> => {
  try {
    const raw = await SecureStore.getItemAsync(KEYS.SESSION);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
};

export const clearSessionFromSecureStore = async (): Promise<void> => {
  await SecureStore.deleteItemAsync(KEYS.SESSION).catch(() => {});
};

// ── Biometric preference ──────────────────────────────────────────────────────

export const setBiometricEnabled = async (enabled: boolean): Promise<void> => {
  await SecureStore.setItemAsync(KEYS.BIOMETRIC_ENABLED, enabled ? '1' : '0');
};

export const isBiometricEnabled = async (): Promise<boolean> => {
  const val = await SecureStore.getItemAsync(KEYS.BIOMETRIC_ENABLED);
  return val === '1';
};

// ── Last phone cache ──────────────────────────────────────────────────────────

export const saveLastPhone = async (phone: string): Promise<void> => {
  await SecureStore.setItemAsync(KEYS.PHONE, phone);
};

export const getLastPhone = async (): Promise<string> => {
  return (await SecureStore.getItemAsync(KEYS.PHONE)) ?? '';
};
