import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';

// ─── Notification Handler (foreground) ────────────────────────────────────────
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

// ─── Notification content definitions ─────────────────────────────────────────
export type NotificationEvent =
  | 'booking_accepted'
  | 'captain_arriving'
  | 'ride_started'
  | 'ride_completed';

interface NotificationContent {
  titleAr: string;
  bodyAr: string;
  titleEn: string;
  bodyEn: string;
  data?: Record<string, unknown>;
}

const NOTIFICATION_TEMPLATES: Record<NotificationEvent, NotificationContent> = {
  booking_accepted: {
    titleAr: '✅ تم قبول حجزك!',
    bodyAr: 'تم العثور على كابتن. سيصل إليك قريباً.',
    titleEn: '✅ Booking Accepted!',
    bodyEn: 'A captain has been found and is on the way.',
    data: { event: 'booking_accepted' },
  },
  captain_arriving: {
    titleAr: '🚗 الكابتن في الطريق إليك',
    bodyAr: 'تتبّع موقع الكابتن على الخريطة الآن.',
    titleEn: '🚗 Captain is On the Way',
    bodyEn: 'Track your captain live on the map.',
    data: { event: 'captain_arriving' },
  },
  ride_started: {
    titleAr: '🛣️ بدأت رحلتك!',
    bodyAr: 'استمتع برحلة آمنة وفاخرة مع طريق.',
    titleEn: '🛣️ Your Ride Has Started!',
    bodyEn: 'Enjoy a safe and luxurious ride with Tariq.',
    data: { event: 'ride_started' },
  },
  ride_completed: {
    titleAr: '🏁 وصلت إلى وجهتك!',
    bodyAr: 'شكراً لاستخدامك طريق. قيّم رحلتك الآن.',
    titleEn: '🏁 You Have Arrived!',
    bodyEn: 'Thank you for riding with Tariq. Rate your trip!',
    data: { event: 'ride_completed' },
  },
};

// ─── Permission Request ────────────────────────────────────────────────────────
export async function requestNotificationPermissions(): Promise<boolean> {
  if (!Device.isDevice && Platform.OS !== 'web') {
    // Simulators/emulators still allow local notifications test
    console.log('[Notifications] Running on simulator — local notifications supported');
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('tariq-rides', {
      name: 'Tariq Rides',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#C9A84C',
      sound: 'default',
    });
    await Notifications.setNotificationChannelAsync('tariq-updates', {
      name: 'Tariq Updates',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 150],
      lightColor: '#C9A84C',
      sound: 'default',
    });
  }

  return finalStatus === 'granted';
}

// ─── Send Local Notification ───────────────────────────────────────────────────
export async function sendRideNotification(
  event: NotificationEvent,
  language: 'ar' | 'en',
  delaySeconds = 0
): Promise<string | null> {
  try {
    const template = NOTIFICATION_TEMPLATES[event];
    const title = language === 'ar' ? template.titleAr : template.titleEn;
    const body = language === 'ar' ? template.bodyAr : template.bodyEn;

    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        data: template.data ?? {},
        sound: 'default',
        ...(Platform.OS === 'android' && { channelId: 'tariq-rides' }),
      },
      trigger: delaySeconds > 0
        ? { type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL, seconds: delaySeconds }
        : null,
    });

    return id;
  } catch (err) {
    console.warn('[Notifications] Failed to schedule:', err);
    return null;
  }
}

// ─── Cancel All Pending ────────────────────────────────────────────────────────
export async function cancelAllNotifications(): Promise<void> {
  await Notifications.cancelAllScheduledNotificationsAsync();
}

// ─── Clear Badge ───────────────────────────────────────────────────────────────
export async function clearBadge(): Promise<void> {
  await Notifications.setBadgeCountAsync(0);
}
