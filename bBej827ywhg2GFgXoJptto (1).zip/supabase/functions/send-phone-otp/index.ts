import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

const hashOTP = async (otp: string): Promise<string> => {
  const encoder = new TextEncoder();
  const data = encoder.encode(otp);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const { phone } = await req.json();
    if (!phone) {
      return new Response(JSON.stringify({ error: 'رقم الهاتف مطلوب' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Normalize phone: ensure +962 format
    let normalized = phone.toString().trim();
    if (normalized.startsWith('07')) {
      normalized = '+962' + normalized.slice(1);
    } else if (normalized.startsWith('962')) {
      normalized = '+' + normalized;
    } else if (!normalized.startsWith('+')) {
      normalized = '+962' + normalized;
    }

    const otp = generateOTP();
    const otpHash = await hashOTP(otp);
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString(); // 10 minutes

    // Store OTP in DB
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Invalidate old OTPs for this phone
    await supabase
      .from('phone_otps')
      .update({ used: true })
      .eq('phone', normalized)
      .eq('used', false);

    // Insert new OTP
    const { error: insertError } = await supabase.from('phone_otps').insert({
      phone: normalized,
      otp_hash: otpHash,
      expires_at: expiresAt,
    });

    if (insertError) {
      console.error('DB insert error:', insertError);
      return new Response(JSON.stringify({ error: 'خطأ في قاعدة البيانات' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Send via Twilio SMS
    const accountSid = Deno.env.get('TWILIO_ACCOUNT_SID');
    const authToken = Deno.env.get('TWILIO_AUTH_TOKEN');
    const smsFrom = Deno.env.get('TWILIO_PHONE_NUMBER');

    if (!accountSid || !authToken || !smsFrom) {
      console.error('Twilio credentials missing');
      return new Response(JSON.stringify({ error: 'إعداد خدمة SMS غير مكتمل' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const messageBody =
      `Tariq - طريقي\n` +
      `رمز التحقق: ${otp}\n` +
      `OTP: ${otp}\n` +
      `صالح 10 دقائق. لا تشاركه.`;

    const twilioResponse = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: 'Basic ' + btoa(`${accountSid}:${authToken}`),
        },
        body: new URLSearchParams({
          To: normalized,
          From: smsFrom,
          Body: messageBody,
        }),
      }
    );

    if (!twilioResponse.ok) {
      const errText = await twilioResponse.text();
      console.error('Twilio SMS error:', errText);
      return new Response(JSON.stringify({ error: 'فشل إرسال رسالة SMS' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ success: true, phone: normalized }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    console.error('send-phone-otp error:', err);
    return new Response(JSON.stringify({ error: 'حدث خطأ غير متوقع' }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
