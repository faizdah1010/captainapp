import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_ANON_KEY") ?? ""
  );

  try {
    // Authenticate user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("No authorization header");
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userErr } = await supabase.auth.getUser(token);
    if (userErr || !user?.email) throw new Error("User not authenticated");

    // Parse request body
    const { amount_jod } = await req.json();
    if (!amount_jod || isNaN(Number(amount_jod)) || Number(amount_jod) <= 0) {
      throw new Error("Invalid amount");
    }

    const amountNum = Number(amount_jod);
    if (amountNum > 500) throw new Error("Maximum top-up amount is 500 JOD");

    // Convert JOD to fils (1 JOD = 1000 fils; Stripe uses smallest unit)
    // Stripe requires integer in smallest currency unit
    // For JOD: 1 JOD = 1000 fils — but Stripe treats JOD as zero-decimal currency
    // Actually JOD is NOT zero-decimal in Stripe; it uses 3 decimal places
    // Stripe represents JOD in fils (1/1000 JOD)
    const amountFils = Math.round(amountNum * 1000);

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") ?? "", {
      apiVersion: "2025-08-27.basil",
    });

    // Find or note existing Stripe customer
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });
    const customerId = customers.data.length > 0 ? customers.data[0].id : undefined;

    // Create Stripe Checkout Session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      customer_email: customerId ? undefined : user.email,
      line_items: [
        {
          price_data: {
            currency: "jod",
            product_data: {
              name: "شحن محفظة طريقي",
              description: `إضافة ${amountNum.toFixed(3)} دينار أردني إلى محفظتك`,
            },
            unit_amount: amountFils,
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `tariqyapp://payment/success?amount=${amountNum}&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `tariqyapp://payment/cancel`,
      metadata: {
        user_id: user.id,
        amount_jod: String(amountNum),
        type: "wallet_topup",
      },
    });

    console.log(`Stripe session created: ${session.id} for user ${user.id}, amount ${amountNum} JOD`);

    return new Response(
      JSON.stringify({ url: session.url, session_id: session.id }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
    );
  } catch (error) {
    console.error("create-wallet-topup error:", error.message);
    return new Response(
      JSON.stringify({ error: error.message }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
    );
  }
});
