/**
 * Edge Function: send-push-notification
 * Sends real Expo Push Notifications to passengers or captains.
 * Called server-side when ride events occur.
 */
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const EXPO_PUSH_URL = "https://exp.host/--/api/v2/push/send";

interface PushPayload {
  to: string;
  title: string;
  body: string;
  data?: Record<string, any>;
  sound?: string;
  badge?: number;
  channelId?: string;
}

async function sendExpoPush(messages: PushPayload[]) {
  const res = await fetch(EXPO_PUSH_URL, {
    method: "POST",
    headers: {
      "Accept": "application/json",
      "Accept-Encoding": "gzip, deflate",
      "Content-Type": "application/json",
    },
    body: JSON.stringify(messages),
  });
  return res.json();
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  try {
    const body = await req.json();
    const {
      target_type,  // 'passenger' | 'captain' | 'token'
      target_id,    // user_id or captain phone or direct token
      title,
      message,
      data,
    } = body;

    let pushToken: string | null = null;

    if (target_type === "passenger") {
      // Fetch passenger push token
      const { data: profile } = await supabase
        .from("user_profiles")
        .select("push_token")
        .eq("id", target_id)
        .single();
      pushToken = profile?.push_token ?? null;

    } else if (target_type === "captain") {
      // target_id = captain_profiles.id or phone
      const { data: profile } = await supabase
        .from("captain_profiles")
        .select("push_token")
        .eq("id", target_id)
        .single();
      pushToken = profile?.push_token ?? null;

    } else if (target_type === "token") {
      pushToken = target_id;
    }

    if (!pushToken) {
      console.log(`No push token found for ${target_type} ${target_id}`);
      return new Response(
        JSON.stringify({ success: false, reason: "no_token" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
      );
    }

    // Validate Expo push token
    if (!pushToken.startsWith("ExponentPushToken[") && !pushToken.startsWith("ExpoPushToken[")) {
      console.log(`Invalid push token: ${pushToken}`);
      return new Response(
        JSON.stringify({ success: false, reason: "invalid_token" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
      );
    }

    const payload: PushPayload = {
      to: pushToken,
      title,
      body: message,
      sound: "default",
      data: data ?? {},
      badge: 1,
    };

    const result = await sendExpoPush([payload]);
    console.log("Expo push result:", JSON.stringify(result));

    return new Response(
      JSON.stringify({ success: true, result }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
    );

  } catch (error) {
    console.error("send-push-notification error:", error.message);
    return new Response(
      JSON.stringify({ error: error.message }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
    );
  }
});
