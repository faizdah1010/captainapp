import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

const hashOTP = async (otp: string): Promise<string> => {
  const encoder = new TextEncoder();
  const data = encoder.encode(otp);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
};

const normalizePhone = (phone: string): string => {
  let p = phone.toString().trim().replace(/\s/g, '');
  if (p.startsWith('07')) return '+962' + p.slice(1);
  if (p.startsWith('962')) return '+' + p;
  if (!p.startsWith('+')) return '+962' + p;
  return p;
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const { phone, otp } = await req.json();
    if (!phone || !otp) {
      return new Response(JSON.stringify({ error: 'رقم الهاتف والرمز مطلوبان' }), {
        status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const normalized = normalizePhone(phone);
    const otpHash = await hashOTP(otp.toString().trim());

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // 1. Verify OTP
    const { data: otpRecords, error: fetchError } = await supabaseAdmin
      .from('phone_otps')
      .select('*')
      .eq('phone', normalized)
      .eq('otp_hash', otpHash)
      .eq('used', false)
      .gt('expires_at', new Date().toISOString())
      .order('created_at', { ascending: false })
      .limit(1);

    if (fetchError || !otpRecords || otpRecords.length === 0) {
      return new Response(JSON.stringify({ error: 'رمز التحقق غير صحيح أو منتهي الصلاحية' }), {
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // 2. Mark OTP used
    await supabaseAdmin.from('phone_otps').update({ used: true }).eq('id', otpRecords[0].id);

    // 3. Derive a stable email and password from the phone number
    const stableEmail = `${normalized.replace('+', '')}@tariq-user.app`;
    const stablePassword = await hashOTP(normalized + 'tariq_salt_2025');

    // 4. Try signing in first (existing user)
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );

    const { data: signInData, error: signInError } = await supabaseClient.auth.signInWithPassword({
      email: stableEmail,
      password: stablePassword,
    });

    if (!signInError && signInData.session) {
      // Existing user signed in
      return new Response(JSON.stringify({
        success: true,
        isNewUser: false,
        session: signInData.session,
        user: signInData.user,
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // 5. Create new user
    const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email: stableEmail,
      password: stablePassword,
      email_confirm: true,
      user_metadata: { phone: normalized },
    });

    if (createError) {
      console.error('Create user error:', createError);
      return new Response(JSON.stringify({ error: 'خطأ في إنشاء الحساب' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Wait for trigger to fire (creates profile + wallet)
    await new Promise((r) => setTimeout(r, 800));

    // Update profile with phone
    await supabaseAdmin
      .from('user_profiles')
      .update({ phone: normalized, phone_verified: true })
      .eq('id', newUser.user!.id);

    // Sign in the new user
    const { data: newSession, error: newSignInError } = await supabaseClient.auth.signInWithPassword({
      email: stableEmail,
      password: stablePassword,
    });

    if (newSignInError || !newSession.session) {
      console.error('New user sign-in error:', newSignInError);
      return new Response(JSON.stringify({ error: 'خطأ في تسجيل الدخول' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({
      success: true,
      isNewUser: true,
      session: newSession.session,
      user: newSession.user,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (err) {
    console.error('verify-phone-otp error:', err);
    return new Response(JSON.stringify({ error: 'حدث خطأ غير متوقع' }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
