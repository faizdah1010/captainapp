import { useEffect, useRef, useCallback } from 'react';
import * as Notifications from 'expo-notifications';
import {
  requestNotificationPermissions,
  sendRideNotification,
  cancelAllNotifications,
  clearBadge,
  type NotificationEvent,
} from '@/services/notificationService';

export interface UseNotificationsReturn {
  sendNotification: (event: NotificationEvent, language: 'ar' | 'en', delaySeconds?: number) => Promise<void>;
  cancelAll: () => Promise<void>;
}

export function useNotifications(): UseNotificationsReturn {
  const notificationListener = useRef<Notifications.EventSubscription | null>(null);
  const responseListener = useRef<Notifications.EventSubscription | null>(null);
  const permissionGranted = useRef(false);

  // Request permissions on mount
  useEffect(() => {
    (async () => {
      permissionGranted.current = await requestNotificationPermissions();
    })();

    // Listen for incoming notifications (while app is foregrounded)
    notificationListener.current = Notifications.addNotificationReceivedListener((notification) => {
      console.log('[Notifications] Received:', notification.request.content.title);
    });

    // Listen for user tapping a notification
    responseListener.current = Notifications.addNotificationResponseReceivedListener((response) => {
      const event = response.notification.request.content.data?.event as string | undefined;
      console.log('[Notifications] Tapped:', event);
      // Deep-link handling can be wired here if needed
    });

    return () => {
      notificationListener.current?.remove();
      responseListener.current?.remove();
      clearBadge();
    };
  }, []);

  const sendNotification = useCallback(
    async (event: NotificationEvent, language: 'ar' | 'en', delaySeconds = 0) => {
      await sendRideNotification(event, language, delaySeconds);
    },
    []
  );

  const cancelAll = useCallback(async () => {
    await cancelAllNotifications();
  }, []);

  return { sendNotification, cancelAll };
}
