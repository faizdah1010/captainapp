// Tariq Captain App — Royal Red Theme (same brand, simpler layout)

export const Colors = {
  background: '#0D0002',
  surface: '#160004',
  surfaceCard: '#1A0005',
  surfaceElevated: '#200008',
  border: '#3A0010',
  borderGold: '#C9A84C44',

  primary: '#CC1020',
  primaryLight: '#E8182A',
  red: '#CC1020',
  redLight: '#E8182A',
  redDim: '#8B0010',
  redFaint: '#CC102018',
  redMedium: '#CC102035',

  gold: '#C9A84C',
  goldLight: '#E8C96A',
  goldFaint: '#C9A84C18',

  green: '#22C55E',
  greenFaint: '#22C55E18',
  greenDim: '#16A34A',

  textPrimary: '#F5F0E8',
  textSecondary: '#C4A8B0',
  textMuted: '#7A5060',
  textOnRed: '#FFFFFF',
  textOnGold: '#1A0005',
  textOnGreen: '#FFFFFF',

  success: '#22C55E',
  error: '#FF4444',
  warning: '#E8A030',

  overlay: 'rgba(10,0,2,0.82)',
};

export const Spacing = {
  xs: 4, sm: 8, md: 12, base: 16, lg: 20, xl: 24, xxl: 32, xxxl: 48,
};

export const Typography = {
  sizes: { xs: 11, sm: 13, md: 15, base: 16, lg: 18, xl: 20, xxl: 24, xxxl: 30, hero: 40 },
  weights: {
    regular: '400' as const,
    medium: '500' as const,
    semiBold: '600' as const,
    bold: '700' as const,
    extraBold: '800' as const,
  },
};

export const Radius = { sm: 8, md: 12, lg: 16, xl: 20, xxl: 28, full: 999 };

export const Shadows = {
  red: { shadowColor: '#CC1020', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.45, shadowRadius: 16, elevation: 10 },
  green: { shadowColor: '#22C55E', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.35, shadowRadius: 12, elevation: 8 },
  gold: { shadowColor: '#C9A84C', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 8 },
  card: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.5, shadowRadius: 8, elevation: 5 },
};
