// Captain push notification service — local alerts + real Expo push tokens
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL ?? 'https://isvxscoyczqjyyzxisvx.backend.onspace.ai';
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

/** Request notification permission + register Android channels */
export async function requestNotificationPermission(): Promise<boolean> {
  if (!Device.isDevice) return false;
  const { status: existing } = await Notifications.getPermissionsAsync();
  let finalStatus = existing;
  if (existing !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }
  if (finalStatus !== 'granted') return false;

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('ride-requests', {
      name: 'طلبات الرحلات',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#CC1020',
      sound: 'default',
    });
    await Notifications.setNotificationChannelAsync('ride-status', {
      name: 'حالة الرحلة',
      importance: Notifications.AndroidImportance.HIGH,
      lightColor: '#CC1020',
      sound: 'default',
    });
  }
  return true;
}

/**
 * Get the real Expo Push Token for this device
 * Returns null if running on simulator or permission denied
 */
export async function getExpoPushToken(): Promise<string | null> {
  if (!Device.isDevice) {
    console.log('[Notifications] Not a physical device — push tokens unavailable');
    return null;
  }

  try {
    const { status } = await Notifications.getPermissionsAsync();
    if (status !== 'granted') return null;

    const tokenData = await Notifications.getExpoPushTokenAsync({
      projectId: 'tariq-captain-001', // matches app.json extra.eas.projectId
    });
    return tokenData.data;
  } catch (e) {
    console.warn('[Notifications] Could not get push token:', e);
    return null;
  }
}

/**
 * Save the Expo Push Token to Supabase captain_profiles
 * Called after captain logs in and phone is known
 */
export async function savePushToken(captainPhone: string, sessionToken: string): Promise<void> {
  const pushToken = await getExpoPushToken();
  if (!pushToken) return;

  try {
    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: `Bearer ${sessionToken}` } },
    });
    await supabase
      .from('captain_profiles')
      .update({ push_token: pushToken })
      .eq('phone', captainPhone);

    console.log('[Notifications] Push token saved for captain:', captainPhone);
  } catch (e) {
    console.warn('[Notifications] Failed to save push token:', e);
  }
}

/** Show a local notification for a new ride request */
export async function notifyNewRideRequest(fromName: string, toName: string, priceJod: number) {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: '🚗 طلب رحلة جديد!',
      body: `${fromName} ← ${toName}  |  ${priceJod.toFixed(3)} د.أ`,
      sound: 'default',
      data: { type: 'new_request' },
      ...(Platform.OS === 'android' ? { channelId: 'ride-requests' } : {}),
    },
    trigger: null,
  });
}

/** Show a local notification for ride status change */
export async function notifyRideStatus(title: string, body: string) {
  await Notifications.scheduleNotificationAsync({
    content: {
      title,
      body,
      sound: 'default',
      data: { type: 'ride_status' },
      ...(Platform.OS === 'android' ? { channelId: 'ride-status' } : {}),
    },
    trigger: null,
  });
}

/** Clear app badge */
export async function clearBadge() {
  await Notifications.setBadgeCountAsync(0);
}
