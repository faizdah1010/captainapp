// Captain GPS location service — updates captain_profiles every 10s when online
import * as Location from 'expo-location';
import { getSupabase } from '@/contexts/CaptainAuthContext';

let _watchSub: Location.LocationSubscription | null = null;
let _intervalId: ReturnType<typeof setInterval> | null = null;

export async function startLocationTracking(captainId: string): Promise<boolean> {
  const { status } = await Location.requestForegroundPermissionsAsync();
  if (status !== 'granted') return false;

  stopLocationTracking();

  // Get initial position immediately
  try {
    const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    await updateCaptainLocation(captainId, loc.coords.latitude, loc.coords.longitude);
  } catch {}

  // Watch position and update DB every 10 seconds
  let lastUpdateTime = 0;
  _watchSub = await Location.watchPositionAsync(
    {
      accuracy: Location.Accuracy.Balanced,
      timeInterval: 5000,
      distanceInterval: 10,
    },
    async (loc) => {
      const now = Date.now();
      if (now - lastUpdateTime >= 10000) {
        lastUpdateTime = now;
        await updateCaptainLocation(captainId, loc.coords.latitude, loc.coords.longitude);
      }
    }
  );

  return true;
}

export function stopLocationTracking() {
  if (_watchSub) {
    _watchSub.remove();
    _watchSub = null;
  }
  if (_intervalId) {
    clearInterval(_intervalId);
    _intervalId = null;
  }
}

async function updateCaptainLocation(captainId: string, lat: number, lng: number) {
  const supabase = getSupabase();
  await supabase
    .from('captain_profiles')
    .update({ current_lat: lat, current_lng: lng })
    .eq('id', captainId);
}

export async function getCurrentLocation(): Promise<{ lat: number; lng: number } | null> {
  try {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') return null;
    const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    return { lat: loc.coords.latitude, lng: loc.coords.longitude };
  } catch {
    return null;
  }
}
