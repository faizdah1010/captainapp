import React, { useEffect, useRef } from 'react';
import { View, StyleSheet } from 'react-native';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import { Colors } from '@/constants/theme';
import { RideRequest } from '@/contexts/RideContext';

interface CaptainMapProps {
  activeRide: RideRequest | null;
  captainLat?: number;
  captainLng?: number;
}

export default function CaptainMap({ activeRide, captainLat, captainLng }: CaptainMapProps) {
  const mapRef = useRef<MapView>(null);

  // Default center: Amman, Jordan
  const defaultLat = 31.9539;
  const defaultLng = 35.9106;

  const capLat = captainLat ?? defaultLat;
  const capLng = captainLng ?? defaultLng;

  useEffect(() => {
    if (!mapRef.current || !activeRide) return;
    const coords = [
      { latitude: capLat, longitude: capLng },
      { latitude: Number(activeRide.from_lat), longitude: Number(activeRide.from_lng) },
      { latitude: Number(activeRide.to_lat), longitude: Number(activeRide.to_lng) },
    ];
    mapRef.current.fitToCoordinates(coords, {
      edgePadding: { top: 60, right: 40, bottom: 60, left: 40 },
      animated: true,
    });
  }, [activeRide?.id, capLat, capLng]);

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        style={styles.map}
        provider={PROVIDER_GOOGLE}
        initialRegion={{
          latitude: activeRide ? Number(activeRide.from_lat) : defaultLat,
          longitude: activeRide ? Number(activeRide.from_lng) : defaultLng,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        }}
        customMapStyle={darkMapStyle}
        showsUserLocation={false}
        showsTraffic={false}
      >
        {/* Captain position */}
        <Marker
          coordinate={{ latitude: capLat, longitude: capLng }}
          title="موقعك"
          anchor={{ x: 0.5, y: 0.5 }}
        >
          <View style={styles.captainMarker}>
            <View style={styles.captainDot} />
          </View>
        </Marker>

        {activeRide ? (
          <>
            {/* Pickup marker */}
            <Marker
              coordinate={{ latitude: Number(activeRide.from_lat), longitude: Number(activeRide.from_lng) }}
              title="نقطة الانطلاق"
              description={activeRide.from_name}
            >
              <View style={styles.pickupMarker}>
                <View style={styles.pickupDot} />
              </View>
            </Marker>

            {/* Dropoff marker */}
            <Marker
              coordinate={{ latitude: Number(activeRide.to_lat), longitude: Number(activeRide.to_lng) }}
              title="الوجهة"
              description={activeRide.to_name}
            >
              <View style={styles.dropoffMarker}>
                <View style={styles.dropoffDot} />
              </View>
            </Marker>

            {/* Route line: captain → pickup */}
            <Polyline
              coordinates={[
                { latitude: capLat, longitude: capLng },
                { latitude: Number(activeRide.from_lat), longitude: Number(activeRide.from_lng) },
              ]}
              strokeColor={Colors.gold}
              strokeWidth={3}
              lineDashPattern={[6, 4]}
            />

            {/* Route line: pickup → dropoff */}
            <Polyline
              coordinates={[
                { latitude: Number(activeRide.from_lat), longitude: Number(activeRide.from_lng) },
                { latitude: Number(activeRide.to_lat), longitude: Number(activeRide.to_lng) },
              ]}
              strokeColor={Colors.red}
              strokeWidth={3}
            />
          </>
        ) : null}
      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, overflow: 'hidden' },
  map: { flex: 1 },

  captainMarker: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: Colors.red + '30',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: Colors.red,
  },
  captainDot: {
    width: 14, height: 14, borderRadius: 7,
    backgroundColor: Colors.red,
  },

  pickupMarker: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: Colors.green + '30',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: Colors.green,
  },
  pickupDot: {
    width: 12, height: 12, borderRadius: 6,
    backgroundColor: Colors.green,
  },

  dropoffMarker: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: Colors.gold + '30',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: Colors.gold,
  },
  dropoffDot: {
    width: 12, height: 12, borderRadius: 6,
    backgroundColor: Colors.gold,
  },
});

const darkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#1a0005' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#c4a8b0' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#0d0002' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#3a0010' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#5a0018' }] },
  { featureType: 'road', elementType: 'labels.text.fill', stylers: [{ color: '#7a5060' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#0d0010' }] },
  { featureType: 'poi', stylers: [{ visibility: 'off' }] },
  { featureType: 'transit', stylers: [{ visibility: 'off' }] },
  { featureType: 'administrative', elementType: 'geometry.stroke', stylers: [{ color: '#3a0010' }] },
];
