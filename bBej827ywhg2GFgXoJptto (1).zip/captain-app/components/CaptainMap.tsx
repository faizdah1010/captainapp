import { View, Text, StyleSheet } from 'react-native';
import { Colors, Typography, Spacing } from '@/constants/theme';

// Web fallback for captain map
export default function CaptainMap({ activeRide, captainLat, captainLng }: {
  activeRide: any;
  captainLat?: number;
  captainLng?: number;
}) {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>
        {activeRide ? `${activeRide.from_name} ← ${activeRide.to_name}` : 'الخريطة متاحة على الجوال'}
      </Text>
      {captainLat ? (
        <Text style={styles.coords}>{captainLat.toFixed(4)}, {captainLng?.toFixed(4)}</Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1, backgroundColor: '#160004',
    alignItems: 'center', justifyContent: 'center', gap: Spacing.sm,
  },
  text: { color: Colors.textMuted, fontSize: Typography.sizes.sm, textAlign: 'center', paddingHorizontal: Spacing.xl },
  coords: { color: Colors.textMuted, fontSize: Typography.sizes.xs },
});
