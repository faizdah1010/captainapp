import React, { createContext, useState, useCallback, useContext, ReactNode, useRef, useEffect } from 'react';
import { getSupabase } from './CaptainAuthContext';
import { CaptainAuthContext } from './CaptainAuthContext';
import { notifyNewRideRequest, requestNotificationPermission } from '@/services/notificationService';
import { startLocationTracking, stopLocationTracking, getCurrentLocation } from '@/services/locationService';

export interface RideRequest {
  id: string;
  passenger_id: string;
  passenger_name: string | null;
  passenger_phone: string | null;
  passenger_rating: number | null;
  service: 'regular' | 'ladies' | 'express';
  from_name: string;
  from_name_en: string | null;
  from_lat: number;
  from_lng: number;
  to_name: string;
  to_name_en: string | null;
  to_lat: number;
  to_lng: number;
  price_jod: number;
  discount_pct: number;
  status: 'pending' | 'accepted' | 'rejected' | 'cancelled' | 'inProgress' | 'completed';
  created_at: string;
  accepted_at: string | null;
}

interface RideContextType {
  pendingRequests: RideRequest[];
  activeRide: RideRequest | null;
  isLoadingRequests: boolean;
  completedTrips: RideRequest[];
  captainLocation: { lat: number; lng: number } | null;
  acceptRide: (rideId: string) => Promise<void>;
  rejectRide: (rideId: string) => Promise<void>;
  startRide: (rideId: string) => Promise<void>;
  completeRide: (rideId: string) => Promise<void>;
  fetchHistory: () => Promise<void>;
  refreshRequests: () => Promise<void>;
}

export const RideContext = createContext<RideContextType | undefined>(undefined);

export function useRide() {
  const ctx = useContext(RideContext);
  if (!ctx) throw new Error('useRide must be inside RideProvider');
  return ctx;
}

const POLL_MS = 4000;

export function RideProvider({ children }: { children: ReactNode }) {
  const auth = useContext(CaptainAuthContext);
  const supabase = getSupabase();

  const [pendingRequests, setPendingRequests] = useState<RideRequest[]>([]);
  const [activeRide, setActiveRide] = useState<RideRequest | null>(null);
  const [completedTrips, setCompletedTrips] = useState<RideRequest[]>([]);
  const [isLoadingRequests, setIsLoadingRequests] = useState(false);
  const [captainLocation, setCaptainLocation] = useState<{ lat: number; lng: number } | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  // Track IDs we've already notified about to avoid duplicate alerts
  const notifiedIdsRef = useRef<Set<string>>(new Set());

  const refreshRequests = useCallback(async () => {
    if (!auth?.captain?.is_online || !auth.captain) return;
    const cap = auth.captain;

    // Active ride for this captain
    const { data: active } = await supabase
      .from('ride_requests')
      .select('*')
      .eq('captain_id', cap.id)
      .in('status', ['accepted', 'inProgress'])
      .order('accepted_at', { ascending: false })
      .limit(1)
      .single();
    setActiveRide(active as RideRequest | null);

    // Pending requests matching captain's service types
    if (!active) {
      const { data: pending } = await supabase
        .from('ride_requests')
        .select('*')
        .eq('status', 'pending')
        .is('captain_id', null)
        .in('service', cap.service_types)
        .order('created_at', { ascending: true });

      const requests = (pending as RideRequest[]) ?? [];
      setPendingRequests(requests);

      // Notify captain about new requests they haven't seen yet
      for (const req of requests) {
        if (!notifiedIdsRef.current.has(req.id)) {
          notifiedIdsRef.current.add(req.id);
          // Only notify if this request is new (created within last 30 seconds)
          const ageMs = Date.now() - new Date(req.created_at).getTime();
          if (ageMs < 30000) {
            notifyNewRideRequest(req.from_name, req.to_name, Number(req.price_jod)).catch(() => {});
          }
        }
      }
    } else {
      setPendingRequests([]);
    }
  }, [auth?.captain?.id, auth?.captain?.is_online]);

  // Start/stop polling + GPS tracking when online status changes
  useEffect(() => {
    const cap = auth?.captain;
    if (!cap?.is_online) {
      if (pollRef.current) clearInterval(pollRef.current);
      stopLocationTracking();
      setPendingRequests([]);
      setActiveRide(null);
      return;
    }

    // Start GPS tracking
    requestNotificationPermission().catch(() => {});
    startLocationTracking(cap.id).then((ok) => {
      if (!ok) {
        // Fallback: get current position once
        getCurrentLocation().then((loc) => {
          if (loc) setCaptainLocation(loc);
        });
      }
    });

    // Get initial location for map display
    getCurrentLocation().then((loc) => {
      if (loc) setCaptainLocation(loc);
    });

    refreshRequests();
    pollRef.current = setInterval(refreshRequests, POLL_MS);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
      stopLocationTracking();
    };
  }, [auth?.captain?.is_online, auth?.captain?.id, refreshRequests]);

  // Update local captainLocation state from captain_profiles periodically
  useEffect(() => {
    if (!auth?.captain?.is_online || !auth.captain) return;
    const capId = auth.captain.id;
    const timer = setInterval(async () => {
      const { data } = await supabase
        .from('captain_profiles')
        .select('current_lat, current_lng')
        .eq('id', capId)
        .single();
      if (data?.current_lat && data?.current_lng) {
        setCaptainLocation({ lat: Number(data.current_lat), lng: Number(data.current_lng) });
      }
    }, 10000);
    return () => clearInterval(timer);
  }, [auth?.captain?.is_online, auth?.captain?.id]);

  const acceptRide = useCallback(async (rideId: string) => {
    if (!auth?.captain) return;
    const { data: rideData } = await supabase
      .from('ride_requests')
      .update({
        captain_id: auth.captain.id,
        status: 'accepted',
        accepted_at: new Date().toISOString(),
      })
      .eq('id', rideId)
      .eq('status', 'pending')
      .select('passenger_id')
      .single();

    // Send real push notification to passenger
    if (rideData?.passenger_id) {
      try {
        await supabase.functions.invoke('send-push-notification', {
          body: {
            target_type: 'passenger',
            target_id: rideData.passenger_id,
            title: '🚗 تم قبول طلبك!',
            message: `الكابتن ${auth.captain.name_ar} في طريقه إليك`,
            data: { type: 'ride_accepted', ride_id: rideId },
          },
        });
      } catch (e) {
        console.warn('[Push] Failed to notify passenger:', e);
      }
    }

    await refreshRequests();
  }, [auth?.captain?.id, auth?.captain?.name_ar, refreshRequests]);

  const rejectRide = useCallback(async (rideId: string) => {
    await supabase
      .from('ride_requests')
      .update({ status: 'rejected' })
      .eq('id', rideId);
    // Remove from notified set so it won't re-notify
    notifiedIdsRef.current.delete(rideId);
    await refreshRequests();
  }, [refreshRequests]);

  const startRide = useCallback(async (rideId: string) => {
    await supabase
      .from('ride_requests')
      .update({ status: 'inProgress' })
      .eq('id', rideId);
    await refreshRequests();
  }, [refreshRequests]);

  const completeRide = useCallback(async (rideId: string) => {
    await supabase
      .from('ride_requests')
      .update({ status: 'completed', completed_at: new Date().toISOString() })
      .eq('id', rideId);

    // Increment captain's trip counter
    if (auth?.captain) {
      await supabase
        .from('captain_profiles')
        .update({ total_trips: (auth.captain.total_trips ?? 0) + 1 })
        .eq('id', auth.captain.id);
    }
    setActiveRide(null);
    await refreshRequests();
    await fetchHistory();
  }, [auth?.captain, refreshRequests]);

  const fetchHistory = useCallback(async () => {
    if (!auth?.captain) return;
    setIsLoadingRequests(true);
    const { data } = await supabase
      .from('ride_requests')
      .select('*')
      .eq('captain_id', auth.captain.id)
      .eq('status', 'completed')
      .order('completed_at', { ascending: false })
      .limit(30);
    setCompletedTrips((data as RideRequest[]) ?? []);
    setIsLoadingRequests(false);
  }, [auth?.captain?.id]);

  return (
    <RideContext.Provider value={{
      pendingRequests, activeRide, isLoadingRequests, completedTrips,
      captainLocation,
      acceptRide, rejectRide, startRide, completeRide, fetchHistory, refreshRequests,
    }}>
      {children}
    </RideContext.Provider>
  );
}
