import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { createClient, SupabaseClient, Session } from '@supabase/supabase-js';
import * as SecureStore from 'expo-secure-store';
import { savePushToken } from '@/services/notificationService';

// ── Supabase config — reads from .env (same backend as passenger app) ──────────
const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL ?? 'https://isvxscoyczqjyyzxisvx.backend.onspace.ai';
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '';

let _client: SupabaseClient | null = null;
export const getSupabase = () => {
  if (!_client) {
    _client = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  }
  return _client;
};

export interface CaptainProfile {
  id: string;
  phone: string;
  email: string | null;
  name_ar: string;
  name_en: string;
  vehicle_model: string | null;
  vehicle_color: string | null;
  plate_number: string | null;
  service_types: string[];
  avatar_url: string | null;
  rating: number;
  total_trips: number;
  is_online: boolean;
  is_approved: boolean;
  current_lat: number | null;
  current_lng: number | null;
}

interface CaptainAuthContextType {
  captain: CaptainProfile | null;
  session: Session | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isOnline: boolean;
  toggleOnline: () => Promise<void>;
  setSessionFromOTP: (session: Session, phone?: string) => Promise<void>;
  refreshProfile: () => Promise<void>;
  logout: () => Promise<void>;
}

export const CaptainAuthContext = createContext<CaptainAuthContextType | undefined>(undefined);

export function useCaptainAuth() {
  const ctx = useContext(CaptainAuthContext);
  if (!ctx) throw new Error('useCaptainAuth must be inside CaptainAuthProvider');
  return ctx;
}

const SESSION_KEY = 'captain_session_v1';

export function CaptainAuthProvider({ children }: { children: ReactNode }) {
  const [captain, setCaptain] = useState<CaptainProfile | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const supabase = getSupabase();

  const fetchProfile = async (phone: string): Promise<CaptainProfile | null> => {
    const { data } = await supabase
      .from('captain_profiles')
      .select('*')
      .eq('phone', phone)
      .single();
    return data as CaptainProfile | null;
  };

  const fetchProfileByEmail = async (email: string): Promise<CaptainProfile | null> => {
    const { data } = await supabase
      .from('captain_profiles')
      .select('*')
      .eq('email', email)
      .single();
    return data as CaptainProfile | null;
  };

  const fetchProfileByUserId = async (userId: string): Promise<CaptainProfile | null> => {
    // Get phone and email from user_profiles
    const { data: userProfile } = await supabase
      .from('user_profiles')
      .select('phone, email')
      .eq('id', userId)
      .single();
    // Try phone first, then email
    if (userProfile?.phone) {
      const byPhone = await fetchProfile(userProfile.phone);
      if (byPhone) return byPhone;
    }
    if (userProfile?.email) {
      return fetchProfileByEmail(userProfile.email);
    }
    return null;
  };

  useEffect(() => {
    const init = async () => {
      const { data: { session: s } } = await supabase.auth.getSession();
      if (s?.user) {
        setSession(s);
        const profile = await fetchProfileByUserId(s.user.id);
        setCaptain(profile);
      }
      setIsLoading(false);
    };
    init();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_, s) => {
      setSession(s);
      if (s?.user) {
        const profile = await fetchProfileByUserId(s.user.id);
        setCaptain(profile);
      } else {
        setCaptain(null);
      }
    });
    return () => subscription.unsubscribe();
  }, []);

  const setSessionFromOTP = async (newSession: Session, emailOrPhone?: string) => {
    await supabase.auth.setSession({
      access_token: newSession.access_token,
      refresh_token: newSession.refresh_token,
    });
    await SecureStore.setItemAsync(SESSION_KEY, JSON.stringify({
      access_token: newSession.access_token,
      refresh_token: newSession.refresh_token,
    }));
    const profile = await fetchProfileByUserId(newSession.user.id);
    setCaptain(profile);
    setSession(newSession);
    // Save push token for real notifications
    if (profile?.phone) {
      savePushToken(profile.phone, newSession.access_token).catch(() => {});
    }
  };

  const toggleOnline = async () => {
    if (!captain) return;
    const newStatus = !captain.is_online;
    await supabase
      .from('captain_profiles')
      .update({ is_online: newStatus })
      .eq('id', captain.id);
    setCaptain({ ...captain, is_online: newStatus });
  };

  const refreshProfile = async () => {
    if (session?.user) {
      const profile = await fetchProfileByUserId(session.user.id);
      setCaptain(profile);
    }
  };

  const logout = async () => {
    if (captain) {
      await supabase.from('captain_profiles').update({ is_online: false }).eq('id', captain.id);
    }
    await supabase.auth.signOut();
    await SecureStore.deleteItemAsync(SESSION_KEY);
    setCaptain(null);
    setSession(null);
  };

  return (
    <CaptainAuthContext.Provider value={{
      captain, session,
      isAuthenticated: !!session && !!captain,
      isLoading,
      isOnline: captain?.is_online ?? false,
      toggleOnline, setSessionFromOTP, refreshProfile, logout,
    }}>
      {children}
    </CaptainAuthContext.Provider>
  );
}
