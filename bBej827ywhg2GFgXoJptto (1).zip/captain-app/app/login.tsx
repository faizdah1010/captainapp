import React, { useState } from 'react';
import {
  View, Text, StyleSheet, Pressable, TextInput,
  KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { getSupabase, useCaptainAuth } from '@/contexts/CaptainAuthContext';
import { Colors, Typography, Spacing, Radius, Shadows } from '@/constants/theme';

type Step = 'email' | 'otp';

export default function CaptainLoginScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { setSessionFromOTP } = useCaptainAuth();

  const [step, setStep] = useState<Step>('email');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [sentEmail, setSentEmail] = useState('');

  const supabase = getSupabase();

  const handleSendOTP = async () => {
    const emailVal = email.trim().toLowerCase();
    if (!emailVal.includes('@') || !emailVal.includes('.')) {
      setError('أدخل بريداً إلكترونياً صحيحاً');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const { error: err } = await supabase.auth.signInWithOtp({ email: emailVal });
      if (err) throw new Error(err.message);
      setSentEmail(emailVal);
      setStep('otp');
    } catch (e: any) {
      setError(e.message || 'حدث خطأ. حاول مجدداً');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (otp.length < 4) { setError('أدخل رمز التحقق'); return; }
    setError('');
    setLoading(true);
    try {
      const { data, error: err } = await supabase.auth.verifyOtp({
        email: sentEmail,
        token: otp.trim(),
        type: 'email',
      });
      if (err) throw new Error(err.message);
      if (!data.session) throw new Error('لم يتم إنشاء الجلسة');
      await setSessionFromOTP(data.session, sentEmail);
      router.replace('/');
    } catch (e: any) {
      setError(e.message || 'رمز التحقق غير صحيح');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.root}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingTop: insets.top + 32, paddingBottom: insets.bottom + 32 }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* ── Brand ── */}
        <View style={styles.brandSection}>
          <View style={styles.logoBox}>
            <MaterialIcons name="directions-car" size={48} color={Colors.red} />
          </View>
          <Text style={styles.appName}>طريقي</Text>
          <Text style={styles.subtitle}>بوابة الكابتن</Text>
        </View>

        {/* ── Card ── */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>
            {step === 'email' ? 'تسجيل الدخول' : 'التحقق من الهوية'}
          </Text>
          <Text style={styles.cardSub}>
            {step === 'email'
              ? 'أدخل بريدك الإلكتروني وسيصلك رمز التحقق'
              : `تم إرسال رمز التحقق إلى ${sentEmail}`}
          </Text>

          {step === 'email' ? (
            <>
              <View style={styles.inputWrapper}>
                <MaterialIcons name="email" size={20} color={Colors.textMuted} style={styles.inputIcon} />
                <TextInput
                  style={styles.input}
                  value={email}
                  onChangeText={setEmail}
                  placeholder="captain@example.com"
                  placeholderTextColor={Colors.textMuted}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  textAlign="right"
                />
              </View>
              <Pressable
                style={[styles.mainBtn, loading && styles.mainBtnDisabled]}
                onPress={handleSendOTP}
                disabled={loading}
              >
                {loading
                  ? <ActivityIndicator color="#fff" />
                  : <><MaterialIcons name="mail" size={18} color="#fff" /><Text style={styles.mainBtnText}>  إرسال رمز التحقق</Text></>}
              </Pressable>
            </>
          ) : (
            <>
              <View style={styles.inputWrapper}>
                <MaterialIcons name="lock-outline" size={20} color={Colors.textMuted} style={styles.inputIcon} />
                <TextInput
                  style={[styles.input, styles.otpInput]}
                  value={otp}
                  onChangeText={setOtp}
                  placeholder="• • • •"
                  placeholderTextColor={Colors.textMuted}
                  keyboardType="number-pad"
                  textAlign="center"
                  maxLength={6}
                  autoFocus
                />
              </View>
              <Pressable
                style={[styles.mainBtn, loading && styles.mainBtnDisabled]}
                onPress={handleVerifyOTP}
                disabled={loading}
              >
                {loading
                  ? <ActivityIndicator color="#fff" />
                  : <Text style={styles.mainBtnText}>تحقق والدخول</Text>}
              </Pressable>
              <Pressable style={styles.backBtn} onPress={() => { setStep('email'); setOtp(''); setError(''); }}>
                <MaterialIcons name="chevron-right" size={18} color={Colors.textMuted} />
                <Text style={styles.backBtnText}>تغيير البريد الإلكتروني</Text>
              </Pressable>
            </>
          )}

          {error ? (
            <View style={styles.errorBox}>
              <MaterialIcons name="error-outline" size={16} color={Colors.error} />
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}
        </View>

        <Text style={styles.footerNote}>
          للتسجيل كابتن جديد تواصل مع إدارة طريقي
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background },
  scroll: { paddingHorizontal: Spacing.xl, gap: Spacing.xl },

  brandSection: { alignItems: 'center', gap: Spacing.sm },
  logoBox: {
    width: 90, height: 90, borderRadius: 24,
    backgroundColor: Colors.redFaint, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: Colors.red, ...Shadows.red,
  },
  appName: { color: Colors.textPrimary, fontSize: Typography.sizes.xxxl, fontWeight: Typography.weights.extraBold },
  subtitle: { color: Colors.gold, fontSize: Typography.sizes.base, fontWeight: Typography.weights.medium },

  card: {
    backgroundColor: Colors.surfaceCard, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, padding: Spacing.xl, gap: Spacing.base,
  },
  cardTitle: { color: Colors.textPrimary, fontSize: Typography.sizes.xl, fontWeight: Typography.weights.bold, textAlign: 'right' },
  cardSub: { color: Colors.textSecondary, fontSize: Typography.sizes.sm, textAlign: 'right', lineHeight: 20 },

  inputWrapper: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.surface, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border, paddingHorizontal: Spacing.base,
    minHeight: 52,
  },
  inputIcon: {},
  input: { flex: 1, color: Colors.textPrimary, fontSize: Typography.sizes.base, paddingVertical: 12 },
  otpInput: { fontSize: Typography.sizes.xxl, letterSpacing: 8, fontWeight: Typography.weights.bold },

  mainBtn: {
    backgroundColor: Colors.red, borderRadius: Radius.md,
    paddingVertical: 16, alignItems: 'center', justifyContent: 'center',
    minHeight: 54, ...Shadows.red,
  },
  mainBtnDisabled: { opacity: 0.6 },
  mainBtnText: { color: '#fff', fontSize: Typography.sizes.base, fontWeight: Typography.weights.bold },

  backBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4 },
  backBtnText: { color: Colors.textMuted, fontSize: Typography.sizes.sm },

  errorBox: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: 'rgba(255,68,68,0.1)', borderRadius: Radius.md,
    padding: Spacing.md, borderWidth: 1, borderColor: 'rgba(255,68,68,0.3)',
  },
  errorText: { color: Colors.error, fontSize: Typography.sizes.sm, flex: 1, textAlign: 'right' },

  footerNote: { color: Colors.textMuted, fontSize: Typography.sizes.xs, textAlign: 'center' },
});
