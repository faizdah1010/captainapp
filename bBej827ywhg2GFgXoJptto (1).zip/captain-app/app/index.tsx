import { useEffect } from 'react';
import { useRouter } from 'expo-router';
import { View, ActivityIndicator } from 'react-native';
import { useCaptainAuth } from '@/contexts/CaptainAuthContext';

export default function RootIndex() {
  const router = useRouter();
  const { isAuthenticated, isLoading, captain } = useCaptainAuth();

  useEffect(() => {
    if (isLoading) return;
    if (isAuthenticated && captain) {
      router.replace('/(tabs)');
    } else {
      router.replace('/login');
    }
  }, [isLoading, isAuthenticated, captain]);

  return (
    <View style={{ flex: 1, backgroundColor: '#0D0002', alignItems: 'center', justifyContent: 'center' }}>
      <ActivityIndicator color="#CC1020" size="large" />
    </View>
  );
}
