import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, TextInput,
  ActivityIndicator, Image, Alert, Platform,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { useCaptainAuth, getSupabase } from '@/contexts/CaptainAuthContext';
import { Colors, Typography, Spacing, Radius, Shadows } from '@/constants/theme';

type Step = 1 | 2 | 3;

export default function RegisterScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { captain, session, logout, refreshProfile } = useCaptainAuth();
  const supabase = getSupabase();

  const [step, setStep] = useState<Step>(1);

  // Step 1 — Personal
  const [nameAr, setNameAr] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [phone, setPhone] = useState('');
  const [avatarUri, setAvatarUri] = useState<string | null>(null);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);

  // Step 2 — Vehicle
  const [vehicleModel, setVehicleModel] = useState('');
  const [vehicleColor, setVehicleColor] = useState('');
  const [plateNumber, setPlateNumber] = useState('');

  // Step 3 — Services
  const [services, setServices] = useState<string[]>(['regular']);

  const [loading, setLoading] = useState(false);
  const [avatarUploading, setAvatarUploading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const toggleService = (s: string) => {
    setServices(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);
  };

  // ── Avatar upload ──────────────────────────────────────────────────────────
  const pickAvatar = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('الإذن مطلوب', 'يرجى السماح بالوصول إلى معرض الصور');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
      base64: true,
    });

    if (result.canceled || !result.assets?.[0]) return;

    const asset = result.assets[0];
    setAvatarUri(asset.uri);

    if (!session?.user?.id || !asset.base64) return;

    setAvatarUploading(true);
    try {
      const ext = asset.uri.split('.').pop() ?? 'jpg';
      const fileName = `${session.user.id}/avatar.${ext}`;
      const contentType = `image/${ext === 'jpg' ? 'jpeg' : ext}`;

      const byteChars = atob(asset.base64);
      const byteArray = new Uint8Array(byteChars.length);
      for (let i = 0; i < byteChars.length; i++) {
        byteArray[i] = byteChars.charCodeAt(i);
      }

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, byteArray.buffer, { contentType, upsert: true });

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage.from('avatars').getPublicUrl(fileName);
      setAvatarUrl(urlData.publicUrl);
    } catch (e: any) {
      Alert.alert('خطأ في رفع الصورة', e.message ?? 'حاول مجدداً');
      setAvatarUri(null);
    } finally {
      setAvatarUploading(false);
    }
  };

  // ── Step validations ───────────────────────────────────────────────────────
  const validateStep = (s: Step): boolean => {
    setError('');
    if (s === 1) {
      if (!nameAr.trim() || !nameEn.trim()) {
        setError('يرجى إدخال الاسم بالعربية والإنجليزية');
        return false;
      }
    } else if (s === 2) {
      if (!vehicleModel.trim() || !plateNumber.trim()) {
        setError('يرجى إدخال موديل السيارة ورقم اللوحة');
        return false;
      }
    } else if (s === 3) {
      if (services.length === 0) {
        setError('يرجى اختيار نوع خدمة واحد على الأقل');
        return false;
      }
    }
    return true;
  };

  const handleNext = () => {
    if (!validateStep(step)) return;
    setStep(prev => (prev < 3 ? (prev + 1) as Step : prev));
  };

  // ── Final submit ───────────────────────────────────────────────────────────
  const handleSubmit = async () => {
    if (!validateStep(3)) return;
    if (!session?.user) return;

    setLoading(true);
    try {
      const captainEmail = session.user.email ?? '';

      // Normalize phone (optional)
      let normalizedPhone: string | null = null;
      if (phone.trim()) {
        let p = phone.trim();
        if (p.startsWith('07')) p = '+962' + p.slice(1);
        else if (p.startsWith('962')) p = '+' + p;
        else if (!p.startsWith('+')) p = '+962' + p;
        normalizedPhone = p;
      }

      // Upsert captain_profiles using email as conflict key
      const { error: upsertError } = await supabase
        .from('captain_profiles')
        .upsert({
          phone: normalizedPhone ?? `email:${captainEmail}`, // fallback placeholder if no phone
          email: captainEmail,
          name_ar: nameAr.trim(),
          name_en: nameEn.trim(),
          vehicle_model: vehicleModel.trim(),
          vehicle_color: vehicleColor.trim() || null,
          plate_number: plateNumber.trim(),
          service_types: services,
          avatar_url: avatarUrl ?? null,
          is_approved: false,
        }, { onConflict: 'email' });

      if (upsertError) throw upsertError;
      await refreshProfile();
      setSubmitted(true);
    } catch (e: any) {
      setError(e.message || 'حدث خطأ. حاول مجدداً');
    } finally {
      setLoading(false);
    }
  };

  // ── Success / Pending state ────────────────────────────────────────────────
  if (submitted || (captain && !captain.is_approved)) {
    return (
      <View style={[styles.container, styles.centered, { paddingTop: insets.top }]}>
        <View style={styles.pendingIcon}>
          <MaterialIcons name="pending-actions" size={56} color={Colors.gold} />
        </View>
        <Text style={styles.pendingTitle}>تم إرسال طلبك بنجاح</Text>
        <Text style={styles.pendingSubtitle}>
          سيتم مراجعة طلبك من قِبل إدارة طريقي والتواصل معك عبر البريد الإلكتروني في أقرب وقت.{'\n\n'}
          يرجى الانتظار حتى يتم تفعيل حسابك.
        </Text>
        <View style={styles.pendingSteps}>
          {[
            { icon: 'check-circle', text: 'تم استلام طلبك', done: true },
            { icon: 'hourglass-empty', text: 'مراجعة البيانات', done: false },
            { icon: 'verified', text: 'تفعيل الحساب', done: false },
          ].map((item, idx) => (
            <View key={idx} style={styles.pendingStepRow}>
              <MaterialIcons
                name={item.icon as any}
                size={20}
                color={item.done ? Colors.success : Colors.textMuted}
              />
              <Text style={[styles.pendingStepText, item.done && { color: Colors.success }]}>
                {item.text}
              </Text>
            </View>
          ))}
        </View>
        <Pressable
          style={styles.logoutBtn}
          onPress={async () => { await logout(); router.replace('/login'); }}
        >
          <Text style={styles.logoutBtnText}>تسجيل الخروج</Text>
        </Pressable>
      </View>
    );
  }

  if (captain?.is_approved) {
    router.replace('/');
    return null;
  }

  const stepTitles = ['المعلومات الشخصية', 'معلومات السيارة', 'أنواع الخدمات'];
  const progress = (step / 3) * 100;

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Top progress bar */}
      <View style={styles.progressBar}>
        <View style={[styles.progressFill, { width: `${progress}%` }]} />
      </View>

      {/* Step indicator */}
      <View style={styles.stepHeader}>
        <Text style={styles.stepCounter}>الخطوة {step} من 3</Text>
        <Text style={styles.stepTitle}>{stepTitles[step - 1]}</Text>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
      >

        {/* ── STEP 1: Personal Info ─────────────────────────────────────── */}
        {step === 1 ? (
          <View style={styles.stepBody}>
            {/* Email display (read-only from auth) */}
            <View style={styles.emailBadge}>
              <MaterialIcons name="email" size={16} color={Colors.gold} />
              <Text style={styles.emailBadgeText}>{session?.user?.email ?? '—'}</Text>
              <View style={styles.verifiedBadge}>
                <MaterialIcons name="verified" size={12} color={Colors.success} />
                <Text style={styles.verifiedText}>موثّق</Text>
              </View>
            </View>

            {/* Avatar picker */}
            <Pressable style={styles.avatarPicker} onPress={pickAvatar} disabled={avatarUploading}>
              {avatarUri ? (
                <Image source={{ uri: avatarUri }} style={styles.avatarImage} />
              ) : (
                <View style={styles.avatarPlaceholder}>
                  <MaterialIcons name="add-a-photo" size={32} color={Colors.textMuted} />
                  <Text style={styles.avatarPlaceholderText}>إضافة صورة شخصية</Text>
                  <Text style={styles.avatarPlaceholderSub}>اختياري</Text>
                </View>
              )}
              {avatarUploading ? (
                <View style={styles.avatarOverlay}>
                  <ActivityIndicator color={Colors.gold} />
                </View>
              ) : null}
              {avatarUri && !avatarUploading ? (
                <View style={styles.avatarEditBadge}>
                  <MaterialIcons name="edit" size={14} color="#fff" />
                </View>
              ) : null}
            </Pressable>

            <Field
              label="الاسم بالعربية *"
              value={nameAr}
              onChange={setNameAr}
              placeholder="محمد أحمد"
              hint="كما يظهر في التطبيق للركاب"
            />
            <Field
              label="الاسم بالإنجليزية *"
              value={nameEn}
              onChange={setNameEn}
              placeholder="Mohammed Ahmad"
              hint="For English-speaking passengers"
            />
            <Field
              label="رقم الهاتف (اختياري)"
              value={phone}
              onChange={setPhone}
              placeholder="07XXXXXXXX"
              hint="للتواصل من قِبل الإدارة"
              keyboardType="phone-pad"
            />
          </View>
        ) : null}

        {/* ── STEP 2: Vehicle ───────────────────────────────────────────── */}
        {step === 2 ? (
          <View style={styles.stepBody}>
            <View style={styles.vehicleIconRow}>
              <View style={styles.vehicleIcon}>
                <MaterialIcons name="directions-car" size={40} color={Colors.red} />
              </View>
              <Text style={styles.vehicleIconLabel}>أدخل بيانات مركبتك</Text>
            </View>

            <Field
              label="موديل السيارة *"
              value={vehicleModel}
              onChange={setVehicleModel}
              placeholder="Toyota Corolla 2022"
              hint="المصنّع + الموديل + السنة"
            />
            <Field
              label="لون السيارة"
              value={vehicleColor}
              onChange={setVehicleColor}
              placeholder="أبيض"
            />
            <Field
              label="رقم اللوحة *"
              value={plateNumber}
              onChange={setPlateNumber}
              placeholder="أ ب ج 1234"
              hint="كما يظهر على لوحة المركبة"
            />

            {/* Color swatches */}
            <View style={styles.colorRow}>
              {['أبيض', 'أسود', 'فضي', 'رمادي', 'أحمر', 'أزرق'].map(c => (
                <Pressable
                  key={c}
                  style={[styles.colorChip, vehicleColor === c && styles.colorChipActive]}
                  onPress={() => setVehicleColor(c)}
                >
                  <Text style={[styles.colorChipText, vehicleColor === c && styles.colorChipTextActive]}>
                    {c}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        ) : null}

        {/* ── STEP 3: Services ──────────────────────────────────────────── */}
        {step === 3 ? (
          <View style={styles.stepBody}>
            <Text style={styles.servicesDesc}>
              اختر أنواع الخدمات التي يمكنك تقديمها. يمكنك اختيار أكثر من نوع.
            </Text>

            {SERVICE_OPTIONS.map(s => {
              const active = services.includes(s.key);
              return (
                <Pressable
                  key={s.key}
                  style={[styles.serviceCard, active && styles.serviceCardActive]}
                  onPress={() => toggleService(s.key)}
                >
                  <View style={[styles.serviceIconWrap, active && styles.serviceIconWrapActive]}>
                    <MaterialIcons name={s.icon as any} size={26} color={active ? Colors.gold : Colors.textMuted} />
                  </View>
                  <View style={styles.serviceTextWrap}>
                    <Text style={[styles.serviceTitle, active && styles.serviceTitleActive]}>{s.label}</Text>
                    <Text style={styles.serviceDesc}>{s.desc}</Text>
                  </View>
                  <View style={[styles.serviceCheck, active && styles.serviceCheckActive]}>
                    {active ? <MaterialIcons name="check" size={14} color="#fff" /> : null}
                  </View>
                </Pressable>
              );
            })}

            {/* Summary preview */}
            <View style={styles.summaryCard}>
              <Text style={styles.summaryTitle}>ملخص الطلب</Text>
              <View style={styles.summaryRow}>
                <MaterialIcons name="email" size={16} color={Colors.textMuted} />
                <Text style={styles.summaryText}>{session?.user?.email ?? '—'}</Text>
              </View>
              <View style={styles.summaryRow}>
                <MaterialIcons name="person" size={16} color={Colors.textMuted} />
                <Text style={styles.summaryText}>{nameAr} · {nameEn}</Text>
              </View>
              <View style={styles.summaryRow}>
                <MaterialIcons name="directions-car" size={16} color={Colors.textMuted} />
                <Text style={styles.summaryText}>{vehicleModel || '—'} · {plateNumber || '—'}</Text>
              </View>
              {phone ? (
                <View style={styles.summaryRow}>
                  <MaterialIcons name="phone" size={16} color={Colors.textMuted} />
                  <Text style={styles.summaryText}>{phone}</Text>
                </View>
              ) : null}
              <View style={styles.summaryRow}>
                <MaterialIcons name="category" size={16} color={Colors.textMuted} />
                <Text style={styles.summaryText}>
                  {services.map(s => SERVICE_OPTIONS.find(o => o.key === s)?.label).join('، ')}
                </Text>
              </View>
            </View>
          </View>
        ) : null}

        {/* Error */}
        {error ? (
          <View style={styles.errorBox}>
            <MaterialIcons name="error-outline" size={16} color={Colors.error} />
            <Text style={styles.errorText}>{error}</Text>
          </View>
        ) : null}
      </ScrollView>

      {/* Bottom nav */}
      <View style={[styles.bottomNav, { paddingBottom: insets.bottom + Spacing.base }]}>
        {step > 1 ? (
          <Pressable
            style={styles.backNavBtn}
            onPress={() => { setError(''); setStep(prev => (prev - 1) as Step); }}
          >
            <MaterialIcons name="chevron-right" size={22} color={Colors.textMuted} />
            <Text style={styles.backNavText}>السابق</Text>
          </Pressable>
        ) : (
          <View style={{ flex: 1 }} />
        )}

        {step < 3 ? (
          <Pressable style={styles.nextBtn} onPress={handleNext}>
            <Text style={styles.nextBtnText}>التالي</Text>
            <MaterialIcons name="chevron-left" size={22} color="#fff" />
          </Pressable>
        ) : (
          <Pressable
            style={[styles.nextBtn, styles.submitBtn, loading && { opacity: 0.6 }]}
            onPress={handleSubmit}
            disabled={loading}
          >
            {loading
              ? <ActivityIndicator color="#fff" />
              : <><Text style={styles.nextBtnText}>إرسال الطلب</Text><MaterialIcons name="send" size={18} color="#fff" /></>
            }
          </Pressable>
        )}
      </View>
    </View>
  );
}

// ── Service options ────────────────────────────────────────────────────────────
const SERVICE_OPTIONS = [
  {
    key: 'regular',
    label: 'طريق عادي',
    desc: 'توصيل الركاب العاديين لأي وجهة',
    icon: 'directions-car',
  },
  {
    key: 'ladies',
    label: 'طريق نسائي',
    desc: 'توصيل راكبات فقط — يتطلب سيارة نظيفة',
    icon: 'woman',
  },
  {
    key: 'express',
    label: 'طريق إكسبرس',
    desc: 'توصيل الطرود والبضائع الصغيرة',
    icon: 'local-shipping',
  },
];

// ── Field component ────────────────────────────────────────────────────────────
function Field({ label, value, onChange, placeholder, hint, keyboardType = 'default' }: {
  label: string; value: string; onChange: (t: string) => void;
  placeholder: string; hint?: string; keyboardType?: string;
}) {
  return (
    <View style={styles.fieldGroup}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        style={styles.input}
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={Colors.textMuted}
        keyboardType={keyboardType as any}
        textAlign="right"
      />
      {hint ? <Text style={styles.fieldHint}>{hint}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  centered: { alignItems: 'center', justifyContent: 'center', padding: Spacing.xxl },
  scrollContent: { paddingHorizontal: Spacing.base, paddingBottom: 120, gap: Spacing.base },
  stepBody: { gap: Spacing.base },

  // Progress
  progressBar: { height: 4, backgroundColor: Colors.border },
  progressFill: { height: 4, backgroundColor: Colors.red, borderRadius: 2 },
  stepHeader: {
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.base,
    gap: 2, borderBottomWidth: 1, borderBottomColor: Colors.border, marginBottom: Spacing.sm,
  },
  stepCounter: { color: Colors.red, fontSize: Typography.sizes.xs, fontWeight: Typography.weights.semiBold },
  stepTitle: { color: Colors.textPrimary, fontSize: Typography.sizes.xl, fontWeight: Typography.weights.bold, textAlign: 'right' },

  // Email badge
  emailBadge: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: 'rgba(201,168,76,0.08)', borderRadius: Radius.md,
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderWidth: 1, borderColor: Colors.borderGold,
  },
  emailBadgeText: { color: Colors.gold, fontSize: Typography.sizes.sm, flex: 1, textAlign: 'right' },
  verifiedBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: 'rgba(34,197,94,0.12)', borderRadius: Radius.full,
    paddingHorizontal: 8, paddingVertical: 3,
  },
  verifiedText: { color: Colors.success, fontSize: 10, fontWeight: Typography.weights.semiBold },

  // Avatar
  avatarPicker: {
    alignSelf: 'center', width: 100, height: 100, borderRadius: 50,
    overflow: 'hidden', borderWidth: 2, borderColor: Colors.border,
    borderStyle: 'dashed',
  },
  avatarImage: { width: '100%', height: '100%', resizeMode: 'cover' },
  avatarPlaceholder: {
    width: '100%', height: '100%',
    backgroundColor: Colors.surfaceCard,
    alignItems: 'center', justifyContent: 'center', gap: 4,
  },
  avatarPlaceholderText: { color: Colors.textMuted, fontSize: 10, textAlign: 'center' },
  avatarPlaceholderSub: { color: Colors.textMuted, fontSize: 9 },
  avatarOverlay: {
    position: 'absolute', width: '100%', height: '100%',
    backgroundColor: 'rgba(0,0,0,0.5)', alignItems: 'center', justifyContent: 'center',
  },
  avatarEditBadge: {
    position: 'absolute', bottom: 4, right: 4,
    width: 22, height: 22, borderRadius: 11,
    backgroundColor: Colors.red, alignItems: 'center', justifyContent: 'center',
  },

  // Field
  fieldGroup: { gap: 6 },
  fieldLabel: { color: Colors.textSecondary, fontSize: Typography.sizes.sm, textAlign: 'right' },
  input: {
    backgroundColor: Colors.surfaceCard, borderWidth: 1, borderColor: Colors.border,
    borderRadius: Radius.md, paddingHorizontal: Spacing.base, paddingVertical: 14,
    color: Colors.textPrimary, fontSize: Typography.sizes.base,
  },
  fieldHint: { color: Colors.textMuted, fontSize: Typography.sizes.xs, textAlign: 'right' },

  // Vehicle
  vehicleIconRow: { alignItems: 'center', gap: Spacing.sm, paddingVertical: Spacing.md },
  vehicleIcon: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: Colors.redFaint, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: Colors.red,
  },
  vehicleIconLabel: { color: Colors.textSecondary, fontSize: Typography.sizes.base },

  // Color swatches
  colorRow: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: Spacing.sm },
  colorChip: {
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    borderRadius: Radius.full, borderWidth: 1, borderColor: Colors.border,
    backgroundColor: Colors.surfaceCard,
  },
  colorChipActive: { borderColor: Colors.gold, backgroundColor: Colors.goldFaint },
  colorChipText: { color: Colors.textMuted, fontSize: Typography.sizes.sm },
  colorChipTextActive: { color: Colors.gold, fontWeight: Typography.weights.semiBold },

  // Service cards
  servicesDesc: {
    color: Colors.textSecondary, fontSize: Typography.sizes.sm,
    textAlign: 'right', lineHeight: 20,
  },
  serviceCard: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md,
    backgroundColor: Colors.surfaceCard, borderRadius: Radius.xl,
    borderWidth: 1.5, borderColor: Colors.border, padding: Spacing.base,
  },
  serviceCardActive: { borderColor: Colors.gold, backgroundColor: Colors.goldFaint, ...Shadows.gold },
  serviceIconWrap: {
    width: 54, height: 54, borderRadius: 27,
    backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  serviceIconWrapActive: { borderColor: Colors.gold, backgroundColor: 'rgba(201,168,76,0.15)' },
  serviceTextWrap: { flex: 1, gap: 4, alignItems: 'flex-end' },
  serviceTitle: { color: Colors.textSecondary, fontSize: Typography.sizes.base, fontWeight: Typography.weights.semiBold },
  serviceTitleActive: { color: Colors.textPrimary },
  serviceDesc: { color: Colors.textMuted, fontSize: Typography.sizes.xs, textAlign: 'right' },
  serviceCheck: {
    width: 24, height: 24, borderRadius: 12,
    borderWidth: 1.5, borderColor: Colors.border,
    alignItems: 'center', justifyContent: 'center',
  },
  serviceCheckActive: { backgroundColor: Colors.gold, borderColor: Colors.gold },

  // Summary
  summaryCard: {
    backgroundColor: Colors.surface, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, padding: Spacing.base, gap: Spacing.sm,
    marginTop: Spacing.sm,
  },
  summaryTitle: {
    color: Colors.gold, fontSize: Typography.sizes.sm,
    fontWeight: Typography.weights.semiBold, textAlign: 'right', marginBottom: 4,
  },
  summaryRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm },
  summaryText: { color: Colors.textSecondary, fontSize: Typography.sizes.sm, flex: 1, textAlign: 'right' },

  // Error
  errorBox: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: 'rgba(255,68,68,0.1)', borderRadius: Radius.md,
    padding: Spacing.md, borderWidth: 1, borderColor: 'rgba(255,68,68,0.3)',
  },
  errorText: { color: Colors.error, fontSize: Typography.sizes.sm, flex: 1, textAlign: 'right' },

  // Bottom nav
  bottomNav: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.base,
    paddingHorizontal: Spacing.base, paddingTop: Spacing.base,
    borderTopWidth: 1, borderTopColor: Colors.border,
    backgroundColor: Colors.surface,
  },
  backNavBtn: {
    flexDirection: 'row-reverse', alignItems: 'center', gap: 4,
    paddingHorizontal: Spacing.base, paddingVertical: 14,
  },
  backNavText: { color: Colors.textMuted, fontSize: Typography.sizes.base },
  nextBtn: {
    flex: 1, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: Spacing.sm, backgroundColor: Colors.red, borderRadius: Radius.md,
    paddingVertical: 16, ...Shadows.red,
  },
  submitBtn: { backgroundColor: Colors.red },
  nextBtnText: { color: '#fff', fontSize: Typography.sizes.base, fontWeight: Typography.weights.bold },

  // Pending state
  pendingIcon: {
    width: 110, height: 110, borderRadius: 55,
    backgroundColor: Colors.goldFaint, alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: Colors.gold, marginBottom: Spacing.lg, ...Shadows.gold,
  },
  pendingTitle: {
    color: Colors.textPrimary, fontSize: Typography.sizes.xxl,
    fontWeight: Typography.weights.bold, textAlign: 'center',
  },
  pendingSubtitle: {
    color: Colors.textMuted, fontSize: Typography.sizes.base,
    textAlign: 'center', lineHeight: 24, maxWidth: 300,
  },
  pendingSteps: {
    gap: Spacing.md, marginTop: Spacing.xl, alignSelf: 'stretch',
    backgroundColor: Colors.surfaceCard, borderRadius: Radius.xl,
    padding: Spacing.base, borderWidth: 1, borderColor: Colors.border,
  },
  pendingStepRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md },
  pendingStepText: { color: Colors.textMuted, fontSize: Typography.sizes.base, flex: 1, textAlign: 'right' },
  logoutBtn: {
    marginTop: Spacing.xl, backgroundColor: Colors.surfaceCard,
    borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border,
    paddingHorizontal: Spacing.xl, paddingVertical: 14,
  },
  logoutBtnText: { color: Colors.textMuted, fontSize: Typography.sizes.base, fontWeight: Typography.weights.medium },
});
