// Captain profile screen
import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable, ScrollView, ActivityIndicator, Alert } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useCaptainAuth } from '@/contexts/CaptainAuthContext';
import { Colors, Typography, Spacing, Radius, Shadows } from '@/constants/theme';

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { captain, logout } = useCaptainAuth();
  const [loggingOut, setLoggingOut] = useState(false);

  const handleLogout = async () => {
    setLoggingOut(true);
    await logout();
    router.replace('/login');
    setLoggingOut(false);
  };

  const confirmLogout = () => {
    Alert.alert('تسجيل الخروج', 'هل تريد تسجيل الخروج؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'خروج', style: 'destructive', onPress: handleLogout },
    ]);
  };

  return (
    <ScrollView style={[styles.root, { paddingTop: insets.top }]} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>حسابي</Text>
      </View>

      {/* Avatar & name */}
      <View style={styles.profileCard}>
        <View style={styles.avatar}>
          <MaterialIcons name="directions-car" size={40} color={Colors.red} />
        </View>
        <Text style={styles.name}>{captain?.name_ar || 'كابتن'}</Text>
        <Text style={styles.nameEn}>{captain?.name_en || ''}</Text>
        <View style={styles.ratingRow}>
          <MaterialIcons name="star" size={16} color={Colors.gold} />
          <Text style={styles.ratingText}>{Number(captain?.rating ?? 5).toFixed(1)}</Text>
          <Text style={styles.totalTrips}>• {captain?.total_trips ?? 0} رحلة</Text>
        </View>
        <View style={[styles.statusPill, { backgroundColor: captain?.is_approved ? Colors.green + '20' : Colors.redFaint }]}>
          <View style={[styles.statusDot, { backgroundColor: captain?.is_approved ? Colors.green : Colors.red }]} />
          <Text style={[styles.statusText, { color: captain?.is_approved ? Colors.green : Colors.red }]}>
            {captain?.is_approved ? 'معتمد' : 'قيد المراجعة'}
          </Text>
        </View>
      </View>

      {/* Vehicle info */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>معلومات المركبة</Text>
        {[
          { icon: 'directions-car', label: 'الموديل', value: captain?.vehicle_model },
          { icon: 'palette', label: 'اللون', value: captain?.vehicle_color },
          { icon: 'confirmation-number', label: 'رقم اللوحة', value: captain?.plate_number },
        ].map((item, i) => (
          <View key={i} style={styles.infoRow}>
            <Text style={styles.infoValue}>{item.value || '—'}</Text>
            <View style={styles.infoLabelRow}>
              <MaterialIcons name={item.icon as any} size={16} color={Colors.textMuted} />
              <Text style={styles.infoLabel}>{item.label}</Text>
            </View>
          </View>
        ))}
      </View>

      {/* Services */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>الخدمات المتاحة</Text>
        <View style={styles.servicesRow}>
          {(captain?.service_types ?? []).map((s, i) => (
            <View key={i} style={styles.serviceChip}>
              <Text style={styles.serviceChipText}>
                {s === 'regular' ? 'طريق عادي' : s === 'ladies' ? 'طريق نسائي' : 'إكسبرس'}
              </Text>
            </View>
          ))}
        </View>
      </View>

      {/* Contact info */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>معلومات الاتصال</Text>
        {captain?.email ? (
          <View style={styles.infoRow}>
            <Text style={styles.infoValue} numberOfLines={1}>{captain.email}</Text>
            <View style={styles.infoLabelRow}>
              <MaterialIcons name="email" size={16} color={Colors.textMuted} />
              <Text style={styles.infoLabel}>البريد الإلكتروني</Text>
            </View>
          </View>
        ) : null}
        {captain?.phone && !captain.phone.startsWith('email:') ? (
          <View style={styles.infoRow}>
            <Text style={styles.infoValue}>{captain.phone}</Text>
            <View style={styles.infoLabelRow}>
              <MaterialIcons name="phone" size={16} color={Colors.textMuted} />
              <Text style={styles.infoLabel}>رقم الهاتف</Text>
            </View>
          </View>
        ) : null}
      </View>

      {/* Logout */}
      <Pressable style={styles.logoutBtn} onPress={confirmLogout} disabled={loggingOut}>
        {loggingOut
          ? <ActivityIndicator color={Colors.error} />
          : <>
              <MaterialIcons name="logout" size={20} color={Colors.error} />
              <Text style={styles.logoutText}>تسجيل الخروج</Text>
            </>}
      </Pressable>

      <View style={{ height: 80 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background },
  header: {
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  headerTitle: { color: Colors.textPrimary, fontSize: Typography.sizes.xl, fontWeight: Typography.weights.bold },
  profileCard: {
    margin: Spacing.base, backgroundColor: Colors.surfaceCard,
    borderRadius: Radius.xxl, padding: Spacing.xl, alignItems: 'center', gap: Spacing.sm,
    borderWidth: 1, borderColor: Colors.border, ...Shadows.card,
  },
  avatar: {
    width: 90, height: 90, borderRadius: 45,
    backgroundColor: Colors.redFaint, alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: Colors.red, ...Shadows.red,
  },
  name: { color: Colors.textPrimary, fontSize: Typography.sizes.xl, fontWeight: Typography.weights.bold },
  nameEn: { color: Colors.textMuted, fontSize: Typography.sizes.sm },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  ratingText: { color: Colors.gold, fontSize: Typography.sizes.base, fontWeight: Typography.weights.semiBold },
  totalTrips: { color: Colors.textMuted, fontSize: Typography.sizes.sm },
  statusPill: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    borderRadius: Radius.full, paddingHorizontal: 12, paddingVertical: 6,
  },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  statusText: { fontSize: Typography.sizes.sm, fontWeight: Typography.weights.semiBold },
  section: {
    marginHorizontal: Spacing.base, marginBottom: Spacing.base,
    backgroundColor: Colors.surfaceCard, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, overflow: 'hidden',
  },
  sectionTitle: {
    color: Colors.textMuted, fontSize: Typography.sizes.xs, fontWeight: Typography.weights.semiBold,
    textAlign: 'right', padding: Spacing.base, paddingBottom: Spacing.sm,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    textTransform: 'uppercase', letterSpacing: 0.5,
  },
  infoRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  infoLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  infoLabel: { color: Colors.textMuted, fontSize: Typography.sizes.sm },
  infoValue: { color: Colors.textPrimary, fontSize: Typography.sizes.base, fontWeight: Typography.weights.medium },
  servicesRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, padding: Spacing.base },
  serviceChip: {
    backgroundColor: Colors.redFaint, borderRadius: Radius.full,
    paddingHorizontal: 14, paddingVertical: 6, borderWidth: 1, borderColor: Colors.red + '40',
  },
  serviceChipText: { color: Colors.red, fontSize: Typography.sizes.sm, fontWeight: Typography.weights.semiBold },
  logoutBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm,
    marginHorizontal: Spacing.base, marginBottom: Spacing.base,
    backgroundColor: 'rgba(255,68,68,0.1)', borderRadius: Radius.md,
    paddingVertical: 16, borderWidth: 1, borderColor: 'rgba(255,68,68,0.3)',
  },
  logoutText: { color: Colors.error, fontSize: Typography.sizes.base, fontWeight: Typography.weights.semiBold },
});
