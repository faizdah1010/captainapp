// Captain Home — ride requests, map, active ride management
import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, Pressable, FlatList,
  Switch, ActivityIndicator, Modal, Dimensions, Platform,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useCaptainAuth } from '@/contexts/CaptainAuthContext';
import { useRide, RideRequest } from '@/contexts/RideContext';
import { Colors, Typography, Spacing, Radius, Shadows } from '@/constants/theme';
import CaptainMap from '@/components/CaptainMap';

const { height: SCREEN_H } = Dimensions.get('window');
const MAP_H = Math.round(SCREEN_H * 0.35);

const SERVICE_LABELS: Record<string, string> = {
  regular: 'طريق عادي',
  ladies: 'طريق نسائي',
  express: 'إكسبرس',
};

export default function CaptainHome() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { captain, isOnline, toggleOnline } = useCaptainAuth();
  const { pendingRequests, activeRide, captainLocation, acceptRide, rejectRide, startRide, completeRide, refreshRequests } = useRide();

  const [togglingOnline, setTogglingOnline] = useState(false);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [rideModal, setRideModal] = useState(false);

  const captainPos = captainLocation ?? { lat: 31.9539, lng: 35.9106 };

  useEffect(() => { if (isOnline) refreshRequests(); }, [isOnline]);

  const handleToggle = async () => {
    setTogglingOnline(true);
    await toggleOnline();
    setTogglingOnline(false);
  };

  const handleAccept = async (id: string) => {
    setProcessingId(id);
    await acceptRide(id);
    setProcessingId(null);
  };

  const handleReject = async (id: string) => {
    setProcessingId(id);
    await rejectRide(id);
    setProcessingId(null);
  };

  const handleStart = async () => {
    if (!activeRide) return;
    setProcessingId(activeRide.id);
    await startRide(activeRide.id);
    setProcessingId(null);
  };

  const handleComplete = async () => {
    if (!activeRide) return;
    setProcessingId(activeRide.id);
    await completeRide(activeRide.id);
    setRideModal(false);
    setProcessingId(null);
    // Navigate to rating screen after completion
    router.push({
      pathname: '/rate-ride',
      params: {
        rideId: activeRide.id,
        passengerName: activeRide.passenger_name || 'الراكب',
        captainId: captain?.id || '',
      },
    });
  };

  // ── Not approved ─────────────────────────────────────────────────────────
  if (!captain?.is_approved) {
    return (
      <View style={[styles.center, { paddingTop: insets.top }]}>
        <MaterialIcons name="pending-actions" size={72} color={Colors.redDim} />
        <Text style={styles.bigTitle}>حسابك قيد المراجعة</Text>
        <Text style={styles.subTitle}>سنتواصل معك بعد الموافقة</Text>
      </View>
    );
  }

  // ── Request card ─────────────────────────────────────────────────────────
  const renderRequest = ({ item }: { item: RideRequest }) => {
    const busy = processingId === item.id;
    return (
      <View style={styles.card}>
        {/* Header row */}
        <View style={styles.row}>
          <Text style={styles.price}>{Number(item.price_jod).toFixed(3)} <Text style={styles.priceCur}>د.أ</Text></Text>
          <View style={styles.tag}>
            <Text style={styles.tagText}>{SERVICE_LABELS[item.service] ?? item.service}</Text>
          </View>
        </View>

        {/* Passenger */}
        <View style={styles.passengerRow}>
          <View style={styles.avatar}>
            <MaterialIcons name="person" size={20} color={Colors.gold} />
          </View>
          <Text style={styles.passengerName}>{item.passenger_name || 'راكب'}</Text>
          {item.passenger_rating ? (
            <View style={styles.ratingBadge}>
              <MaterialIcons name="star" size={12} color={Colors.gold} />
              <Text style={styles.ratingText}>{Number(item.passenger_rating).toFixed(1)}</Text>
            </View>
          ) : null}
        </View>

        {/* Route */}
        <View style={styles.route}>
          <View style={styles.routeRow}>
            <View style={[styles.dot, { backgroundColor: Colors.green }]} />
            <Text style={styles.routeText} numberOfLines={1}>{item.from_name}</Text>
          </View>
          <View style={styles.routeDivider} />
          <View style={styles.routeRow}>
            <View style={[styles.dot, { backgroundColor: Colors.red }]} />
            <Text style={styles.routeText} numberOfLines={1}>{item.to_name}</Text>
          </View>
        </View>

        {/* Actions */}
        <View style={styles.actionRow}>
          <Pressable style={styles.rejectBtn} onPress={() => handleReject(item.id)} disabled={busy}>
            <MaterialIcons name="close" size={20} color={Colors.error} />
            <Text style={styles.rejectText}>رفض</Text>
          </Pressable>
          <Pressable style={[styles.acceptBtn, busy && { opacity: 0.6 }]} onPress={() => handleAccept(item.id)} disabled={busy}>
            {busy
              ? <ActivityIndicator color="#fff" size="small" />
              : <><MaterialIcons name="check" size={20} color="#fff" /><Text style={styles.acceptText}>قبول</Text></>}
          </Pressable>
        </View>
      </View>
    );
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>

      {/* ── Top bar ── */}
      <View style={styles.topBar}>
        <View style={{ flex: 1 }}>
          <Text style={styles.greeting}>مرحباً، {captain?.name_ar || 'كابتن'}</Text>
          <Text style={styles.vehicleInfo} numberOfLines={1}>
            {[captain?.vehicle_model, captain?.plate_number].filter(Boolean).join(' • ')}
          </Text>
        </View>
        <View style={styles.toggleArea}>
          <Text style={[styles.statusLabel, { color: isOnline ? Colors.green : Colors.textMuted }]}>
            {isOnline ? 'متاح' : 'غير متاح'}
          </Text>
          {togglingOnline
            ? <ActivityIndicator size="small" color={Colors.red} />
            : <Switch value={isOnline} onValueChange={handleToggle}
                trackColor={{ false: Colors.border, true: Colors.green + '80' }}
                thumbColor={isOnline ? Colors.green : Colors.textMuted} />}
        </View>
      </View>

      {/* ── Map ── */}
      <View style={{ height: MAP_H }}>
        <CaptainMap activeRide={activeRide} captainLat={captainPos.lat} captainLng={captainPos.lng} />
        <View style={styles.mapBadge}>
          <View style={[styles.mapDot, { backgroundColor: isOnline ? Colors.green : Colors.textMuted }]} />
          <Text style={styles.mapBadgeText}>
            {activeRide
              ? (activeRide.status === 'inProgress' ? 'رحلة جارية' : 'في الطريق للراكب')
              : isOnline ? 'بحث عن طلبات...' : 'غير متاح'}
          </Text>
        </View>
        {captainLocation ? (
          <View style={styles.gpsBadge}>
            <View style={styles.gpsDot} />
            <Text style={styles.gpsText}>GPS مباشر</Text>
          </View>
        ) : null}
      </View>

      {/* ── Active ride banner ── */}
      {activeRide ? (
        <Pressable style={styles.activeBanner} onPress={() => setRideModal(true)}>
          <View style={styles.livePill}>
            <View style={styles.liveDot} />
            <Text style={styles.liveText}>{activeRide.status === 'inProgress' ? 'رحلة جارية' : 'تم القبول'}</Text>
          </View>
          <Text style={styles.bannerRoute} numberOfLines={1}>{activeRide.from_name} ← {activeRide.to_name}</Text>
          <View style={styles.row}>
            <Text style={styles.bannerPrice}>{Number(activeRide.price_jod).toFixed(3)} د.أ</Text>
            <Text style={styles.bannerTap}>اضغط للإدارة ←</Text>
          </View>
        </Pressable>
      ) : null}

      {/* ── Body ── */}
      {!isOnline ? (
        <View style={styles.center}>
          <MaterialIcons name="wifi-off" size={56} color={Colors.redDim} />
          <Text style={styles.bigTitle}>أنت غير متاح</Text>
          <Text style={styles.subTitle}>فعّل التوفر لاستقبال الطلبات</Text>
          <Pressable style={styles.goOnlineBtn} onPress={handleToggle}>
            <Text style={styles.goOnlineText}>تفعيل التوفر</Text>
          </Pressable>
        </View>
      ) : activeRide ? (
        <View style={styles.center}>
          <ActivityIndicator color={Colors.red} size="large" />
          <Text style={styles.bigTitle}>{activeRide.status === 'inProgress' ? 'الرحلة جارية' : 'في الطريق للراكب'}</Text>
          <Text style={styles.subTitle}>اضغط على البانر أعلاه لإدارة الرحلة</Text>
        </View>
      ) : (
        <FlatList
          data={pendingRequests}
          keyExtractor={i => i.id}
          renderItem={renderRequest}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={() => (
            <View style={styles.center}>
              <MaterialIcons name="search" size={52} color={Colors.redDim} />
              <Text style={styles.bigTitle}>لا توجد طلبات</Text>
              <Text style={styles.subTitle}>يتحدث تلقائياً كل 4 ثوانٍ</Text>
            </View>
          )}
        />
      )}

      {/* ── Active ride modal ── */}
      <Modal visible={rideModal} transparent animationType="slide" onRequestClose={() => setRideModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.handle} />
            <Text style={styles.modalTitle}>إدارة الرحلة</Text>

            {activeRide ? (
              <>
                {/* Route */}
                <View style={styles.route}>
                  <View style={styles.routeRow}>
                    <View style={[styles.dot, { backgroundColor: Colors.green }]} />
                    <Text style={styles.routeText}>{activeRide.from_name}</Text>
                  </View>
                  <View style={styles.routeDivider} />
                  <View style={styles.routeRow}>
                    <View style={[styles.dot, { backgroundColor: Colors.red }]} />
                    <Text style={styles.routeText}>{activeRide.to_name}</Text>
                  </View>
                </View>

                {/* Passenger info */}
                <View style={styles.passengerBox}>
                  <View style={styles.avatar}>
                    <MaterialIcons name="person" size={22} color={Colors.gold} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.passengerName}>{activeRide.passenger_name || 'راكب'}</Text>
                    {activeRide.passenger_phone ? <Text style={styles.phone}>{activeRide.passenger_phone}</Text> : null}
                  </View>
                  {activeRide.passenger_rating ? (
                    <View style={styles.ratingBadge}>
                      <MaterialIcons name="star" size={14} color={Colors.gold} />
                      <Text style={styles.ratingText}>{Number(activeRide.passenger_rating).toFixed(1)}</Text>
                    </View>
                  ) : null}
                </View>

                {/* Price */}
                <View style={styles.priceBox}>
                  <Text style={styles.priceBoxLabel}>السعر المتفق عليه</Text>
                  <Text style={styles.priceBoxValue}>{Number(activeRide.price_jod).toFixed(3)} د.أ</Text>
                </View>

                {/* Chat */}
                <Pressable style={styles.chatBtn}
                  onPress={() => { setRideModal(false); router.push({ pathname: '/chat', params: { rideId: activeRide.id, passengerName: activeRide.passenger_name || 'الراكب' } }); }}>
                  <MaterialIcons name="chat" size={20} color={Colors.gold} />
                  <Text style={styles.chatBtnText}>دردشة مع الراكب</Text>
                </Pressable>

                {/* Action button */}
                {activeRide.status === 'accepted' ? (
                  <Pressable style={[styles.primaryBtn, processingId === activeRide.id && { opacity: 0.6 }]}
                    onPress={handleStart} disabled={processingId === activeRide.id}>
                    {processingId === activeRide.id
                      ? <ActivityIndicator color="#fff" />
                      : <><MaterialIcons name="play-arrow" size={24} color="#fff" /><Text style={styles.primaryBtnText}>بدء الرحلة</Text></>}
                  </Pressable>
                ) : (
                  <Pressable style={[styles.completeBtn, processingId === activeRide.id && { opacity: 0.6 }]}
                    onPress={handleComplete} disabled={processingId === activeRide.id}>
                    {processingId === activeRide.id
                      ? <ActivityIndicator color="#fff" />
                      : <><MaterialIcons name="check-circle" size={24} color="#fff" /><Text style={styles.primaryBtnText}>إنهاء الرحلة</Text></>}
                  </Pressable>
                )}
              </>
            ) : null}

            <Pressable style={styles.closeBtn} onPress={() => setRideModal(false)}>
              <Text style={styles.closeBtnText}>إغلاق</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const C = Colors;
const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.background },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md, padding: Spacing.xxl },

  topBar: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: C.border,
  },
  greeting: { color: C.textPrimary, fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold, textAlign: 'right' },
  vehicleInfo: { color: C.textSecondary, fontSize: Typography.sizes.xs, textAlign: 'right', marginTop: 2 },
  toggleArea: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  statusLabel: { fontSize: Typography.sizes.sm, fontWeight: Typography.weights.semiBold },

  mapBadge: {
    position: 'absolute', top: 10, left: 12,
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: 'rgba(13,0,2,0.85)', borderRadius: Radius.full,
    paddingHorizontal: 12, paddingVertical: 6, borderWidth: 1, borderColor: C.border,
  },
  mapDot: { width: 8, height: 8, borderRadius: 4 },
  mapBadgeText: { color: C.textSecondary, fontSize: Typography.sizes.xs, fontWeight: Typography.weights.medium },
  gpsBadge: {
    position: 'absolute', bottom: 10, right: 12,
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: 'rgba(13,0,2,0.85)', borderRadius: Radius.full,
    paddingHorizontal: 10, paddingVertical: 5, borderWidth: 1, borderColor: C.green + '60',
  },
  gpsDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: C.green },
  gpsText: { color: C.green, fontSize: 10, fontWeight: Typography.weights.semiBold },

  activeBanner: {
    marginHorizontal: Spacing.base, marginTop: Spacing.md,
    backgroundColor: C.surfaceCard, borderRadius: Radius.lg,
    borderWidth: 1.5, borderColor: C.red, padding: Spacing.base, gap: Spacing.sm, ...Shadows.red,
  },
  livePill: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  liveDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: C.red },
  liveText: { color: C.red, fontSize: Typography.sizes.xs, fontWeight: Typography.weights.bold },
  bannerRoute: { color: C.textPrimary, fontSize: Typography.sizes.sm, fontWeight: Typography.weights.medium, textAlign: 'right' },
  bannerPrice: { color: C.gold, fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold },
  bannerTap: { color: C.textMuted, fontSize: Typography.sizes.xs },

  list: { padding: Spacing.base, gap: Spacing.base, paddingBottom: 100 },

  card: {
    backgroundColor: C.surfaceCard, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: C.border, padding: Spacing.base, gap: Spacing.md, ...Shadows.card,
  },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  price: { color: C.textPrimary, fontSize: Typography.sizes.xxl, fontWeight: Typography.weights.extraBold },
  priceCur: { color: C.textSecondary, fontSize: Typography.sizes.sm },
  tag: { backgroundColor: C.goldFaint, borderRadius: Radius.full, paddingHorizontal: 10, paddingVertical: 4, borderWidth: 1, borderColor: C.borderGold },
  tagText: { color: C.gold, fontSize: Typography.sizes.xs, fontWeight: Typography.weights.semiBold },

  passengerRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  passengerBox: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    backgroundColor: C.surface, borderRadius: Radius.md, padding: Spacing.md,
  },
  avatar: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: C.goldFaint, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: C.borderGold,
  },
  passengerName: { flex: 1, color: C.textPrimary, fontSize: Typography.sizes.base, fontWeight: Typography.weights.semiBold, textAlign: 'right' },
  phone: { color: C.textMuted, fontSize: Typography.sizes.xs },
  ratingBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: C.goldFaint, borderRadius: Radius.full, paddingHorizontal: 8, paddingVertical: 4,
  },
  ratingText: { color: C.gold, fontSize: Typography.sizes.xs, fontWeight: Typography.weights.semiBold },

  route: { backgroundColor: C.surface, borderRadius: Radius.md, padding: Spacing.md },
  routeRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm, paddingVertical: 5 },
  dot: { width: 10, height: 10, borderRadius: 5 },
  routeText: { flex: 1, color: C.textPrimary, fontSize: Typography.sizes.sm, textAlign: 'right' },
  routeDivider: { width: 1, height: 10, backgroundColor: C.border, marginRight: 4, alignSelf: 'flex-end' },

  actionRow: { flexDirection: 'row', gap: Spacing.md },
  rejectBtn: {
    flex: 0.38, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: 'rgba(255,68,68,0.1)', borderRadius: Radius.md, paddingVertical: 14,
    borderWidth: 1, borderColor: 'rgba(255,68,68,0.3)',
  },
  rejectText: { color: C.error, fontSize: Typography.sizes.base, fontWeight: Typography.weights.semiBold },
  acceptBtn: {
    flex: 0.62, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: C.green, borderRadius: Radius.md, paddingVertical: 14, ...Shadows.green,
  },
  acceptText: { color: '#fff', fontSize: Typography.sizes.base, fontWeight: Typography.weights.bold },

  bigTitle: { color: C.textPrimary, fontSize: Typography.sizes.xl, fontWeight: Typography.weights.bold, textAlign: 'center' },
  subTitle: { color: C.textMuted, fontSize: Typography.sizes.base, textAlign: 'center' },
  goOnlineBtn: {
    backgroundColor: C.red, borderRadius: Radius.md,
    paddingHorizontal: Spacing.xl, paddingVertical: 14, marginTop: Spacing.lg, ...Shadows.red,
  },
  goOnlineText: { color: '#fff', fontSize: Typography.sizes.base, fontWeight: Typography.weights.bold },

  modalOverlay: { flex: 1, backgroundColor: C.overlay, justifyContent: 'flex-end' },
  modalCard: {
    backgroundColor: C.surface, borderTopLeftRadius: Radius.xxl, borderTopRightRadius: Radius.xxl,
    padding: Spacing.xl, gap: Spacing.base, borderWidth: 1, borderColor: C.border, paddingBottom: 36,
  },
  handle: { width: 40, height: 4, borderRadius: 2, backgroundColor: C.border, alignSelf: 'center', marginBottom: Spacing.sm },
  modalTitle: { color: C.textPrimary, fontSize: Typography.sizes.xl, fontWeight: Typography.weights.bold, textAlign: 'right' },
  priceBox: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: C.surfaceCard, borderRadius: Radius.md, padding: Spacing.base,
    borderWidth: 1, borderColor: C.borderGold,
  },
  priceBoxLabel: { color: C.textSecondary, fontSize: Typography.sizes.sm },
  priceBoxValue: { color: C.gold, fontSize: Typography.sizes.xxl, fontWeight: Typography.weights.bold },
  chatBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm,
    backgroundColor: C.goldFaint, borderRadius: Radius.md,
    paddingVertical: 12, borderWidth: 1, borderColor: C.borderGold,
  },
  chatBtnText: { color: C.gold, fontSize: Typography.sizes.base, fontWeight: Typography.weights.semiBold },
  primaryBtn: {
    backgroundColor: C.red, borderRadius: Radius.md,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm,
    paddingVertical: 16, ...Shadows.red,
  },
  completeBtn: {
    backgroundColor: C.green, borderRadius: Radius.md,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm,
    paddingVertical: 16, ...Shadows.green,
  },
  primaryBtnText: { color: '#fff', fontSize: Typography.sizes.base, fontWeight: Typography.weights.bold },
  closeBtn: { paddingVertical: 12, alignItems: 'center' },
  closeBtnText: { color: C.textMuted, fontSize: Typography.sizes.base },
});
