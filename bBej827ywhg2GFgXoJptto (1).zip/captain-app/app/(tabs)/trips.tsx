// Captain trip history screen
import React, { useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, Pressable } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRide } from '@/contexts/RideContext';
import { Colors, Typography, Spacing, Radius, Shadows } from '@/constants/theme';

export default function TripsScreen() {
  const insets = useSafeAreaInsets();
  const { completedTrips, isLoadingRequests, fetchHistory } = useRide();

  useEffect(() => { fetchHistory(); }, []);

  const totalEarnings = completedTrips.reduce((sum, t) => sum + Number(t.price_jod), 0);

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>سجل الرحلات</Text>
        <Pressable onPress={fetchHistory} style={styles.refreshBtn}>
          <MaterialIcons name="refresh" size={20} color={Colors.red} />
        </Pressable>
      </View>

      {/* Summary */}
      <View style={styles.summaryRow}>
        <View style={styles.summaryCard}>
          <Text style={styles.summaryValue}>{completedTrips.length}</Text>
          <Text style={styles.summaryLabel}>رحلة مكتملة</Text>
        </View>
        <View style={styles.summaryCard}>
          <Text style={styles.summaryValue}>{totalEarnings.toFixed(3)}</Text>
          <Text style={styles.summaryLabel}>إجمالي الأرباح د.أ</Text>
        </View>
      </View>

      {isLoadingRequests ? (
        <View style={styles.center}>
          <ActivityIndicator color={Colors.red} size="large" />
        </View>
      ) : (
        <FlatList
          data={completedTrips}
          keyExtractor={i => i.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <View style={styles.tripCard}>
              <View style={styles.tripHeader}>
                <Text style={styles.tripDate}>
                  {new Date(item.created_at).toLocaleDateString('ar-JO', { month: 'short', day: 'numeric', year: 'numeric' })}
                </Text>
                <Text style={styles.tripPrice}>{Number(item.price_jod).toFixed(3)} د.أ</Text>
              </View>
              <View style={styles.route}>
                <View style={styles.routeRow}>
                  <View style={[styles.dot, { backgroundColor: Colors.green }]} />
                  <Text style={styles.routeText} numberOfLines={1}>{item.from_name}</Text>
                </View>
                <View style={styles.routeDivider} />
                <View style={styles.routeRow}>
                  <View style={[styles.dot, { backgroundColor: Colors.red }]} />
                  <Text style={styles.routeText} numberOfLines={1}>{item.to_name}</Text>
                </View>
              </View>
            </View>
          )}
          ListEmptyComponent={() => (
            <View style={styles.center}>
              <MaterialIcons name="history" size={52} color={Colors.redDim} />
              <Text style={styles.emptyTitle}>لا توجد رحلات مكتملة</Text>
              <Text style={styles.emptySubtitle}>ستظهر رحلاتك المكتملة هنا</Text>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md, padding: Spacing.xxl },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  headerTitle: { color: Colors.textPrimary, fontSize: Typography.sizes.xl, fontWeight: Typography.weights.bold },
  refreshBtn: { padding: 8 },
  summaryRow: { flexDirection: 'row', gap: Spacing.md, padding: Spacing.base },
  summaryCard: {
    flex: 1, backgroundColor: Colors.surfaceCard, borderRadius: Radius.lg,
    padding: Spacing.base, alignItems: 'center', gap: 4,
    borderWidth: 1, borderColor: Colors.border, ...Shadows.card,
  },
  summaryValue: { color: Colors.gold, fontSize: Typography.sizes.xxl, fontWeight: Typography.weights.bold },
  summaryLabel: { color: Colors.textMuted, fontSize: Typography.sizes.xs, textAlign: 'center' },
  list: { padding: Spacing.base, gap: Spacing.md, paddingBottom: 100 },
  tripCard: {
    backgroundColor: Colors.surfaceCard, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, padding: Spacing.base, gap: Spacing.md,
  },
  tripHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  tripDate: { color: Colors.textMuted, fontSize: Typography.sizes.sm },
  tripPrice: { color: Colors.gold, fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold },
  route: { backgroundColor: Colors.surface, borderRadius: Radius.md, padding: Spacing.md },
  routeRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm, paddingVertical: 5 },
  dot: { width: 10, height: 10, borderRadius: 5 },
  routeText: { flex: 1, color: Colors.textPrimary, fontSize: Typography.sizes.sm, textAlign: 'right' },
  routeDivider: { width: 1, height: 10, backgroundColor: Colors.border, marginRight: 4, alignSelf: 'flex-end' },
  emptyTitle: { color: Colors.textPrimary, fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold },
  emptySubtitle: { color: Colors.textMuted, fontSize: Typography.sizes.sm, textAlign: 'center' },
});
