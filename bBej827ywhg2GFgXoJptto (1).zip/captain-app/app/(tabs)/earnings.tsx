import React, { useEffect, useMemo, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable, Dimensions,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRide } from '@/contexts/RideContext';
import { useCaptainAuth } from '@/contexts/CaptainAuthContext';
import { Colors, Typography, Spacing, Radius, Shadows } from '@/constants/theme';

const SCREEN_W = Dimensions.get('window').width;
const CHART_H = 140;
const BAR_COUNT = 7;

type Period = 'day' | 'week' | 'month';

const DAY_LABELS = ['أح', 'إث', 'ث', 'أر', 'خ', 'ج', 'س'];

export default function EarningsScreen() {
  const insets = useSafeAreaInsets();
  const { captain } = useCaptainAuth();
  const { completedTrips, fetchHistory } = useRide();
  const [period, setPeriod] = useState<Period>('week');

  useEffect(() => { fetchHistory(); }, []);

  // ── Date helpers ──────────────────────────────────────────────────────────
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const startOf = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());

  const startOfWeek = new Date(startOf(now));
  startOfWeek.setDate(now.getDate() - now.getDay());

  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const monthAgo = new Date(Date.now() - 30 * 86400000);
  const weekAgo = new Date(Date.now() - 7 * 86400000);

  // ── Aggregated metrics ────────────────────────────────────────────────────
  const todayTrips = useMemo(
    () => completedTrips.filter(t => t.created_at.startsWith(todayStr)),
    [completedTrips, todayStr]
  );
  const weekTrips = useMemo(
    () => completedTrips.filter(t => new Date(t.created_at) >= startOfWeek),
    [completedTrips]
  );
  const monthTrips = useMemo(
    () => completedTrips.filter(t => new Date(t.created_at) >= startOfMonth),
    [completedTrips]
  );

  const todayEarn = todayTrips.reduce((s, t) => s + Number(t.price_jod), 0);
  const weekEarn = weekTrips.reduce((s, t) => s + Number(t.price_jod), 0);
  const monthEarn = monthTrips.reduce((s, t) => s + Number(t.price_jod), 0);
  const totalEarn = completedTrips.reduce((s, t) => s + Number(t.price_jod), 0);

  // ── Weekly bar chart data (last 7 days) ───────────────────────────────────
  const chartData = useMemo(() => {
    const days: { label: string; value: number; date: Date }[] = [];
    for (let i = BAR_COUNT - 1; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      const dayStr = d.toISOString().split('T')[0];
      const trips = completedTrips.filter(t => t.created_at.startsWith(dayStr));
      const total = trips.reduce((s, t) => s + Number(t.price_jod), 0);
      days.push({ label: DAY_LABELS[d.getDay()], value: total, date: d });
    }
    return days;
  }, [completedTrips]);

  const maxBar = Math.max(...chartData.map(d => d.value), 1);

  // ── Period selector data ──────────────────────────────────────────────────
  const selectedTrips = period === 'day' ? todayTrips : period === 'week' ? weekTrips : monthTrips;
  const selectedEarn = period === 'day' ? todayEarn : period === 'week' ? weekEarn : monthEarn;

  // ── Recent trips ──────────────────────────────────────────────────────────
  const recentTrips = useMemo(
    () => [...completedTrips].sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    ).slice(0, 10),
    [completedTrips]
  );

  // ── Average per trip ──────────────────────────────────────────────────────
  const avgPerTrip = completedTrips.length > 0 ? totalEarn / completedTrips.length : 0;

  return (
    <ScrollView
      style={[styles.root, { paddingTop: insets.top }]}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>الأرباح</Text>
        <View style={styles.captainBadge}>
          <Text style={styles.captainBadgeName}>{captain?.name_ar ?? 'الكابتن'}</Text>
          <View style={styles.ratingPill}>
            <MaterialIcons name="star" size={12} color={Colors.gold} />
            <Text style={styles.ratingPillText}>{Number(captain?.rating ?? 5).toFixed(1)}</Text>
          </View>
        </View>
      </View>

      {/* Summary total card */}
      <View style={styles.totalCard}>
        <View style={styles.totalLeft}>
          <Text style={styles.totalLabelText}>إجمالي الأرباح</Text>
          <Text style={styles.totalValueText}>
            {totalEarn.toFixed(3)}
            <Text style={styles.totalCurrency}> د.أ</Text>
          </Text>
          <Text style={styles.totalSubText}>{completedTrips.length} رحلة مكتملة</Text>
        </View>
        <View style={styles.totalRight}>
          <View style={styles.totalIcon}>
            <MaterialIcons name="account-balance-wallet" size={36} color={Colors.gold} />
          </View>
        </View>
      </View>

      {/* Quick stat grid */}
      <View style={styles.statGrid}>
        <StatCard
          icon="today"
          iconColor={Colors.primary}
          label="اليوم"
          value={todayEarn.toFixed(3)}
          sub={`${todayTrips.length} رحلة`}
        />
        <StatCard
          icon="date-range"
          iconColor={Colors.gold}
          label="هذا الأسبوع"
          value={weekEarn.toFixed(3)}
          sub={`${weekTrips.length} رحلة`}
        />
        <StatCard
          icon="calendar-month"
          iconColor={Colors.success}
          label="هذا الشهر"
          value={monthEarn.toFixed(3)}
          sub={`${monthTrips.length} رحلة`}
        />
      </View>

      {/* Weekly Bar Chart */}
      <View style={styles.chartCard}>
        <View style={styles.chartHeader}>
          <Text style={styles.chartTitle}>أداء آخر 7 أيام</Text>
          <Text style={styles.chartSub}>بالدينار الأردني</Text>
        </View>

        <View style={styles.chartArea}>
          {/* Y-axis labels */}
          <View style={styles.yAxis}>
            <Text style={styles.yLabel}>{maxBar.toFixed(1)}</Text>
            <Text style={styles.yLabel}>{(maxBar / 2).toFixed(1)}</Text>
            <Text style={styles.yLabel}>0</Text>
          </View>

          {/* Bars */}
          <View style={styles.barsContainer}>
            {chartData.map((day, idx) => {
              const isToday = idx === BAR_COUNT - 1;
              const heightPct = maxBar > 0 ? day.value / maxBar : 0;
              const barH = Math.max(4, heightPct * (CHART_H - 24));
              return (
                <View key={idx} style={styles.barColumn}>
                  {day.value > 0 ? (
                    <Text style={styles.barValue}>{day.value.toFixed(1)}</Text>
                  ) : null}
                  <View style={styles.barTrack}>
                    <View
                      style={[
                        styles.bar,
                        { height: barH },
                        isToday ? styles.barToday : styles.barNormal,
                      ]}
                    />
                  </View>
                  <Text style={[styles.barLabel, isToday && styles.barLabelToday]}>
                    {day.label}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>
      </View>

      {/* Period selector + details */}
      <View style={styles.section}>
        <View style={styles.periodSelector}>
          {([['day', 'اليوم'], ['week', 'الأسبوع'], ['month', 'الشهر']] as [Period, string][]).map(([p, label]) => (
            <Pressable
              key={p}
              style={[styles.periodBtn, period === p && styles.periodBtnActive]}
              onPress={() => setPeriod(p)}
            >
              <Text style={[styles.periodBtnText, period === p && styles.periodBtnTextActive]}>
                {label}
              </Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.periodSummary}>
          <View style={styles.periodSummaryRow}>
            <View style={styles.periodSummaryItem}>
              <Text style={styles.periodSummaryValue}>{selectedEarn.toFixed(3)}</Text>
              <Text style={styles.periodSummaryLabel}>الأرباح (د.أ)</Text>
            </View>
            <View style={styles.periodDivider} />
            <View style={styles.periodSummaryItem}>
              <Text style={styles.periodSummaryValue}>{selectedTrips.length}</Text>
              <Text style={styles.periodSummaryLabel}>عدد الرحلات</Text>
            </View>
            <View style={styles.periodDivider} />
            <View style={styles.periodSummaryItem}>
              <Text style={styles.periodSummaryValue}>
                {selectedTrips.length > 0
                  ? (selectedEarn / selectedTrips.length).toFixed(3)
                  : '0.000'}
              </Text>
              <Text style={styles.periodSummaryLabel}>متوسط الرحلة</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Performance metrics */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>الأداء الإجمالي</Text>
        <View style={styles.perfRow}>
          <PerfCard icon="star" iconColor={Colors.gold} label="التقييم" value={Number(captain?.rating ?? 5).toFixed(1)} />
          <PerfCard icon="route" iconColor={Colors.primary} label="إجمالي الرحلات" value={String(captain?.total_trips ?? 0)} />
          <PerfCard icon="trending-up" iconColor={Colors.success} label="متوسط الرحلة" value={avgPerTrip.toFixed(3)} />
        </View>
      </View>

      {/* Recent trips list */}
      {recentTrips.length > 0 ? (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>آخر الرحلات</Text>
          <View style={styles.tripsList}>
            {recentTrips.map((trip, idx) => {
              const d = new Date(trip.created_at);
              const timeStr = `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
              const dateStr = d.toLocaleDateString('ar-JO', { day: 'numeric', month: 'short' });
              return (
                <View key={trip.id ?? idx} style={[styles.tripItem, idx > 0 && styles.tripItemBorder]}>
                  <View style={styles.tripIcon}>
                    <MaterialIcons name="directions-car" size={18} color={Colors.red} />
                  </View>
                  <View style={styles.tripInfo}>
                    <Text style={styles.tripFrom} numberOfLines={1}>
                      {trip.from_name ?? 'الموقع الحالي'}
                    </Text>
                    <Text style={styles.tripTo} numberOfLines={1}>
                      {trip.to_name ?? 'الوجهة'}
                    </Text>
                    <Text style={styles.tripTime}>{dateStr} · {timeStr}</Text>
                  </View>
                  <View style={styles.tripEarn}>
                    <Text style={styles.tripEarnValue}>{Number(trip.price_jod).toFixed(3)}</Text>
                    <Text style={styles.tripEarnCur}>د.أ</Text>
                  </View>
                </View>
              );
            })}
          </View>
        </View>
      ) : (
        <View style={styles.emptyState}>
          <MaterialIcons name="receipt-long" size={48} color={Colors.redDim} />
          <Text style={styles.emptyTitle}>لا توجد رحلات بعد</Text>
          <Text style={styles.emptySubtitle}>ابدأ بقبول الطلبات لرؤية أرباحك هنا</Text>
        </View>
      )}
    </ScrollView>
  );
}

// ── Sub-components ─────────────────────────────────────────────────────────────
function StatCard({ icon, iconColor, label, value, sub }: {
  icon: string; iconColor: string; label: string; value: string; sub: string;
}) {
  return (
    <View style={styles.statCard}>
      <View style={[styles.statIconWrap, { backgroundColor: iconColor + '18' }]}>
        <MaterialIcons name={icon as any} size={20} color={iconColor} />
      </View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statSub}>{sub}</Text>
    </View>
  );
}

function PerfCard({ icon, iconColor, label, value }: {
  icon: string; iconColor: string; label: string; value: string;
}) {
  return (
    <View style={styles.perfCard}>
      <MaterialIcons name={icon as any} size={22} color={iconColor} />
      <Text style={styles.perfValue}>{value}</Text>
      <Text style={styles.perfLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background },

  // Header
  header: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  headerTitle: {
    color: Colors.textPrimary, fontSize: Typography.sizes.xl, fontWeight: Typography.weights.bold,
  },
  captainBadge: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.sm },
  captainBadgeName: { color: Colors.textSecondary, fontSize: Typography.sizes.sm },
  ratingPill: {
    flexDirection: 'row', alignItems: 'center', gap: 2,
    backgroundColor: Colors.goldFaint, borderRadius: Radius.full,
    paddingHorizontal: 8, paddingVertical: 3, borderWidth: 1, borderColor: Colors.borderGold,
  },
  ratingPillText: { color: Colors.gold, fontSize: Typography.sizes.xs, fontWeight: Typography.weights.bold },

  // Total card
  totalCard: {
    flexDirection: 'row-reverse', alignItems: 'center',
    margin: Spacing.base, borderRadius: Radius.xxl, padding: Spacing.xl,
    backgroundColor: Colors.surfaceCard, borderWidth: 1.5, borderColor: Colors.borderGold,
    ...Shadows.gold,
  },
  totalLeft: { flex: 1, gap: 6, alignItems: 'flex-end' },
  totalRight: {},
  totalLabelText: { color: Colors.textSecondary, fontSize: Typography.sizes.sm },
  totalValueText: {
    color: Colors.gold, fontSize: 36, fontWeight: Typography.weights.extraBold,
  },
  totalCurrency: { color: Colors.textSecondary, fontSize: Typography.sizes.lg },
  totalSubText: { color: Colors.textMuted, fontSize: Typography.sizes.xs },
  totalIcon: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: Colors.goldFaint, borderWidth: 1, borderColor: Colors.borderGold,
    alignItems: 'center', justifyContent: 'center', marginLeft: Spacing.base,
  },

  // Stat grid
  statGrid: {
    flexDirection: 'row', paddingHorizontal: Spacing.base, gap: Spacing.sm, marginBottom: Spacing.base,
  },
  statCard: {
    flex: 1, backgroundColor: Colors.surfaceCard, borderRadius: Radius.xl,
    padding: Spacing.md, alignItems: 'center', gap: 4,
    borderWidth: 1, borderColor: Colors.border, ...Shadows.card,
  },
  statIconWrap: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', marginBottom: 2 },
  statValue: {
    color: Colors.textPrimary, fontSize: Typography.sizes.base, fontWeight: Typography.weights.bold,
    textAlign: 'center',
  },
  statLabel: { color: Colors.textSecondary, fontSize: 10, textAlign: 'center' },
  statSub: { color: Colors.textMuted, fontSize: 10, textAlign: 'center' },

  // Chart
  chartCard: {
    marginHorizontal: Spacing.base, marginBottom: Spacing.base,
    backgroundColor: Colors.surfaceCard, borderRadius: Radius.xl,
    padding: Spacing.base, borderWidth: 1, borderColor: Colors.border, ...Shadows.card,
  },
  chartHeader: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.base },
  chartTitle: { color: Colors.textPrimary, fontSize: Typography.sizes.base, fontWeight: Typography.weights.semiBold },
  chartSub: { color: Colors.textMuted, fontSize: Typography.sizes.xs },
  chartArea: { flexDirection: 'row-reverse', alignItems: 'flex-end', height: CHART_H },
  yAxis: {
    width: 40, height: CHART_H - 24, justifyContent: 'space-between',
    alignItems: 'flex-end', paddingRight: Spacing.sm, paddingBottom: 0,
  },
  yLabel: { color: Colors.textMuted, fontSize: 9 },
  barsContainer: {
    flex: 1, flexDirection: 'row-reverse', alignItems: 'flex-end',
    justifyContent: 'space-around', height: CHART_H,
  },
  barColumn: { alignItems: 'center', gap: 3, flex: 1 },
  barValue: { color: Colors.gold, fontSize: 8, fontWeight: Typography.weights.bold },
  barTrack: { height: CHART_H - 24, justifyContent: 'flex-end' },
  bar: { width: 20, borderRadius: 4, minHeight: 4 },
  barNormal: { backgroundColor: Colors.redDim + 'CC' },
  barToday: { backgroundColor: Colors.gold },
  barLabel: { color: Colors.textMuted, fontSize: 10 },
  barLabelToday: { color: Colors.gold, fontWeight: Typography.weights.bold },

  // Period selector
  section: { marginHorizontal: Spacing.base, marginBottom: Spacing.base, gap: Spacing.sm },
  sectionTitle: {
    color: Colors.textPrimary, fontSize: Typography.sizes.base,
    fontWeight: Typography.weights.semiBold, textAlign: 'right',
  },
  periodSelector: {
    flexDirection: 'row-reverse', backgroundColor: Colors.surface,
    borderRadius: Radius.full, padding: 3,
    borderWidth: 1, borderColor: Colors.border,
  },
  periodBtn: { flex: 1, paddingVertical: 8, borderRadius: Radius.full, alignItems: 'center' },
  periodBtnActive: { backgroundColor: Colors.red, ...Shadows.red },
  periodBtnText: { color: Colors.textMuted, fontSize: Typography.sizes.sm },
  periodBtnTextActive: { color: '#fff', fontWeight: Typography.weights.bold },
  periodSummary: {
    backgroundColor: Colors.surfaceCard, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, overflow: 'hidden',
  },
  periodSummaryRow: { flexDirection: 'row-reverse' },
  periodSummaryItem: { flex: 1, padding: Spacing.base, alignItems: 'center', gap: 4 },
  periodDivider: { width: 1, backgroundColor: Colors.border, marginVertical: Spacing.md },
  periodSummaryValue: {
    color: Colors.textPrimary, fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold,
  },
  periodSummaryLabel: { color: Colors.textMuted, fontSize: 10, textAlign: 'center' },

  // Perf row
  perfRow: { flexDirection: 'row', gap: Spacing.sm },
  perfCard: {
    flex: 1, backgroundColor: Colors.surfaceCard, borderRadius: Radius.xl,
    padding: Spacing.base, alignItems: 'center', gap: 6,
    borderWidth: 1, borderColor: Colors.border,
  },
  perfValue: { color: Colors.textPrimary, fontSize: Typography.sizes.xl, fontWeight: Typography.weights.bold },
  perfLabel: { color: Colors.textMuted, fontSize: 10, textAlign: 'center' },

  // Trips list
  tripsList: {
    backgroundColor: Colors.surfaceCard, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, overflow: 'hidden',
  },
  tripItem: { flexDirection: 'row-reverse', alignItems: 'center', gap: Spacing.md, padding: Spacing.base },
  tripItemBorder: { borderTopWidth: 1, borderTopColor: Colors.border },
  tripIcon: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: Colors.redFaint, alignItems: 'center', justifyContent: 'center',
  },
  tripInfo: { flex: 1, gap: 2, alignItems: 'flex-end' },
  tripFrom: {
    color: Colors.textPrimary, fontSize: Typography.sizes.sm, fontWeight: Typography.weights.semiBold,
  },
  tripTo: { color: Colors.textSecondary, fontSize: Typography.sizes.xs },
  tripTime: { color: Colors.textMuted, fontSize: 10 },
  tripEarn: { alignItems: 'center', gap: 1 },
  tripEarnValue: { color: Colors.gold, fontSize: Typography.sizes.base, fontWeight: Typography.weights.bold },
  tripEarnCur: { color: Colors.textMuted, fontSize: 9 },

  // Empty state
  emptyState: {
    alignItems: 'center', paddingVertical: Spacing.xxxl, gap: Spacing.md,
    marginHorizontal: Spacing.base,
  },
  emptyTitle: { color: Colors.textPrimary, fontSize: Typography.sizes.base, fontWeight: Typography.weights.semiBold },
  emptySubtitle: { color: Colors.textMuted, fontSize: Typography.sizes.sm, textAlign: 'center' },
});
