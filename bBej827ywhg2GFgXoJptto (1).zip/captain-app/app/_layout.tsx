import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { View, Text, StyleSheet, Pressable, Modal, Animated } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { CaptainAuthProvider } from '@/contexts/CaptainAuthContext';
import { RideProvider } from '@/contexts/RideContext';
import { useEffect } from 'react';
import { requestNotificationPermission } from '@/services/notificationService';

// ── Simple inline Alert system (no external template needed) ─────────────────
interface AlertButton {
  text: string;
  style?: 'default' | 'cancel' | 'destructive';
  onPress?: () => void;
}
interface AlertContextType {
  showAlert: (title: string, message?: string, buttons?: AlertButton[]) => void;
}
const AlertCtx = createContext<AlertContextType>({ showAlert: () => {} });
export const useAlert = () => useContext(AlertCtx);

function AlertProvider({ children }: { children: ReactNode }) {
  const [visible, setVisible] = useState(false);
  const [alertTitle, setAlertTitle] = useState('');
  const [alertMessage, setAlertMessage] = useState('');
  const [buttons, setButtons] = useState<AlertButton[]>([]);

  const showAlert = useCallback((title: string, message?: string, btns?: AlertButton[]) => {
    setAlertTitle(title);
    setAlertMessage(message ?? '');
    setButtons(btns ?? [{ text: 'حسناً', style: 'default' }]);
    setVisible(true);
  }, []);

  return (
    <AlertCtx.Provider value={{ showAlert }}>
      {children}
      <Modal visible={visible} transparent animationType="fade" onRequestClose={() => setVisible(false)}>
        <View style={alertStyles.overlay}>
          <View style={alertStyles.card}>
            <Text style={alertStyles.title}>{alertTitle}</Text>
            {alertMessage ? <Text style={alertStyles.message}>{alertMessage}</Text> : null}
            <View style={alertStyles.btnRow}>
              {buttons.map((btn, i) => (
                <Pressable
                  key={i}
                  style={[alertStyles.btn, btn.style === 'destructive' && alertStyles.btnDestructive, btn.style === 'cancel' && alertStyles.btnCancel]}
                  onPress={() => { setVisible(false); btn.onPress?.(); }}
                >
                  <Text style={[alertStyles.btnText, btn.style === 'destructive' && alertStyles.btnTextDestructive]}>
                    {btn.text}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        </View>
      </Modal>
    </AlertCtx.Provider>
  );
}

const alertStyles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', alignItems: 'center', justifyContent: 'center', padding: 32 },
  card: { backgroundColor: '#1A0005', borderRadius: 20, padding: 24, width: '100%', borderWidth: 1, borderColor: '#3A0010', gap: 12 },
  title: { color: '#F5F0E8', fontSize: 18, fontWeight: '700', textAlign: 'center' },
  message: { color: '#C4A8B0', fontSize: 14, textAlign: 'center', lineHeight: 22 },
  btnRow: { flexDirection: 'row', gap: 10, marginTop: 4 },
  btn: { flex: 1, backgroundColor: '#CC1020', borderRadius: 12, paddingVertical: 13, alignItems: 'center' },
  btnCancel: { backgroundColor: '#3A0010' },
  btnDestructive: { backgroundColor: '#FF4444' },
  btnText: { color: '#fff', fontSize: 15, fontWeight: '600' },
  btnTextDestructive: { color: '#fff' },
});

// ── Notification setup ────────────────────────────────────────────────────────
function NotificationSetup() {
  useEffect(() => {
    requestNotificationPermission()
      .then((granted) => {
        if (granted) console.log('[App] Notification permission granted');
      })
      .catch(() => {});
  }, []);
  return null;
}

// ── Root layout ───────────────────────────────────────────────────────────────
export default function RootLayout() {
  return (
    <AlertProvider>
      <SafeAreaProvider>
        <CaptainAuthProvider>
          <RideProvider>
            <NotificationSetup />
            <StatusBar style="light" backgroundColor="#0D0002" />
            <Stack
              screenOptions={{
                headerShown: false,
                contentStyle: { backgroundColor: '#0D0002' },
                animation: 'fade_from_bottom',
              }}
            >
              <Stack.Screen name="index" options={{ animation: 'fade' }} />
              <Stack.Screen name="login" options={{ animation: 'slide_from_right' }} />
              <Stack.Screen name="(tabs)" options={{ animation: 'fade' }} />
              <Stack.Screen name="register" options={{ animation: 'slide_from_right' }} />
              <Stack.Screen name="chat" options={{ animation: 'slide_from_right' }} />
              <Stack.Screen name="rate-ride" options={{ animation: 'slide_from_bottom' }} />
            </Stack>
          </RideProvider>
        </CaptainAuthProvider>
      </SafeAreaProvider>
    </AlertProvider>
  );
}
