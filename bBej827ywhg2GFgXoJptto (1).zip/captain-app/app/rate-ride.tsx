/**
 * Captain rates the passenger after completing a ride
 * Route: /rate-ride?rideId=xxx&passengerName=xxx
 */
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, Pressable, TextInput,
  ActivityIndicator, KeyboardAvoidingView, Platform,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getSupabase } from '@/contexts/CaptainAuthContext';
import { Colors, Typography, Spacing, Radius, Shadows } from '@/constants/theme';

export default function RateRideScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { rideId, passengerName, captainId } = useLocalSearchParams<{
    rideId: string;
    passengerName: string;
    captainId: string;
  }>();
  const supabase = getSupabase();

  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    if (rating === 0) return;
    setSubmitting(true);
    try {
      // Save captain's rating for this passenger in ride_requests
      await supabase
        .from('ride_requests')
        .update({
          captain_rating: rating,
          captain_review: review || null,
        })
        .eq('id', rideId);

      // Update captain's own average rating in captain_profiles
      if (captainId) {
        await supabase.rpc('update_captain_rating', { p_captain_id: captainId }).catch(() => {});
      }

      setSubmitted(true);
      setTimeout(() => router.replace('/(tabs)'), 1800);
    } catch (e) {
      console.error(e);
    } finally {
      setSubmitting(false);
    }
  };

  const handleSkip = () => {
    router.replace('/(tabs)');
  };

  if (submitted) {
    return (
      <View style={[styles.root, styles.center, { paddingTop: insets.top }]}>
        <View style={styles.successIcon}>
          <MaterialIcons name="check-circle" size={64} color={Colors.green} />
        </View>
        <Text style={styles.successTitle}>شكراً على تقييمك!</Text>
        <Text style={styles.successSub}>يساعدنا تقييمك في تحسين الخدمة</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={[styles.root, { paddingTop: insets.top }]}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.container}>
        {/* Icon */}
        <View style={styles.iconBox}>
          <MaterialIcons name="star-rate" size={52} color={Colors.gold} />
        </View>

        <Text style={styles.title}>كيف كانت الرحلة؟</Text>
        <Text style={styles.subtitle}>قيّم الراكب: {passengerName || 'الراكب'}</Text>

        {/* Stars */}
        <View style={styles.starsRow}>
          {[1, 2, 3, 4, 5].map((star) => (
            <Pressable key={star} onPress={() => setRating(star)} hitSlop={8}>
              <MaterialIcons
                name={star <= rating ? 'star' : 'star-outline'}
                size={48}
                color={star <= rating ? Colors.gold : Colors.border}
              />
            </Pressable>
          ))}
        </View>

        {/* Labels */}
        {rating > 0 ? (
          <Text style={styles.ratingLabel}>
            {rating === 1 ? 'سيء جداً' :
             rating === 2 ? 'سيء' :
             rating === 3 ? 'مقبول' :
             rating === 4 ? 'جيد' : 'ممتاز! 🌟'}
          </Text>
        ) : (
          <Text style={styles.tapHint}>اضغط على النجوم لتقييم الراكب</Text>
        )}

        {/* Comment */}
        <View style={styles.commentBox}>
          <TextInput
            style={styles.commentInput}
            value={review}
            onChangeText={setReview}
            placeholder="أضف ملاحظة (اختياري)..."
            placeholderTextColor={Colors.textMuted}
            multiline
            maxLength={300}
            textAlign="right"
          />
        </View>

        {/* Buttons */}
        <Pressable
          style={[styles.submitBtn, (rating === 0 || submitting) && styles.submitBtnDisabled]}
          onPress={handleSubmit}
          disabled={rating === 0 || submitting}
        >
          {submitting
            ? <ActivityIndicator color="#fff" />
            : <Text style={styles.submitBtnText}>إرسال التقييم</Text>}
        </Pressable>

        <Pressable style={styles.skipBtn} onPress={handleSkip}>
          <Text style={styles.skipText}>تخطي</Text>
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background },
  center: { alignItems: 'center', justifyContent: 'center' },
  container: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: Spacing.xxl, gap: Spacing.lg,
  },

  iconBox: {
    width: 100, height: 100, borderRadius: 28,
    backgroundColor: Colors.goldFaint, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: Colors.borderGold, ...Shadows.gold,
  },
  title: { color: Colors.textPrimary, fontSize: Typography.sizes.xxl, fontWeight: Typography.weights.bold, textAlign: 'center' },
  subtitle: { color: Colors.textSecondary, fontSize: Typography.sizes.base, textAlign: 'center' },

  starsRow: { flexDirection: 'row', gap: Spacing.sm },
  ratingLabel: {
    color: Colors.gold, fontSize: Typography.sizes.lg,
    fontWeight: Typography.weights.semiBold, textAlign: 'center',
  },
  tapHint: { color: Colors.textMuted, fontSize: Typography.sizes.sm, textAlign: 'center' },

  commentBox: {
    width: '100%', backgroundColor: Colors.surfaceCard,
    borderRadius: Radius.xl, borderWidth: 1, borderColor: Colors.border,
    padding: Spacing.base, minHeight: 80,
  },
  commentInput: {
    color: Colors.textPrimary, fontSize: Typography.sizes.base, minHeight: 60, lineHeight: 22,
  },

  submitBtn: {
    width: '100%', backgroundColor: Colors.red, borderRadius: Radius.md,
    paddingVertical: 16, alignItems: 'center', ...Shadows.red,
  },
  submitBtnDisabled: { opacity: 0.4 },
  submitBtnText: { color: '#fff', fontSize: Typography.sizes.base, fontWeight: Typography.weights.bold },

  skipBtn: { paddingVertical: 12, alignItems: 'center' },
  skipText: { color: Colors.textMuted, fontSize: Typography.sizes.base },

  successIcon: {
    width: 110, height: 110, borderRadius: 30,
    backgroundColor: Colors.green + '20', alignItems: 'center', justifyContent: 'center',
  },
  successTitle: { color: Colors.textPrimary, fontSize: Typography.sizes.xxl, fontWeight: Typography.weights.bold },
  successSub: { color: Colors.textMuted, fontSize: Typography.sizes.base, textAlign: 'center' },
});
