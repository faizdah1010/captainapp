// Real-time chat between captain and passenger via ride_messages (polling 3s)
import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TextInput,
  Pressable, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getSupabase } from '@/contexts/CaptainAuthContext';
import { useCaptainAuth } from '@/contexts/CaptainAuthContext';
import { Colors, Typography, Spacing, Radius, Shadows } from '@/constants/theme';

interface Message {
  id: string;
  sender_id: string;
  sender_role: 'passenger' | 'captain';
  message: string;
  created_at: string;
}

export default function ChatScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { rideId, passengerName } = useLocalSearchParams<{ rideId: string; passengerName: string }>();
  const { captain, session } = useCaptainAuth();
  const supabase = getSupabase();

  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const flatListRef = useRef<FlatList>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastCountRef = useRef(0);

  const fetchMessages = useCallback(async () => {
    if (!rideId) return;
    const { data } = await supabase
      .from('ride_messages')
      .select('*')
      .eq('ride_id', rideId)
      .order('created_at', { ascending: true });
    if (data) {
      setMessages(data as Message[]);
      if (data.length !== lastCountRef.current) {
        lastCountRef.current = data.length;
        setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
      }
    }
    setLoading(false);
  }, [rideId]);

  useEffect(() => {
    fetchMessages();
    pollRef.current = setInterval(fetchMessages, 3000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [fetchMessages]);

  const sendMessage = async () => {
    if (!text.trim() || !rideId || !session?.user) return;
    setSending(true);
    const msg = text.trim();
    setText('');
    await supabase.from('ride_messages').insert({
      ride_id: rideId,
      sender_id: session.user.id,
      sender_role: 'captain',
      message: msg,
    });
    setSending(false);
    fetchMessages();
  };

  const renderMessage = ({ item }: { item: Message }) => {
    const isMe = item.sender_role === 'captain';
    return (
      <View style={[styles.bubble, isMe ? styles.bubbleMe : styles.bubbleThem]}>
        <Text style={[styles.bubbleText, isMe ? styles.bubbleTextMe : styles.bubbleTextThem]}>
          {item.message}
        </Text>
        <Text style={[styles.bubbleTime, isMe ? styles.bubbleTimeMe : styles.bubbleTimeThem]}>
          {new Date(item.created_at).toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={[styles.root, { paddingTop: insets.top }]}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={0}
    >
      {/* Header */}
      <View style={styles.header}>
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <MaterialIcons name="chevron-right" size={28} color={Colors.textPrimary} />
        </Pressable>
        <View style={styles.headerInfo}>
          <View style={styles.avatarSmall}>
            <MaterialIcons name="person" size={20} color={Colors.gold} />
          </View>
          <View>
            <Text style={styles.headerName}>{passengerName || 'الراكب'}</Text>
            <Text style={styles.headerStatus}>رحلة نشطة</Text>
          </View>
        </View>
        <View style={styles.onlineDot} />
      </View>

      {/* Messages */}
      {loading ? (
        <View style={styles.loadingState}>
          <ActivityIndicator color={Colors.red} size="large" />
        </View>
      ) : (
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={renderMessage}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
          ListEmptyComponent={() => (
            <View style={styles.emptyState}>
              <MaterialIcons name="chat-bubble-outline" size={48} color={Colors.redDim} />
              <Text style={styles.emptyText}>لا توجد رسائل بعد</Text>
              <Text style={styles.emptySub}>ابدأ المحادثة مع الراكب</Text>
            </View>
          )}
        />
      )}

      {/* Input */}
      <View style={[styles.inputBar, { paddingBottom: insets.bottom + 8 }]}>
        <Pressable
          style={[styles.sendBtn, (!text.trim() || sending) && styles.sendBtnDisabled]}
          onPress={sendMessage}
          disabled={!text.trim() || sending}
        >
          {sending
            ? <ActivityIndicator size="small" color="#fff" />
            : <MaterialIcons name="send" size={22} color="#fff" />}
        </Pressable>
        <TextInput
          style={styles.textInput}
          value={text}
          onChangeText={setText}
          placeholder="اكتب رسالة..."
          placeholderTextColor={Colors.textMuted}
          multiline
          maxLength={500}
          textAlign="right"
          onSubmitEditing={sendMessage}
        />
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background },

  header: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    backgroundColor: Colors.surface,
  },
  backBtn: { padding: 4 },
  headerInfo: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  avatarSmall: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: Colors.goldFaint, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.borderGold,
  },
  headerName: { color: Colors.textPrimary, fontSize: Typography.sizes.base, fontWeight: Typography.weights.semiBold },
  headerStatus: { color: Colors.green, fontSize: Typography.sizes.xs },
  onlineDot: {
    width: 10, height: 10, borderRadius: 5,
    backgroundColor: Colors.green,
  },

  loadingState: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  listContent: { padding: Spacing.base, gap: Spacing.sm, paddingBottom: 8 },

  emptyState: { alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, paddingTop: 80 },
  emptyText: { color: Colors.textPrimary, fontSize: Typography.sizes.lg, fontWeight: Typography.weights.semiBold },
  emptySub: { color: Colors.textMuted, fontSize: Typography.sizes.sm },

  bubble: {
    maxWidth: '78%', borderRadius: Radius.lg, paddingHorizontal: 14, paddingVertical: 10, gap: 3,
  },
  bubbleMe: {
    alignSelf: 'flex-end', backgroundColor: Colors.red,
    borderBottomRightRadius: 4, ...Shadows.red,
  },
  bubbleThem: {
    alignSelf: 'flex-start', backgroundColor: Colors.surfaceCard,
    borderWidth: 1, borderColor: Colors.border, borderBottomLeftRadius: 4,
  },
  bubbleText: { fontSize: Typography.sizes.base, lineHeight: 22 },
  bubbleTextMe: { color: '#fff' },
  bubbleTextThem: { color: Colors.textPrimary },
  bubbleTime: { fontSize: 10 },
  bubbleTimeMe: { color: 'rgba(255,255,255,0.65)', textAlign: 'left' },
  bubbleTimeThem: { color: Colors.textMuted, textAlign: 'right' },

  inputBar: {
    flexDirection: 'row', alignItems: 'flex-end', gap: Spacing.sm,
    paddingHorizontal: Spacing.base, paddingTop: Spacing.sm,
    borderTopWidth: 1, borderTopColor: Colors.border,
    backgroundColor: Colors.surface,
  },
  textInput: {
    flex: 1, backgroundColor: Colors.surfaceCard, borderRadius: Radius.xl,
    borderWidth: 1, borderColor: Colors.border, paddingHorizontal: Spacing.base,
    paddingTop: 10, paddingBottom: 10, color: Colors.textPrimary,
    fontSize: Typography.sizes.base, maxHeight: 100,
  },
  sendBtn: {
    width: 48, height: 48, borderRadius: 24,
    backgroundColor: Colors.red, alignItems: 'center', justifyContent: 'center',
    ...Shadows.red,
  },
  sendBtnDisabled: { opacity: 0.5 },
});
